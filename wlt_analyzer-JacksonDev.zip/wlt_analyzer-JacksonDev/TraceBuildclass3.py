import sys,os,traceback
import re
import struct
import binascii
import subprocess
from workload1 import WorkloadTraceParseClass


leaf_header = '''{
            "cdb_replay": {
                "trace_info": {
                    "source": "", 
                    "author": "unknown", 
                    "max_lba": "", 
                    "date_time": ""
                }, 
                "transaction_attributes": {
                    "time_mode": "relative", 
                    "time_unit": "ms", 
                    "endian": "little"
                }, 
                "header": {
                    "tag": "not presently used"
                }, 
                "device": {
                    "block_size": 0, 
                    "native_block_size": 0, 
                    "lun": 0, 
                    "serial_num": "unknown"
                }, 
                "interface": {
                    "speed": 6, 
                    "type": "SAS"
                }, 
                "transaction_format": [
                    {
                        "rec_length_bytes": 2
                    }, 
                    {
                        "record_format": [
                            {
                                "field": "time", 
                                "length": 4
                            }, 
                            {
                                "field": "cdb_length", 
                                "length": 1
                            }, 
                            {
                                "field": "cdb", 
                                "length": -1
                            }, 
                            {
                                "field": "queue_depth", 
                                "length": 1
                            }
                        ]
                    }
                ]
            }
        }'''

class TraceBuild():
    def __init__(self, *arg) -> None:
        self.arg = arg
        self.input_dir= os.path.dirname(self.arg[1])

    def traceparser(self, ParquetOrNot):
        try:
            # inputfile = sys.argv[1]
            inputfile =  self.arg[1]
            tempDir = self.input_dir
            filename = os.path.basename(inputfile).split('.')[0]
            print(self.input_dir)
            print(f'filename = {filename}')
            if not ParquetOrNot:
                self.callWLT(inputfile,filename,tempDir, '-csv')
                self.updateHeader()
                self.buildLeafFile(tempDir,filename)
            else:
                self.callWLT(inputfile,filename,tempDir, '-parquet')
            self.arg[0].put(1)
        except Exception as e:
            print( '[ERROR] ' + str(e))
            print( traceback.format_exc())
            self.arg[0].put(-1)
            # if os.path.exists('WLTFrameHeader.txt'):
            #     os.remove('WLTFrameHeader.txt')
            # if os.path.exists('WLTMasterFrameHeader.txt'):
            #     os.remove('WLTMasterFrameHeader.txt')

    def callWLT(self,inputfile,filename,tempDir, outputoption):
        infile = inputfile
        outfile = f'{tempDir}\{filename}'
        print(f'infile: {infile}\noutfile: {outfile}')
        #subprocess.call(['py27','workload/WorkloadTraceParse.py', infile ,'-f', outfile,'-notext'])
        #os.system('py27 workload/WorkloadTraceParse.py %s -f %s -notext' % (infile, outfile))
        WorkloadTraceParseClass.WLTparse(self.arg[0], infile, '-f', outfile, outputoption, '-notext').wlt_parser()
        # subprocess.run('python workload1/WorkloadTraceParsePy.py %s -f %s -csv -notext' % (infile, outfile))

    def updateHeader(self):
        global leaf_header
        fi = open('WLTMasterFrameHeader.txt', 'r')
        data = fi.readlines()
        fi.close()
        for line in data:
            if 'SectSize' in line:
                headers = line.strip().split(',')
            else:
                vals = line.strip().split(',')
                leaf_header = leaf_header \
                    .replace(r'"block_size": 0', '"block_size": %s' % vals[headers.index('SectSize')]) \
                    .replace(r'"serial_num": "unknown"', '"serial_num": "%s"' % vals[headers.index('DriveSN')])
                break
        os.remove('WLTMasterFrameHeader.txt')
        os.remove('WLTFrameHeader.txt')


    def buildLeafFile(self, tempDir, filename):
        #bin_files = [f for f in os.listdir(self.input_dir) if f.endswith('.BIN')]
        files = [f for f in os.listdir(tempDir) if filename in f and '.csv' in f]
        #sort file list
        files.sort(key=lambda v: [int(i) for i in (re.match(r"[\w\s\-]*?([\d\.]+)", v).group(1)).split('.')])
        
        offset = binascii.unhexlify(struct.pack('<I',len(leaf_header.encode('utf-8'))+8).hex().upper())

        with open(tempDir+'/{0}_output.csv'.format(filename), 'w') as output_file:
            output_file.write('op,time(ms),start_lba,xfer_length\n')
            current_time = 0
            inc=0
            skipped=0
            wrote=0
            iters = 0        
            for f in files:
                iters += 1
                tempFile = '%s/%s' %( tempDir, f )
                print('reading tempFile: %s' % tempFile)
                # self.arg[0].put(0.49 + iters/len(files)/2)
                try: 
                    with open(tempFile, 'r') as input_file:            	
                        for line in input_file:
                            data = line.rstrip().split(',')
                            if data[-1] == 'READ' or data[-1] == 'WRITE':
                                inc+=1
                                op = data[-1]
                                new_time = round(int(data[2]) * 0.001) #format time to ms
                                time_hr = data[3]
                                start_lba = int(data[5])
                                xfer_length = int(data[6])

                                if inc == 1:
                                    timestamp_ms = 0
                                    #cum_timestamp_ms = 0
                                else:
                                    timestamp_ms = new_time - current_time

                                current_time = new_time            
                                
                                if start_lba > 0:# and timestamp_ms > 0:
                                    wrote+=1
                                    output_string = '{0},{1},{2},{3}\n'.format(op,new_time,start_lba,xfer_length)
                                    output_file.write(output_string)
                                else:
                                    skipped+=1
                                    #print('skip: %s' % line)
                except Exception as e:
                    print('[Error] {0}'.format(e))
                    pass
        print('inc: %s\nwrote: %s\nskipped: %s' % (inc, wrote, skipped))
        for f in files:
            tempFile = '%s/%s' %( tempDir, f )
            os.remove(tempFile)


    def buildLeafCDB(self,op,time,lba,xfer_length):
    ###########################################################
    #  16 byte cdb
    #  88 00 12 34 56 78 90 AB CD EF 00 11 22 33 00 00
    # op|   |        lba           || xfer len |
    ###########################################################

        leaf_length = 22
        cdb_size = 16
        qd = 1
        ops = {
            'READ': '88',
            'WRITE': '8A'
        }
        leaf_size = struct.pack('<H',leaf_length).encode('hex').upper()
        leaf_time = struct.pack('<I',time).encode('hex').upper()
        leaf_cdb_length = "{0:02x}".format(cdb_size).upper()
        leaf_op = ops[op]
        leaf_lba = "{0:016x}".format(lba).upper()
        leaf_xfer_length = "{0:08x}".format(xfer_length).upper()
        leaf_qd = "{0:02x}".format(qd)

        leaf_cdb = leaf_op+'00'+leaf_lba+leaf_xfer_length+'0000'

        leaf_transaction = leaf_size + leaf_time + leaf_cdb_length + leaf_cdb + leaf_qd
        
        return leaf_transaction
    