from PyQt5.QtWidgets import QMainWindow, QApplication
from PyQt5 import uic
import sys

class Delta_time_stats(QMainWindow):
    def __init__(self):
        super().__init__()

        uic.loadUi("delta_time_stats.ui", self)

         
        self.show()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    UIWindow = Delta_time_stats()
    app.exec_()

