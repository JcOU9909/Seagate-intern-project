from PyQt5.QtWidgets import QMainWindow, QApplication
from PyQt5 import uic
import sys

class UI(QMainWindow):
    def __init__(self) -> None:
        super(UI, self).__init__()

        # load the ui file
        uic.loadUi("dialog.ui", self)
        