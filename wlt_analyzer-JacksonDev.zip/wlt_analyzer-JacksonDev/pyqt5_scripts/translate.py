from PyQt5.QtWidgets import QMainWindow, QApplication, QPushButton, QComboBox, QTextEdit, QMessageBox
from PyQt5 import uic
import sys
import googletrans
import textblob
import pyttsx3

class UI(QMainWindow):
    def __init__(self):
        super().__init__()

        uic.loadUi("translate.ui", self)
        self.setWindowTitle("Translator App!")

        self.t_button = self.findChild(QPushButton, "pushButton")
        self.c_button = self.findChild(QPushButton, "pushButton_2")

        self.combo_1 = self.findChild(QComboBox, "comboBox")
        self.combo_2 = self.findChild(QComboBox, "comboBox_2")

        self.text_1 = self.findChild(QTextEdit, "textEdit")
        self.text_2 = self.findChild(QTextEdit, "textEdit_2")

        # click the buttons
        self.t_button.clicked.connect(self.translate)
        self.c_button.clicked.connect(self.clear)

        # Add languages to the combo boxes
        self.languages = googletrans.LANGUAGES
        
        # convert to list
        self.language_list = list(self.languages.values())

        # add items to combo boxes
        self.combo_1.addItems(self.language_list)
        self.combo_2.addItems(self.language_list)


        # Set default combo item
        self.combo_1.setCurrentText('english')
        self.combo_2.setCurrentText('chinese (simplified)')

        self.show()

    def clear(self):
        # Clear the text boxes
        self.text_1.setText("")
        self.text_2.setText("")

        # Set default combo item
        self.combo_1.setCurrentText('english')
        self.combo_2.setCurrentText('chinese (simplified)')




    def translate(self):
        try:
            for key, value in self.languages.items():
                if (value == self.combo_1.currentText()):
                    from_language_key = key
                if (value == self.combo_2.currentText()):
                    to_language_key = key

            # self.text_1.setText(from_language_key)
            # self.text_2.setText(to_language_key)

            words = textblob.TextBlob(self.text_1.toPlainText())

            # translate words
            words = words.translate(from_lang=from_language_key, to=to_language_key)

            self.text_2.setText(str(words))

            # Initialize the speech engine

            engine = pyttsx3.init()

            # play with voices
            voices = engine.getProperty('voices')
            for voice in voices:
                engine.setProperty('voice', voice.id)
                engine.say(words)

            # pass words to speech
            # engine.say(words)

            engine.runAndWait()

        except Exception as e:
            QMessageBox.about(self, "Translator", str(e))



app = QApplication(sys.argv)
UIWindow = UI()
app.exec_()