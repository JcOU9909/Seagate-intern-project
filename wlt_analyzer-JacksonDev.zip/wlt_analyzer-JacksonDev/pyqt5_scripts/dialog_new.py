from PyQt5.QtWidgets import QMainWindow, QApplication, QPushButton, QLabel, QFileDialog
from PyQt5 import uic
import sys

class UI(QMainWindow):
    def __init__(self) -> None:
        super().__init__()

        uic.loadUi("dialog_new.ui", self)

        self.button = self.findChild(QPushButton, "pushButton")
        self.label = self.findChild(QLabel, 'label')
        
        self.button.clicked.connect(self.clicker)



        self.show()

    def clicker(self):
        # self.label.setText("You clicked the button")
        # open file dialog
        fname, _ = QFileDialog.getOpenFileName(self, "Open file", "", "ALL Files (*);;Python Files (*.py)")

        # output filename to screen
        if fname:
            self.label.setText(fname)

app = QApplication(sys.argv)
window = UI()
app.exec_()
