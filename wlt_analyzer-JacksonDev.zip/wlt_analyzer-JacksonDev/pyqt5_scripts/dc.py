from PyQt5.QtWidgets import QMainWindow, QApplication, QComboBox, QLabel
from PyQt5 import uic
import sys

class UI(QMainWindow):
    def __init__(self) -> None:
        super(UI, self).__init__()

        # load the ui file
        uic.loadUi("dc.ui", self)

        self.combo1 = self.findChild(QComboBox, "comboBox")
        self.combo2 = self.findChild(QComboBox, "comboBox_2")
        self.label = self.findChild(QLabel, "label")

        # Add items to the comboBox
        self.combo1.addItem('Male', ['John', 'Wes', 'Dan'])
        self.combo1.addItem('Female', ['April', 'Mary'])

        # Click the first dropdown
        self.combo1.activated.connect(self.clicker)
        self.combo2.activated.connect(self.clicker2)

        # Show the App
        self.show()

    def clicker(self, tmp):
        # clear the second box
        self.combo2.clear()
        self.combo2.addItems(self.combo1.itemData(tmp))

    def clicker2(self):
        self.label.setText(f'You picked {self.combo2.currentText()}')


app = QApplication(sys.argv)
UIWindow = UI()
app.exec_()