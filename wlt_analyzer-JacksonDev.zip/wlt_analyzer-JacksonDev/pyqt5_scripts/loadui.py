from PyQt5.QtWidgets import QMainWindow, QApplication, QLabel, QTextEdit, QPushButton
from PyQt5 import uic
import sys

class UI(QMainWindow):
    def __init__(self) -> None:
        super(UI, self).__init__()

        # Load the ui file
        uic.loadUi("loadui.ui", self)

        # define our widget
        self.label = self.findChild(QLabel, "label")
        self.textedit = self.findChild(QTextEdit, "textEdit")
        self.button = self.findChild(QPushButton, "pushButton")
        self.clear_button = self.findChild(QPushButton, "pushButton_2")
        # Do something
        self.button.clicked.connect(self.clicker)
        self.clear_button.clicked.connect(self.clearer)
        # show the app
        self.show()

    def clicker(self):
        self.label.setText(f"hello There {self.textedit.toPlainText()}")
        self.textedit.setPlainText('')

    def clearer(self):
        self.textedit.setPlainText('')
        self.label.setText('Welcome again')

        
# Initialize the app
app = QApplication(sys.argv)
UIWindow = UI()
app.exec_()