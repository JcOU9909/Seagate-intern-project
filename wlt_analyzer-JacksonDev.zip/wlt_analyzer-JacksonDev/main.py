import re
import sys
from PyQt5 import uic
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QMainWindow, QApplication
from PyQt5.QtCore import QAbstractTableModel, Qt, QProcess, QThread, QTimer

import dask.dataframe as dd
import matplotlib.style as mplstyle
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
mplstyle.use('fast')

import multiprocessing

from ui_demo_1 import *
from TraceBuildclass3 import *
from Wlt_utils import *

# print(os.getcwd())

# PLOT_TYPE = ["scatter", "density", "hexbin"] 
PLOT_TYPE = ["scatter"]
APPINFO = """A python-based WLT Analyzer Tool that can efficiently parse, manipulate and visualize WLT data with common PC config (16GB RAM) to aid FA Engineers in analysis of workload vs failure details (TTF, error LBA, TA/Defect loc, etc.)"""
SCHEMA1 = ['op','start_lba','time(ms)', 'poh', 'xfer_length']
SCHEMA4 = ['op', 'time(ms)', 'poh', 'xfer_length', 'lba after stacking']
ALL_SCHEMA = ['op','start_lba','time(ms)', 'poh', 'xfer_length','delta_time(s)', 'delta_time(hr)','log[delta_time(hr)]', 'lba after stacking']

def sub_run(filename, queue1, queue2):
    """parse function"""
    while not queue1.empty():
        filename = queue1.get()
        TraceBuild(queue2, filename).traceparser(ParquetOrNot=False)

def assign_parse(queue1, filename):
    """assign parse job to multi process"""
    queue1.put(filename)

class WLT_MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.show()

        self.column_types = {'op': 'category',
            'time(ms)': 'float64',
            'start_lba': 'int64',
            'xfer_length': 'int16'}

        self.subdata = pd.DataFrame()
        self.canvas = MplCanvas()

        ## Tookit default status
        self.hidden = False
        self.hide_unhide()
        
        self.ui.progressBar.setValue(0)
        self.queue = multiprocessing.Queue()
        # timer for parsing
        self.timer1 = QTimer()
        self.timer1.timeout.connect(lambda: self.changeProcessBar())
        # timer for analyzing
        self.timer2 = QTimer()
        self.timer2.timeout.connect(lambda: self.communicate())

        # timer for analyzing
        self.updatepgb = QTimer()
        self.updatepgb.timeout.connect(lambda: self.update_progressbar())


        self.multiproc = None
        self.queue1 = None
        self.queue2 = None

        ## Function Connect
        for w in self.ui.leftMenuSubContainer.findChildren(QPushButton):
            # Add click event listener
            w.clicked.connect(self.applyButtonStyle)

        # create a threading pool
        self.threadpool = QThreadPool()
        print("Multithreading with maximum %d threads" % self.threadpool.maxThreadCount())

        self.ui.menuBtn.clicked.connect(lambda: self.hide_unhide())
        self.ui.parseBtn.clicked.connect(self.parser)
        self.ui.csvBtn.clicked.connect(self.load_data)
        # self.ui.csvBtn.clicked.connect(lambda: self.sub_thread_plot())
        self.ui.cacheBtn.clicked.connect(self.show_cache_widget)
        self.ui.filterBtn.clicked.connect(self.show_plot_wlt_widget)
        self.ui.deltaAccessBtn.clicked.connect(self.show_delta_access_widget)
        self.ui.statisticBtn.clicked.connect(self.show_statistic_widget)
        self.ui.adjacentMapBtn.clicked.connect(self.show_adjacent_map_widget)
        self.ui.dataBtn.clicked.connect(self.show_head_widget)

        self.ui.outfilelistWidget.currentRowChanged.connect(self.changeoutfile)         # detect and update outfile

        self.ui.confirm_1.clicked.connect(self.cal_confirm1)
        # self.ui.confirm_2.clicked.connect(self.cal_confirm2)
        self.ui.confirm_2.clicked.connect(self.cal_confirm2_thread)
        self.ui.confirm_3.clicked.connect(self.cal_confirm3)
        self.ui.confirm_4.clicked.connect(self.cal_confirm4)

        self.ui.plotBtn_1.clicked.connect(self.lba_plot_1)
        self.ui.plotBtn_4.clicked.connect(self.lba_plot_4)

        self.ui.informationBtn.clicked.connect(self.show_appinfo)
        self.ui.helpBtn.clicked.connect(self.show_apphelp)

        ## widget changed indicator
        self.ui.stackedWidget.currentChanged.connect(self.changeWidget)
        self.widgetchanged = True
        self.ui.slba_lineEdit_1.textChanged.connect(self.paraChange1)
        self.ui.elba_lineEdit_1.textChanged.connect(self.paraChange1)
        self.ui.spoh_lineEdit_1.textChanged.connect(self.paraChange1)
        self.ui.epoh_lineEdit_1.textChanged.connect(self.paraChange1)
        self.changed1 = False
        self.ui.slba_lineEdit_2.textChanged.connect(self.paraChange2)
        self.ui.elba_lineEdit_2.textChanged.connect(self.paraChange2)
        self.ui.spoh_lineEdit_2.textChanged.connect(self.paraChange2)
        self.ui.epoh_lineEdit_2.textChanged.connect(self.paraChange2)
        self.changed2 = True
        self.ui.lba_lineEdit_3.textChanged.connect(self.paraChange3)
        self.ui.spoh_lineEdit_3.textChanged.connect(self.paraChange3)
        self.ui.epoh_lineEdit_3.textChanged.connect(self.paraChange3)
        self.changed3 = False
        self.ui.slba_lineEdit_4.textChanged.connect(self.paraChange4)
        self.ui.elba_lineEdit_4.textChanged.connect(self.paraChange4)
        self.ui.spoh_lineEdit_4.textChanged.connect(self.paraChange4)
        self.ui.epoh_lineEdit_4.textChanged.connect(self.paraChange4)
        self.changed4 = False

        ## marker operation
        self.update_xy_axis()
        self.ui.style1.addItems(["Solid", "Dashed", "Dotted"])
        self.ui.style4.addItems(["Solid", "Dashed", "Dotted"])

        self.ui.color1.setStyleSheet("QPushButton{background-color: %s}" % QtGui.QColor(0,0,0).name())
        self.ui.color4.setStyleSheet("QPushButton{background-color: %s}" % QtGui.QColor(0,0,0).name())
        self.ui.color1.clicked.connect(lambda: self.color_picker(self.ui.color1))
        self.ui.color4.clicked.connect(lambda: self.color_picker(self.ui.color4))

        self.ui.add_marker_1.clicked.connect(lambda: self.addMarker1(self.ui.marker_listWidget_1, self.ui.x_axis_comboBox_1, self.ui.y_axis_comboBox_1, \
                                                                     self.ui.attr1_1, self.ui.attr1_2, self.ui.attr_value_1, self.ui.attr_label_1, \
                                                                     self.ui.color1, self.ui.style1))
        
        self.ui.add_marker_4.clicked.connect(lambda: self.addMarker1(self.ui.marker_listWidget_4, self.ui.x_axis_comboBox_4, self.ui.y_axis_comboBox_4, \
                                                                     self.ui.attr4_1, self.ui.attr4_2, self.ui.attr_value_4, self.ui.attr_label_4, \
                                                                     self.ui.color4, self.ui.style4))
        
        self.ui.remove_marker_1.clicked.connect(lambda: self.removeMarker(self.ui.marker_listWidget_1))
        self.ui.remove_marker_4.clicked.connect(lambda: self.removeMarker(self.ui.marker_listWidget_4))
        # self.ui.remove_bin.clicked.connect(lambda: self.removeMarker(self.ui.binlistWidget))
        self.ui.remove_outfile.clicked.connect(lambda: self.removeMarker(self.ui.outfilelistWidget))
        self.ui.remove_fig.clicked.connect(lambda: self.removeMarker(self.ui.figlistWidget))


        ## clarify data
        self.binfile_list = []
        self.outfile_list = []
        self.fig_list = []
        

    def hide_unhide(self):
        if self.hidden:
            self.ui.centerMenuContainer.show()
            self.hidden = False
        else:
            self.ui.centerMenuContainer.hide()
            self.hidden = True

    def show_cache_widget(self):
        if self.hidden:
            self.ui.centerMenuContainer.show()
            self.hidden = False
        self.ui.stackedWidget.setCurrentWidget(self.ui.page_2)

    def show_plot_wlt_widget(self):
        if self.hidden:
            self.ui.centerMenuContainer.show()
            self.hidden = False
        self.ui.stackedWidget.setCurrentWidget(self.ui.page_plot_wlt)

    def show_delta_access_widget(self):
        if self.hidden:
            self.ui.centerMenuContainer.show()
            self.hidden = False
        self.ui.stackedWidget.setCurrentWidget(self.ui.page_ave_delta)

    def show_statistic_widget(self):
        if self.hidden:
            self.ui.centerMenuContainer.show()
            self.hidden = False
        self.ui.stackedWidget.setCurrentWidget(self.ui.page_accessed)

    def show_adjacent_map_widget(self):
        if self.hidden:
            self.ui.centerMenuContainer.show()
            self.hidden = False
        self.ui.stackedWidget.setCurrentWidget(self.ui.page_adjacent_map)

    def show_head_widget(self):
        if self.hidden:
            self.ui.centerMenuContainer.show()
            self.hident = False

        self.ui.tableWidget.setRowCount(self.subdata.head(200).shape[0])
        self.ui.tableWidget.setColumnCount(self.subdata.head(200).shape[1])

        # Set the headers for the table widget
        self.ui.tableWidget.setHorizontalHeaderLabels(self.subdata.head(200).columns)

        # Iterate over the rows and columns of the DataFrame
        for i in range(self.subdata.head(200).shape[0]):
            for j in range(self.subdata.head(200).shape[1]):
                # Get the value of the cell in the DataFrame
                cell_value = str(self.subdata.head(200).iloc[i, j])
                
                # Create a new QTableWidgetItem with the cell value
                item = QTableWidgetItem(cell_value)
                
                # Set the item in the table widget
                self.ui.tableWidget.setItem(i, j, item)
        
        self.ui.stackedWidget.setCurrentWidget(self.ui.page_subdata)

    def show_appinfo(self):
        QtWidgets.QMessageBox.information(self, "App Info", APPINFO)

    def show_apphelp(self):
        QtWidgets.QMessageBox.information(self, "Need Help?", "Please contact the app support team at Jiechen.ou@seagate.com.")

    def changeoutfile(self):
        """load outfile if selection occurs"""
        if self.ui.outfilelistWidget.currentItem() is not None:
            self.filepath = self.ui.outfilelistWidget.currentItem().text()
            self.dataset = ds.dataset(self.filepath, format='csv')
            self.ddf = dd.read_csv(self.filepath, blocksize='16mb', dtype=self.column_types)
            self.ui.file_name_label.setText(f"File to analyse: {os.path.basename(self.filepath)}")
        else:
            self.filepath = 'None'
            self.ui.file_name_label.setText(f"File to analyse: {self.filepath}")
            self.ddf = None


    def changeProcessBar(self):
        """change processbar status"""
        if self.queue2.empty() is False:
            value = self.queue2.get()            
            self.ui.progressBar.setValue(int(value*100))
            if value == 1:
                self.ui.binlistWidget.setCurrentRow(0)
                self.ui.binlistWidget.takeItem(0)

                if self.ui.binlistWidget.count() == 0:
                    print("Good")
                    self.multiproc.terminate()
                    self.multiproc = None
                    self.queue1 = None
                    self.queue2 = None
                    self.timer1.stop()
                    self.ui.status_label.setText("Processing Status: Parsing completed")
                    return

                bin_path = self.ui.binlistWidget.currentItem().text()
                bin_name = re.findall(r'(?<=/)[A-Za-z0-9_.]*', bin_path)[-1]
                self.ui.file_name_label.setText(f"File to parse: {bin_name}")
            elif value == -1:
                self.ui.binlistWidget.clear()
                self.multiproc.terminate()
                self.multiproc = None
                self.queue1 = None
                self.queue2 = None
                self.timer1.stop()
                self.ui.status_label.setText("Processing Status: Parsing failure")



    def parser(self):
        """parser bin file (multi process)"""

        bin_path,_ =  QtWidgets.QFileDialog.getOpenFileName(self, "Open file", "", "ALL Files (*);; BIN file (*.BIN)")
        if bin_path:
            bin_name = re.findall(r'(?<=/)[A-Za-z0-9_.]*', bin_path)[-1]
                                       

        question = QtWidgets.QMessageBox.question(self, "Parser BIN file", 
                                                  "Do you want to parse the BIN file?",
                                                  QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No)

        if question == QtWidgets.QMessageBox.Yes and not bin_path is None:
            # print(bin[-3:])
            if bin_path[-3:] != 'BIN':
                self.ui.status_label.setText("Processing status :  Error (Wrong file selected)")
                QtWidgets.QMessageBox.critical(self, "Error", "Please select appropriate files")
                return
            
            # print(f"Start parse BIN file : {self.bin_name}")
            self.ui.binlistWidget.addItem(bin_path)
            if self.multiproc is None:
                self.timer1.start(500)
                self.ui.file_name_label.setText(f"File to parse: {bin_name}")
                self.ui.status_label.setText("Processing Status: Parsing...")

                self.queue1 = multiprocessing.Queue()
                self.queue2 = multiprocessing.Queue()

                self.queue1.put(bin_path)
                self.multiproc = multiprocessing.Process(target=sub_run, args=(bin_path, self.queue1, self.queue2))
                self.multiproc.start()
            else:
                self.queue1.put(bin_path)


    def load_data(self):
        """load dataset with Dask module"""
        self.ui.progressBar.setValue(0)

        fname, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Open file", "", "ALL Files (*);; Excel (*.csv) ;; BIN file (*.BIN)")
        if fname:
            file_path = fname
            file_name = os.path.basename(fname)
            # self.ui.file_name_label.setText(f"File to analyse: {self.file_name}")

            if file_name[-3:] != 'csv':
                self.ui.status_label.setText("Processing status :  Error (Wrong file selected)")
                QtWidgets.QMessageBox.critical(self, "Error", "Please select appropriate files")
                return

            # ddf = dd.read_csv(file_path, blocksize='16mb', dtype=self.column_types)
            self.outfile_list.append(file_path)
            # self.ddf_list.append(ddf)
            self.ui.progressBar.setValue(100)
            self.ui.outfilelistWidget.addItem(file_path)
            self.ui.outfilelistWidget.setCurrentRow(self.ui.outfilelistWidget.count()-1)
            self.ui.outfilelistWidget.item(self.ui.outfilelistWidget.count()-1).setSelected(True)
            self.ui.status_label.setText("Processing Status: Loading completed")

    def changeWidget(self):
        """trigger for widget change"""
        self.widgetchanged = True

    def paraChange1(self):
        """trigger for parameters change"""
        self.changed1 = True

    def paraChange2(self):
        """trigger for parameters change"""
        self.changed2 = True

    def paraChange3(self):
        """trigger for parameters change"""
        self.changed3 = True

    def paraChange4(self):
        """trigger for parameters change"""
        self.changed4 = True

    def communicate(self):
        """Communication with process 2 after it finishes"""
        self.ui.progressBar.setValue(min(95, (self.ui.progressBar.value()+1)))
        if self.queue.empty() is False:
            index = self.queue.get()
            self.multiproc.terminate()
            self.timer2.stop()
            self.queue = None
            if index == 'None data found':
                QtWidgets.QMessageBox.information(self, "Info", "No data found during searching")
                return

            self.subdata = pd.read_parquet(index)            

            ## update plot options for different functions
            if self.ui.stackedWidget.currentIndex() == 1:
                if self.ui.x_axis_comboBox_1.count() <= 1:
                    self.ui.x_axis_comboBox_1.addItems([self.ui.x_axis_comboBox_1.currentText()] + list(self.subdata.columns))
                    self.ui.y_axis_comboBox_1.addItems([self.ui.y_axis_comboBox_1.currentText()] + list(self.subdata.columns))
                    self.ui.kind_comboBox_1.addItems([self.ui.kind_comboBox_1.currentText()] + PLOT_TYPE)
            elif self.ui.stackedWidget.currentIndex() == 4:
                if self.ui.x_axis_comboBox_4.count() <= 1:
                    self.ui.x_axis_comboBox_4.addItems([self.ui.x_axis_comboBox_4.currentText()] + list(self.subdata.columns))
                    self.ui.y_axis_comboBox_4.addItems([self.ui.y_axis_comboBox_4.currentText()] + list(self.subdata.columns))
                    self.ui.kind_comboBox_4.addItems([self.ui.kind_comboBox_4.currentText()] + PLOT_TYPE)
                
            # self.check_option()
            if os.path.exists("buffer.parquet"):
                os.remove("buffer.parquet")
            
            # check visual function
            self.check_plot_option()

            self.ui.status_label.setText("Processing Status: Loading completed")
            self.ui.progressBar.setValue(100) # show the process is finished


    def cal_confirm1(self):
        """confirm function for `wlt plot`"""
        if self.ddf is None:
            QtWidgets.QMessageBox.critical(self, "Error", "Please Load dataset first")
            return
        
        plt.close("all")
        self.clean_subwindow() # clean mdiwindow
        # self.subdata = pd.DataFrame() # clean dataframe


        start_lba = str2num(self.ui.slba_lineEdit_1)
        end_lba = str2num(self.ui.elba_lineEdit_1)
        start_poh = str2num(self.ui.spoh_lineEdit_1)
        end_poh = str2num(self.ui.epoh_lineEdit_1)
        
        if self.changed1 or self.widgetchanged:
            self.changestatus(1)
            self.ui.progressBar.setValue(0)
            self.ui.status_label.setText("Processing Status: Loading...")
            self.timer2.start(500)
            self.queue = multiprocessing.Queue()
            self.multiproc = multiprocessing.Process(target=ddf_compute, kwargs={'ddf':self.ddf, 'start_lba':start_lba, 'end_lba':end_lba, 'start_poh':start_poh, 'end_poh':end_poh, \
                                                                                 'type':2, 'aug':['POH'], 'queue':self.queue})
            self.multiproc.start()
            self.changed1 = False
            self.widgetchanged = False
        else: # parameters as well as widget no change
            if len(self.subdata) > 0:
                if self.clicked_func1:
                    self.check_plot_option()
                else:
                    QtWidgets.QMessageBox.critical(self, "Error", "Please choose a subset of data first")
                    return
            else:
                if not self.clicked_func1:
                    QtWidgets.QMessageBox.critical(self, "Error", "Please choose a subset of data first")
                else:
                    QtWidgets.QMessageBox.critical(self, "Error", "The data you select is empty")


    def cal_confirm1_thread(self):
        """plot function for 'wlt_data'"""
        if self.dataset is None:
            QtWidgets.QMessageBox.critical(self, "Error", "Please Load dataset first")
            return
        
        start_lba = str2num(self.ui.slba_lineEdit_1)
        end_lba = str2num(self.ui.elba_lineEdit_1)
        start_poh = str2num(self.ui.spoh_lineEdit_1)
        end_poh = str2num(self.ui.epoh_lineEdit_1)

        path1 = self.return_path()
        path1 = path1 + \
            f'_filter_{self.ui.slba_lineEdit_1.text().strip()}_{self.ui.elba_lineEdit_1.text().strip()}_{self.ui.spoh_lineEdit_1.text().strip()}_{self.ui.epoh_lineEdit_1.text().strip()}.csv'
        first_click = self.changed1 or self.widgetchanged # check for first click
        if first_click:
            canvas = MplCanvas()
            subwidget = SubWindow_Canvas(canvas=canvas)
            axes = [subwidget.canvas.axes]
            # create new sub window
            sub = QMdiSubWindow()
            sub.setWidget(subwidget)
            # Add the sub-window to the MDI area
            self.ui.mdiArea.addSubWindow(sub)
            x = [self.ui.x_axis_comboBox_1.currentText()]
            y = [self.ui.y_axis_comboBox_1.currentText()]
            plot_kind = [self.ui.kind_comboBox_1.currentText()]
            sub.show()
            self.sub_thread_plot(axes, start_lba, end_lba, start_poh, end_poh, x_axis = x, plot_kind=plot_kind, funcindex=2, saveOrnot=self.ui.save_radioBtn_2.isChecked(), path1=path1, state=1)
        else:
            pass
        

    def cal_confirm2_thread(self):
        """confirm function for `accessed freq`"""
        if self.dataset is None:
            QtWidgets.QMessageBox.critical(self, "Error", "Please Load dataset first")
            return

        start_lba = str2num(self.ui.slba_lineEdit_2)
        end_lba = str2num(self.ui.elba_lineEdit_2)
        start_poh = str2num(self.ui.spoh_lineEdit_2)
        end_poh = str2num(self.ui.epoh_lineEdit_2)
        
        path1 = self.return_path()
        path1 = path1 + '_startlba_freq_100.csv'
        first_click = self.changed2 or self.widgetchanged # check for first click

        if first_click:
            if self.ui.show_hist_2.isChecked():
                canvas = MplCanvas()
                subwidget = SubWindow_Canvas(canvas=canvas)
                axes = [subwidget.canvas.axes]
                # create new sub window
                sub = QMdiSubWindow()
                sub.setWidget(subwidget)
                # Add the sub-window to the MDI area
                self.ui.mdiArea.addSubWindow(sub)
                plot_kind = ['histogram']
                x = ['start_lba']
                sub.show()
                self.sub_thread_plot(axes, start_lba, end_lba, start_poh, end_poh, x_axis = x, plot_kind=plot_kind, funcindex=2, saveOrnot=self.ui.save_radioBtn_2.isChecked(), path1=path1, state=1)
            else:
                self.sub_thread_plot(None, start_lba, end_lba, start_poh, end_poh, funcindex=2, saveOrnot=self.ui.save_radioBtn_2.isChecked(), path1=path1, state=1)
        else:
            pass


    def cal_confirm2(self):
        """confirm function for `accessed freq`"""
        if self.dataset is None:
            QtWidgets.QMessageBox.critical(self, "Error", "Please Load dataset first")
            return
        
        plt.close("all")
        self.clean_subwindow()
        # self.subdata = pd.DataFrame() # clean dataframe


        start_lba = str2num(self.ui.slba_lineEdit_2)
        end_lba = str2num(self.ui.elba_lineEdit_2)
        start_poh = str2num(self.ui.spoh_lineEdit_2)
        end_poh = str2num(self.ui.epoh_lineEdit_2)
        
        if self.changed2 or self.widgetchanged:
            self.changestatus(2)
            self.ui.progressBar.setValue(0)
            self.ui.status_label.setText("Processing Status: Loading...")
            self.timer2.start(500)
            self.queue = multiprocessing.Queue()
            self.multiproc = multiprocessing.Process(target=ddf_compute, kwargs={'dataset':self.dataset, 'start_lba':start_lba, 'end_lba':end_lba, 'start_poh':start_poh, 'end_poh':end_poh, \
                                                                                'type':3, 'queue':self.queue})
            self.multiproc.start()
            self.changed2 = False
            self.widgetchanged = False
        else: # parameters as well as widget no change
            if len(self.subdata) > 0:
                if self.clicked_func2:
                    self.check_plot_option()
                else:
                    QtWidgets.QMessageBox.critical(self, "Error", "Please confirm first")
                    return
            else:
                if not self.clicked_func2:
                    QtWidgets.QMessageBox.critical(self, "Error", "Please confirm first")
                else:
                    QtWidgets.QMessageBox.critical(self, "Error", "The data you select is empty")

    def cal_confirm3(self):
        """confirm function for `delta avg time`"""
        if self.ddf is None:
            QtWidgets.QMessageBox.critical(self, "Error", "Please Load dataset first")
            return
        
        plt.close("all")
        self.clean_subwindow()
        # self.subdata = pd.DataFrame() # clean dataframe


        lba = str2num(self.ui.lba_lineEdit_3)
        start_poh = str2num(self.ui.spoh_lineEdit_3)
        end_poh = str2num(self.ui.epoh_lineEdit_3)
        
        if self.changed3 or self.widgetchanged:
            self.changestatus(3)
            if lba == -2:
                QtWidgets.QMessageBox.critical(self, "Error", "Please specify LBA first")
                return

            self.ui.progressBar.setValue(0)
            self.ui.status_label.setText("Processing Status: Loading...")
            self.timer2.start(500)
            self.queue = multiprocessing.Queue()
            self.multiproc = multiprocessing.Process(target=ddf_compute, kwargs={'ddf':self.ddf, 'lba':lba, 'start_poh':start_poh, 'end_poh':end_poh, 'queue':self.queue, \
                                                                                 'aug':["POH", "delta_time"], 'type':1})
            self.multiproc.start()
            self.changed3 = False
            self.widgetchanged = False
        else: # parameters as well as widget no change
            if len(self.subdata) > 0:
                if self.clicked_func3:
                    self.check_plot_option()
                else:
                    QtWidgets.QMessageBox.critical(self, "Error", "Please confirm first")
                    return
            else:
                if not self.clicked_func3:
                    QtWidgets.QMessageBox.critical(self, "Error", "Please confirm first")
                else:
                    QtWidgets.QMessageBox.critical(self, "Error", "The data you select is empty")

    def cal_confirm4(self):
        """confirm function for `adjacent write map`"""
        if self.ddf is None:
            QtWidgets.QMessageBox.critical(self, "Error", "Please Load dataset first")
            return
        
        plt.close("all")
        self.clean_subwindow()
        # self.subdata = pd.DataFrame() # clean dataframe

        
        start_lba = str2num(self.ui.slba_lineEdit_4)
        end_lba = str2num(self.ui.elba_lineEdit_4)
        start_poh = str2num(self.ui.spoh_lineEdit_4)
        end_poh = str2num(self.ui.epoh_lineEdit_4)
        
        if self.changed4 or self.widgetchanged:
            self.changestatus(4)
            
            self.ui.progressBar.setValue(0)
            self.ui.status_label.setText("Processing Status: Loading...")
            self.timer2.start(500)
            self.queue = multiprocessing.Queue()
            self.multiproc = multiprocessing.Process(target=stack_data, kwargs={'ddf':self.ddf, 'start_lba':start_lba, 'end_lba':end_lba, 'start_poh':start_poh, 'end_poh':end_poh, \
                                                                                 'type':2, 'aug':[], 'queue':self.queue})
            self.multiproc.start()
            self.changed4 = False
            self.widgetchanged
        else: # parameters as well as widget no change
            if len(self.subdata) > 0:
                if self.clicked_func4:
                    self.check_plot_option()
                else:
                    QtWidgets.QMessageBox.critical(self, "Error", "Please choose a subset of data first")
                    return
            else:
                if not self.clicked_func4:
                    QtWidgets.QMessageBox.critical(self, "Error", "Please choose a subset of data first")
                else:
                    QtWidgets.QMessageBox.critical(self, "Error", "The data you select is empty")


    def count_dist(self):
        self.ui.status_label.setText("Processing Status: Loading...")
        self.ui.progressBar.setValue(25)
        fig, ax = plt.subplots(figsize=(16,4))
        # sns.barplot(data=self.subdata, x="start_lba", y="count", ax=ax)
        tmp = self.ddf['start_lba'].compute()
        ax.hist(tmp, bins=int(500), histtype='barstacked', color='teal', rwidth=0.9)
        # fig, ax = plt.subplots(figsize=(18,3))
        # ax.bar(self.subdata['start_lba'].loc[:10], self.subdata['count'].loc[:10])
        # ax.set_yticklabels([])
        ax.set_ylabel('Freq')
        ax.set_xlabel('start lba')
        ax.set_title("Distributions")
        ax.ticklabel_format(style='plain', axis='x')
        # ax.ticklabel_format(style='plain', axis='y')
        # change the font size of the x-axis labels
        ax.tick_params(axis='x', labelsize=6)
        plot_mdiarea(self.ui.mdiArea, fig, ax, process_bar=self.ui.progressBar, status_label=self.ui.status_label)
        # self.ui.figlistWidget.addItem(str(id(fig)))

    
    def delta_access_time_stats(self, lba):
        
        quantiles = [0.005, 0.025, 0.1, 0.25, 0.5, 0.75, 0.975, 0.995]
        stat = self.subdata['delta_time_sec'].dropna().describe(percentiles=quantiles).to_frame().round(3).reset_index(names='statistics')
        
        show_df_mdiarea(self.ui.mdiArea, stat, f"Time delta bet LBA access(in seconds) to LBA {lba}")
        if self.ui.save_radioBtn_3.isChecked():
            stat.to_csv(f"{self.filepath[:-4]}_delta_statistics_of_LBA{lba}.csv", index=False)

        return

    def delta_time_cdf(self):
        self.ui.status_label.setText("Processing Status: Loading...")
        self.ui.progressBar.setValue(25)
        fig, ax = plt.subplots(figsize=(4,4))
        sns.axes_style("whitegrid")
        gfg = sns.kdeplot(ax=ax,
            data=self.subdata.loc[self.subdata['delta_time_sec'] < 200], x="delta_time_sec",
            cumulative=True, common_norm=False, common_grid=True, color='red')
        gfg.set(xlabel="Delta bet LBA access", ylabel = 'Cum Prob')

        plot_mdiarea(self.ui.mdiArea, fig, gfg, process_bar=self.ui.progressBar, status_label=self.ui.status_label)
        # self.ui.figlistWidget.addItem(str(id(fig)))
    
    def delta_time_hist(self):
        self.ui.status_label.setText("Processing Status: Loading...")
        self.ui.progressBar.setValue(25)
        fig, ax = plt.subplots(figsize=(4,4))
        ax.hist(data=self.subdata, x='delta_time_sec', bins=30)
        ax.set_xlabel('Time delta bet LBA access (sec)')
        ax.set_ylabel('Count')

        # ax.xaxis.set_major_formatter(ScalarFormatter())
        # ax.yaxis.set_major_formatter(ScalarFormatter())
        ax.ticklabel_format(style='plain', axis='x')
        ax.ticklabel_format(style='plain', axis='y')
        ax.tick_params(axis='x', labelsize=6)
        ax.tick_params(axis='y', labelsize=6)

        plot_mdiarea(self.ui.mdiArea, fig, ax, process_bar=self.ui.progressBar, status_label=self.ui.status_label)
        # self.ui.figlistWidget.addItem(str(id(fig)))


    def delta_time_jointplot(self, lba):
        '''
            Subdata should already have column POH, Log_time(delta) before call this function
        '''
        self.ui.status_label.setText("Processing Status: Loading...")
        self.ui.progressBar.setValue(25)
        
        x_label = 'POH'
        y_label = 'log_time(delta)'

        jp = sns.JointGrid(data=self.subdata, x= x_label, y= y_label)
        jp.plot_joint(sns.scatterplot, s=5, alpha=.5)
        jp.plot_marginals(sns.histplot)

        jp.ax_joint.axhline(y=-1.3, color='red', linestyle='--')
        jp.ax_joint.text(-.1 , -1.3, '0.5', color='red', va='top')

        jp.ax_joint.set_ylim(-6, 6)
        locator = ticker.FixedLocator([i for i in range(-6, 7)])
        jp.ax_joint.yaxis.set_major_locator(locator)
        jp.ax_joint.set_yticklabels([10**i for i in range(-6, 7)])
        jp.ax_joint.set_ylabel("delta bet LBA access(hr)")
        jp.fig.suptitle(f"Drive SN: {os.path.basename(self.filepath)[:-4]}")

        jp.ax_joint.ticklabel_format(style='plain', axis='x')
        # jp.ax_joint.ticklabel_format(style='plain', axis='y')
        jp.ax_joint.tick_params(axis='x', labelsize=6)
        jp.ax_joint.tick_params(axis='y', labelsize=6)
        
        # self.ui.figlistWidget.addItem(str(id(jp.figure)))
        plot_mdiarea(self.ui.mdiArea, jp.figure, title=f'Bivariate Fit of delta time bet access to LBA {lba} across POH',\
            process_bar=self.ui.progressBar, status_label=self.ui.status_label)


    def lba_plot_1(self):
        self.ui.status_label.setText("Processing Status: Loading...")
        self.ui.progressBar.setValue(25)
        x_axis = self.ui.x_axis_comboBox_1.currentText()
        y_axis = self.ui.y_axis_comboBox_1.currentText()
        plot_style = self.ui.kind_comboBox_1.currentText()

        count = self.ui.marker_listWidget_1.count()

        if x_axis == self.ui.x_axis_comboBox_1.itemText(0) or y_axis == self.ui.x_axis_comboBox_1.itemText(0):
            QtWidgets.QMessageBox.critical(self, "Error", "Please select X/Y axis.")
            return
            
        if self.ui.plotBy1_1.isChecked():
            fig, ax = plt.subplots(figsize=(15, 8))
            if plot_style == 'density':
                # # Sample the data
                # sample_size = 20000
                # sns.histplot(data = self.subdata, x = self.x_axis, y = self.y_axis, hue="op", ax=ax)
                return
            elif plot_style == 'hexbin':
                # ax.hexbin(x=self.subdata.loc[self.subdata['op'] =='READ', x_axis], y=self.subdata.loc[self.subdata['op'] =='READ', y_axis], label='READ', cmap ='Blues')
                # ax.hexbin(x=self.subdata.loc[self.subdata['op'] =='WRITE', x_axis], y=self.subdata.loc[self.subdata['op'] =='WRITE', y_axis], label='WRITE', cmap ='Reds')
                return
            else:
                ax.scatter(x=self.subdata.loc[self.subdata['op'] =='READ', x_axis], y=self.subdata.loc[self.subdata['op'] =='READ', y_axis], s=0.1, label='READ')
                ax.scatter(x=self.subdata.loc[self.subdata['op'] =='WRITE', x_axis], y=self.subdata.loc[self.subdata['op'] =='WRITE', y_axis], s=0.1, label='WRITE')
            ax.legend(loc='upper right')
            ax.set_xlabel(x_axis)
            ax.set_ylabel(y_axis)
            ax.set_title(f"{y_axis} vs. {x_axis}")
            ax.ticklabel_format(style='plain', axis='x')
            ax.ticklabel_format(style='plain', axis='y')
            ax.tick_params(axis='x', labelsize=6)
            ax.tick_params(axis='y', labelsize=6)

            for i in range(count):
                info = self.ui.marker_listWidget_1.item(i).text() # Input format: X/Y value
                color = self.ui.marker_listWidget_1.item(i).foreground().color().name()
    
                pattern = r"(x|y)\((.*)\):\s*(\w*)\s+(\w*)"
                # Use regex to extract the components
                matches = re.search(pattern, info)
                
                if matches.group(1) == 'x':
                    ax.axvline(x = int(matches.group(3)), color=color, linestyle=matches.group(4))
                    ax.text(int(matches.group(3)), -.05, f'{matches.group(2)} : {matches.group(3)}', color='red', transform=ax.get_xaxis_transform(), 
                             ha='center', va='top')
                elif matches.group(1) == 'y':
                    ax.axhline(y = int(matches.group(3)), color=color, linestyle=matches.group(4))
                    ax.text(-.07 , int(matches.group(3)), f'{matches.group(2)} : {matches.group(3)}', color='red', transform=ax.get_yaxis_transform(), 
                             ha='center', va='top')
                else:
                    QtWidgets.QMessageBox.critical(self, "Error", "Input wrong Value or Attribute for marker")
                    return
                    
            # plt.show()
        else:
            if self.ui.plotBy1_1.isChecked():
                fig, (ax1,ax2) = plt.subplots(nrows=2, sharex=True, figsize=(15, 8)) # frameon=False removes frames
                # plt.subplots_adjust(hspace=.05)  

                ax1.grid(linestyle='--', linewidth=0.5)
                ax2.grid(linestyle='--', linewidth=0.5)

                plot1 = ax1.scatter(x=self.subdata.loc[self.subdata['op'] =='READ', x_axis], y=self.subdata.loc[self.subdata['op'] =='READ', y_axis], s=0.1, label='READ', c='crimson')
                plot2 = ax2.scatter(x=self.subdata.loc[self.subdata['op'] =='WRITE', x_axis], y=self.subdata.loc[self.subdata['op'] =='WRITE', y_axis], s=0.1, label='dodgerblue')

                ax1.set_ylabel(y_axis)
                ax2.set_xlabel(x_axis)
                ax2.set_ylabel(y_axis)

                ax2.legend((plot1, plot2), ('Read', 'Write'))
                fig.suptitle(f"{y_axis} vs. {x_axis}")

                ax1.ticklabel_format(style='plain', axis='y')
                ax1.tick_params(axis='y', labelsize=6)
                ax2.ticklabel_format(style='plain', axis='x')
                ax2.ticklabel_format(style='plain', axis='y')
                ax2.tick_params(axis='x', labelsize=6)
                ax2.tick_params(axis='y', labelsize=6)

                for i in range(count):
                    info = self.ui.marker_listWidget_1.item(i).text() # Input format: X/Y value
                    color = self.ui.marker_listWidget_1.item(i).foreground().color().name()
                    pattern = r"(x|y)\((.*)\):\s*(\w*)\s+(\w*)"
                    # Use regex to extract the components
                    matches = re.search(pattern, info)
                
                    if matches.group(1) == 'x':
                        ax1.axvline(x = int(matches.group(3)), color=color, linestyle=matches.group(4))
                        ax2.axvline(x = int(matches.group(3)), color=color, linestyle=matches.group(4))
                        ax2.text(int(matches.group(3)), -.05, f'{matches.group(2)} : {matches.group(3)}', color='red', transform=ax2.get_xaxis_transform(), 
                                ha='center', va='top')
                    elif matches.group(1) == 'y':
                        ax1.axhline(y = int(matches.group(3)), color=color, linestyle=matches.group(4))
                        ax2.axhline(y = int(matches.group(3)), color=color, linestyle=matches.group(4))
                        ax1.text(-.07 , int(matches.group(3)), f'{matches.group(2)} : {matches.group(3)}', color='red', transform=ax1.get_yaxis_transform(), 
                                ha='center', va='top')
                        ax2.text(-.07 , int(matches.group(3)), f'{matches.group(2)} : {matches.group(3)}', color='red', transform=ax2.get_yaxis_transform(), 
                                ha='center', va='top')
                    else:
                        QtWidgets.QMessageBox.critical(self, "Error", "Input wrong Value or Attribute for marker")
                        return

                fig.tight_layout()
                # sns.scatterplot(x=self.subdata.loc[self.subdata['op'] =='READ',self.y_axis], y=self.subdata.loc[self.subdata['op'] =='READ',self.x_axis], s=0.5, label='READ', ax=ax1)
                # sns.scatterplot(x=self.subdata.loc[self.subdata['op'] =='WRITE',self.y_axis], y=self.subdata.loc[self.subdata['op'] =='WRITE',self.x_axis], s=0.5, label='WRITE', ax=ax2)
            else:
                fig, (ax1,ax2) = plt.subplots(ncols=2, sharey=True, figsize=(15, 8)) # frameon=False removes frames
                # plt.subplots_adjust(hspace=.05)  

                ax1.grid(linestyle='--', linewidth=0.5)
                ax2.grid(linestyle='--', linewidth=0.5)

                plot1 = ax1.scatter(x=self.subdata.loc[self.subdata['op'] =='READ', x_axis], y=self.subdata.loc[self.subdata['op'] =='READ', y_axis], s=0.1, label='READ', c='crimson')
                plot2 = ax2.scatter(x=self.subdata.loc[self.subdata['op'] =='WRITE', x_axis], y=self.subdata.loc[self.subdata['op'] =='WRITE', y_axis], s=0.1, label='dodgerblue')

                ax1.set_ylabel(y_axis)
                ax1.set_xlabel(x_axis)
                ax2.set_xlabel(x_axis)

                ax2.legend((plot1, plot2), ('Read', 'Write'))
                fig.suptitle(f"{y_axis} vs. {x_axis}")

                ax1.ticklabel_format(style='plain', axis='x')
                ax1.ticklabel_format(style='plain', axis='y')
                ax1.tick_params(axis='x', labelsize=6)
                ax1.tick_params(axis='y', labelsize=6)
                ax2.ticklabel_format(style='plain', axis='x')
                ax2.tick_params(axis='x', labelsize=6)

                for i in range(count):
                    info = self.ui.marker_listWidget_1.item(i).text() # Input format: X/Y value
                    color = self.ui.marker_listWidget_1.item(i).foreground().color().name()
                    pattern = r"(x|y)\((.*)\):\s*(\w*)\s+(\w*)"
                    # Use regex to extract the components
                    matches = re.search(pattern, info)
                
                    if matches.group(1) == 'x':
                        ax1.axvline(x = float(matches.group(3)), color=color, linestyle=matches.group(4))
                        ax2.axvline(x = float(matches.group(3)), color=color, linestyle=matches.group(4))
                        ax1.text(float(matches.group(3)), -.05, f'{matches.group(2)} : {matches.group(3)}', color='red', transform=ax1.get_xaxis_transform(), 
                                ha='center', va='top')
                        ax2.text(float(matches.group(3)), -.05, f'{matches.group(2)} : {matches.group(3)}', color='red', transform=ax2.get_xaxis_transform(), 
                                ha='center', va='top')
                    elif matches.group(1) == 'y':
                        ax1.axhline(y = float(matches.group(3)), color=color, linestyle=matches.group(4))
                        ax2.axhline(y = float(matches.group(3)), color=color, linestyle=matches.group(4))
                        ax1.text(-.07 , float(matches.group(3)), f'{matches.group(2)} : {matches.group(3)}', color='red', transform=ax1.get_yaxis_transform(), 
                                ha='center', va='top')
                    else:
                        QtWidgets.QMessageBox.critical(self, "Error", "Input wrong Value or Attribute for marker")
                        return
                fig.tight_layout()

        plot_mdiarea(self.ui.mdiArea, fig, process_bar=self.ui.progressBar, status_label=self.ui.status_label)   
        # self.ui.figlistWidget.addItem(str(id(fig)))

    
    def lba_plot_4(self):
        """lba plot for stacked data"""
        self.ui.status_label.setText("Processing Status: Loading...")
        self.ui.progressBar.setValue(25)
        x_axis = self.ui.x_axis_comboBox_4.currentText()
        y_axis = self.ui.y_axis_comboBox_4.currentText()
        plot_style = self.ui.kind_comboBox_4.currentText()

        count = self.ui.marker_listWidget_4.count()

        if x_axis == self.ui.x_axis_comboBox_4.itemText(0) or y_axis == self.ui.x_axis_comboBox_4.itemText(0):
            QtWidgets.QMessageBox.critical(self, "Error", "Please select X/Y axis.")
            return
            
        if self.ui.plotBy4_1.isChecked():
            fig, ax = plt.subplots(figsize=(15, 8))
            if plot_style == 'scatter':
                if self.ui.skip_none.isChecked():
                    ax.scatter(x=self.subdata.loc[self.subdata['label'] =='start_lba', x_axis], y=self.subdata.loc[self.subdata['label'] =='start_lba', y_axis], \
                               c='red', s=0.1, label='start_lba')
                    ax.scatter(x=self.subdata.loc[self.subdata['label'] =='end_lba', x_axis], y=self.subdata.loc[self.subdata['label'] =='end_lba', y_axis], \
                               c='blue',s=0.1, label='end_lba')
                elif self.ui.skip_write.isChecked():
                    ax.scatter(x=self.subdata.loc[(self.subdata['label'] =='start_lba') & (self.subdata['op'] == 'READ'), x_axis], \
                               y=self.subdata.loc[(self.subdata['label'] =='start_lba') & (self.subdata['op'] == 'READ'), y_axis], \
                               c='red', s=0.1, label='start_lba')
                    ax.scatter(x=self.subdata.loc[(self.subdata['label'] =='end_lba') & (self.subdata['op'] == 'READ'), x_axis], \
                               y=self.subdata.loc[(self.subdata['label'] =='end_lba') & (self.subdata['op'] == 'READ'), y_axis], \
                               c='blue', s=0.1, label='end_lba')
                elif self.ui.skip_read.isChecked():
                    ax.scatter(x=self.subdata.loc[(self.subdata['label'] =='start_lba') & (self.subdata['op'] == 'WRITE'), x_axis], \
                               y=self.subdata.loc[(self.subdata['label'] =='start_lba') & (self.subdata['op'] == 'WRITE'), y_axis], \
                               c='red', s=0.1, alpha=0.5, label='start_lba')
                    ax.scatter(x=self.subdata.loc[(self.subdata['label'] =='end_lba') & (self.subdata['op'] == 'WRITE'), x_axis], \
                               y=self.subdata.loc[(self.subdata['label'] =='end_lba') & (self.subdata['op'] == 'WRITE'), y_axis], \
                               c='blue', s=0.1, alpha=0.5, label='end_lba')    
                
            # elif self.plotstyle_combo.currentText() == 'density':
            #     # Sample the data
            #     sample_size = 20000
            #     sns.histplot(data = self.subdata, x = self.x_axis, y = self.y_axis, hue="op", ax=ax)
            # elif self.plotstyle_combo.currentText() == 'hexbin':
            #     ax.hexbin(x=self.subdata.loc[self.subdata['op'] =='READ', self.x_axis], y=self.subdata.loc[self.subdata['op'] =='READ', self.y_axis], label='READ', cmap ='Blues')
            #     ax.hexbin(x=self.subdata.loc[self.subdata['op'] =='WRITE', self.x_axis], y=self.subdata.loc[self.subdata['op'] =='WRITE', self.y_axis], label='WRITE', cmap ='Reds')
            
            ax.ticklabel_format(style='plain', axis='x')
            ax.ticklabel_format(style='plain', axis='y')
            ax.tick_params(axis='x', labelsize=6)
            ax.tick_params(axis='y', labelsize=6)
            fig.legend(loc='outside upper right', title='lba_type')
            ax.set_xlabel(x_axis)
            ax.set_ylabel(y_axis)
            ax.set_title(f"{y_axis} vs. {x_axis}")

            for i in range(count):
                info = self.ui.marker_listWidget_4.item(i).text() # Input format: X/Y value
                color = self.ui.marker_listWidget_4.item(i).foreground().color().name()
                pattern = r"(x|y)\((.*)\):\s*(\w*)\s+(\w*)"
                # Use regex to extract the components
                matches = re.search(pattern, info)

                if matches.group(1) == 'x':
                    ax.axvline(x = int(matches.group(3)), color=color, linestyle=matches.group(4))
                    ax.text(int(matches.group(3)), -.05, f'{matches.group(2)} : {matches.group(3)}', color='red', transform=ax.get_xaxis_transform(), 
                             ha='center', va='top')
                elif matches.group(1) == 'y':
                    ax.axhline(y = int(matches.group(3)), color=color, linestyle=matches.group(4))
                    ax.text(-.07 , int(matches.group(3)), f'{matches.group(2)} : {matches.group(3)}', color='red', transform=ax.get_yaxis_transform(), 
                             ha='center', va='top')
                else:
                    QtWidgets.QMessageBox.critical(self, "Error", "Input wrong Value or Attribute for marker")
                    return
                    
            # plt.show()
        else:
            if self.ui.plotBy4_2.isChecked():
                fig, (ax1,ax2) = plt.subplots(ncols=2, sharey=True, figsize=(15, 8)) # frameon=False removes frames
                # plt.subplots_adjust(hspace=.05)  

                ax1.grid(linestyle='--', linewidth=0.5)
                ax2.grid(linestyle='--', linewidth=0.5)

                ax1.scatter(x=self.subdata.loc[(self.subdata['label'] =='start_lba') & (self.subdata['op'] == 'READ'), x_axis], \
                               y=self.subdata.loc[(self.subdata['label'] =='start_lba') & (self.subdata['op'] == 'READ'), y_axis], \
                               c='red', s=0.1, label='start_lba')
                ax1.scatter(x=self.subdata.loc[(self.subdata['label'] =='end_lba') & (self.subdata['op'] == 'READ'), x_axis], \
                               y=self.subdata.loc[(self.subdata['label'] =='end_lba') & (self.subdata['op'] == 'READ'), y_axis], \
                               c='blue', s=0.1, label='end_lba')

                ax2.scatter(x=self.subdata.loc[(self.subdata['label'] =='start_lba') & (self.subdata['op'] == 'WRITE'), x_axis], \
                               y=self.subdata.loc[(self.subdata['label'] =='start_lba') & (self.subdata['op'] == 'WRITE'), y_axis], \
                               c='red', s=0.1, alpha=0.5, label='start_lba')
                ax2.scatter(x=self.subdata.loc[(self.subdata['label'] =='end_lba') & (self.subdata['op'] == 'WRITE'), x_axis], \
                               y=self.subdata.loc[(self.subdata['label'] =='end_lba') & (self.subdata['op'] == 'WRITE'), y_axis], \
                               c='blue', s=0.1, alpha=0.5, label='end_lba')   

                # plot1 = ax1.scatter(x=self.subdata.loc[self.subdata['op'] =='READ', self.x_axis], y=self.subdata.loc[self.subdata['op'] =='READ', self.y_axis], s=0.1, label='READ', c='crimson')
                # plot2 = ax2.scatter(x=self.subdata.loc[self.subdata['op'] =='WRITE', self.x_axis], y=self.subdata.loc[self.subdata['op'] =='WRITE', self.y_axis], s=0.1, label='dodgerblue')

                ax1.set_ylabel(y_axis)
                ax1.set_xlabel(x_axis)
                ax1.set_title("READ operation")
                ax2.set_xlabel(x_axis)
                ax2.set_title("WRITE operation")

                ax1.ticklabel_format(style='plain', axis='x')
                ax1.ticklabel_format(style='plain', axis='y')
                ax1.tick_params(axis='x', labelsize=6)
                ax1.tick_params(axis='y', labelsize=6)
                ax2.ticklabel_format(style='plain', axis='x')
                ax2.tick_params(axis='x', labelsize=6)

                # ax2.legend((plot1, plot2), ('Read', 'Write'))
                fig.legend(loc='outside upper right', title='lba_type')
                fig.suptitle(f"{y_axis} vs. {x_axis}")

                for i in range(count):
                    info = self.ui.marker_listWidget_4.item(i).text() # Input format: X/Y value
                    color = self.ui.marker_listWidget_4.item(i).foreground().color().name()
                    pattern = r"(x|y)\((.*)\):\s*(\w*)\s+(\w*)"
                    # Use regex to extract the components
                    matches = re.search(pattern, info)
                
                    if matches.group(1) == 'x':
                        ax1.axvline(x = int(matches.group(3)), color=color, linestyle=matches.group(4))
                        ax2.axvline(x = int(matches.group(3)), color=color, linestyle=matches.group(4))
                        ax1.text(float(matches.group(3)), -.05, f'{matches.group(2)} : {matches.group(3)}', color='red', transform=ax1.get_xaxis_transform(), 
                                ha='center', va='top')
                        ax2.text(float(matches.group(3)), -.05, f'{matches.group(2)} : {matches.group(3)}', color='red', transform=ax2.get_xaxis_transform(), 
                                ha='center', va='top')
                    elif matches.group(1) == 'y':
                        ax1.axhline(y = int(matches.group(3)), color=color, linestyle=matches.group(4))
                        ax2.axhline(y = int(matches.group(3)), color=color, linestyle=matches.group(4))
                        ax1.text(-.07 , float(matches.group(3)), f'{matches.group(2)} : {matches.group(3)}', color='red', transform=ax1.get_yaxis_transform(), 
                                ha='center', va='top')
                    else:
                        QtWidgets.QMessageBox.critical(self, "Error", "Input wrong value or attribute for marker")
                        return

                fig.tight_layout()
            
        plot_mdiarea(self.ui.mdiArea, fig, process_bar=self.ui.progressBar, status_label=self.ui.status_label)   
        # self.ui.figlistWidget.addItem(str(id(fig)))


    def addMarker1(self, list_widget, x_axis, y_axis, attr_1, attr_2, value, label, color, shape):
        """add marker for figure"""
        line_style_map = {
            "Solid": 'solid',
            "Dashed": 'dashed',
            "Dotted": 'dotted'
        }

        attr = None
        if attr_1.isChecked():
            attr = 'x'
        elif attr_2.isChecked():
            attr = 'y'
        else:
            QtWidgets.QMessageBox.critical(self, "Error", "Please select attribute first")
            return

        if value.text().isnumeric() or (value.text().count('.') == 1 and value.text().replace('.','').isdigit()):
                if label.text() != '':
                    tmp = attr + f'({label.text()})' + ':' + str(value.text() + f' {line_style_map[shape.currentText()]}')
                else:
                    if attr == 'x':
                        tmp = attr + f'({x_axis.currentText()})' + ':' + str(value.text() + f' {line_style_map[shape.currentText()]}')
                    else:
                        tmp = attr + f'({y_axis.currentText()})' + ':' + str(value.text() + f' {line_style_map[shape.currentText()]}')
                list_widget.addItem(tmp)
                list_widget.item(list_widget.count()-1).setForeground(QtGui.QColor(color.palette().color(QtGui.QPalette.Button).name()))
        else:
            QtWidgets.QMessageBox.critical(self, "Error", 
                                                "Please Enter the right value")


    def removeMarker(self, list_widget):
        """remove markers for list widget"""
        currentIndex = list_widget.currentRow()
        item = list_widget.item(currentIndex)
        if item is None:
            return
        question = QtWidgets.QMessageBox.question(self, "Remove Marker", 
                                                  "Do you want to remove marker?" + item.text(),
                                                  QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No)
        if question == QtWidgets.QMessageBox.Yes:
            item = list_widget.takeItem(currentIndex)
            del item


    def color_picker(self, line_color):
        """change line color"""
        color = QtWidgets.QColorDialog.getColor()
        line_color.setStyleSheet("QPushButton{background-color: %s}" %color.name())

    def check_plot_option(self):
        """check function option and execute them"""
        if self.clicked_func1:
            title = f"{self.filepath[:-4]}_filter_{self.ui.slba_lineEdit_1.text()}_{self.ui.elba_lineEdit_1.text()}_{self.ui.spoh_lineEdit_1.text()}_{self.ui.epoh_lineEdit_1.text()}.csv"
            self.save_csv(self.ui.save_radioBtn_1, title)
        elif self.clicked_func2:
            title = f"{self.filepath[:-4]}_start_lba_freq_more_than_100.csv"
            self.save_csv(self.ui.save_radioBtn_2, title)
            show_df_mdiarea(self.ui.mdiArea, self.subdata.head(int(self.ui.top_n_2.text())), f"Top {self.ui.top_n_2.text()} most accessed")
            if self.ui.show_hist_2.isChecked():
                self.count_dist()
        elif self.clicked_func3:
            title = f"{self.filepath[:-4]}_delta_ave_time_{self.ui.lba_lineEdit_3.text()}_{self.ui.spoh_lineEdit_3.text()}_{self.ui.epoh_lineEdit_3.text()}.csv"
            self.save_csv(self.ui.save_radioBtn_3, title)
            if self.ui.stat_func.isChecked():
                self.delta_access_time_stats(lba = str2num(self.ui.lba_lineEdit_3))
            if self.ui.cdf_plot.isChecked():
                self.delta_time_cdf()
            if self.ui.hist_plot.isChecked():
                self.delta_time_hist()
            if self.ui.joint_plot.isChecked():
                self.delta_time_jointplot(lba = str2num(self.ui.lba_lineEdit_3))
        elif self.clicked_func4:
            if self.clicked_func4:
                title = f"{self.filepath[:-4]}_stacked_{self.ui.slba_lineEdit_4.text()}_{self.ui.elba_lineEdit_4.text()}_POH_{self.ui.spoh_lineEdit_4.text()}_{self.ui.epoh_lineEdit_4.text()}.csv"
                self.save_csv(self.ui.save_radioBtn_4, title)
            if self.ui.show_data_4.isChecked():
                show_df_mdiarea(self.ui.mdiArea, self.subdata.head(1000), f"Top 1000 data")


    def save_csv(self, save_button, title):
        """check function option and execute them"""
        if save_button.isChecked():
            self.subdata.to_csv(title, index=False)

    def changestatus(self, true_one):
        """keep data security when switching function"""
        self.clicked_func1 = (1==true_one)
        self.clicked_func2 = (2==true_one)
        self.clicked_func3 = (3==true_one)
        self.clicked_func4 = (4==true_one)


    def clean_subwindow(self):
        """free memory for the mdiarea"""
        subwindows = self.ui.mdiArea.subWindowList()
        for subwindow in subwindows:
            subwindow.close()
            self.ui.mdiArea.removeSubWindow(subwindow)
            subwindow.deleteLater()


    def first_click(self, dataset, axes=None, start_lba=None, end_lba=None, lba=None, start_poh=None, end_poh=None, x_axis=None, y_axis=None, plot_kind=None, option=None, funcindex=None, \
                    saveOrnot=None, title=None, path1=None, state=None):
        """
        Directly plot data of the first click on widgets
        start_lba, end_lba, start_poh, end_poh are all preprocessed
        """
        raw_schema = dataset.schema.names

        ms_tran = 60*60*1000
        if state == 1: ## New attempt to get result and canvas
            if lba is None:
                filter1 = (pc.field("start_lba") >= start_lba) & (pc.field("start_lba") <= end_lba) & (pc.field("time(ms)") >= start_poh * ms_tran) \
                    & (pc.field("time(ms)") <= end_poh * ms_tran)
            else:
                filter1 = (pc.field("start_lba") == lba) & (pc.field("time(ms)") >= start_poh * ms_tran) \
                    & (pc.field("time(ms)") <= end_poh * ms_tran)
            
            ## check function and save data in csv file
            if funcindex == 1:
                ## write file with chunks
                if saveOrnot:
                    hasHeader = False
                    for batch in dataset.to_batches(filter=filter1):
                        tmp = batch.to_pandas()
                        if 'poh' not in raw_schema or 'POH' not in raw_schema: # Add poh 
                            tmp['poh'] = tmp['time(ms)'] / ms_tran
                        if len(tmp) > 0:
                            if not hasHeader:
                                tmp.to_csv(path1, index=False)
                                hasHeader =True
                            else:
                                tmp.to_csv(path1, index=False, header=False, mode='a')
                ans = dataset.take([i for i in range(1000)],filter=filter1)
            elif funcindex == 2:
                count_limit = 100
                expr = pa.compute.field("start_lba_count") >= count_limit
                ans = dataset.to_table(columns=['start_lba'], filter=filter1).group_by("start_lba").aggregate([("start_lba", "count")]).filter(expr).sort_by([('start_lba_count', "descending")])
                if saveOrnot:
                    ans.to_pandas().to_csv(path1, index=False)
            elif funcindex == 3:
                pass
            elif funcindex == 4:
                pass

            ## Plot data
            if isinstance(plot_kind, list):
                for i in range(len(plot_kind)):
                    ## plot type
                    if plot_kind[i] == 'scatter': # draw scatter step by step
                        if isinstance(axes[i], np.ndarray): ## split plot and always plot read operation first
                            if option != 2: # Option 2 means read operation only
                                new_filter = (pc.field("op") =='WRITE') & filter1
                                if x_axis[i] in raw_schema and y_axis[i] in raw_schema:
                                    x = dataset.to_table(columns=[x_axis[i]], filter=new_filter).column(x_axis[i]).to_numpy()
                                    y = dataset.to_table(columns=[y_axis[i]], filter=new_filter).column(y_axis[i]).to_numpy()
                                elif x_axis[i] not in raw_schema and y_axis[i] in raw_schema:
                                    x = transfer_feature(dataset=dataset, filter=new_filter, feature=x_axis[i])
                                    y = dataset.to_table(columns=[y_axis[i]], filter=new_filter).column(y_axis[i]).to_numpy()
                                elif y_axis[i] not in raw_schema and x_axis[i] in raw_schema:
                                    x = dataset.to_table(columns=[x_axis[i]], filter=new_filter).column(x_axis[i]).to_numpy()
                                    y = transfer_feature(dataset=dataset, filter=new_filter, feature=y_axis[i])
                                else:
                                    x = transfer_feature(dataset=dataset, filter=new_filter, feature=x_axis[i])
                                    y = transfer_feature(dataset=dataset, filter=new_filter, feature=y_axis[i])
                                axes[i][1].scatter(x=x, y=y,c='#1f77b4', s=0.1) 
                            if option != 3: # Option 3 means write operation only
                                new_filter = (pc.field("op") =='READ') & filter1
                                if x_axis[i] in raw_schema and y_axis[i] in raw_schema:
                                    x = dataset.to_table(columns=[x_axis[i]], filter=new_filter).column(x_axis[i]).to_numpy()
                                    y = dataset.to_table(columns=[y_axis[i]], filter=new_filter).column(y_axis[i]).to_numpy()
                                elif x_axis[i] not in raw_schema and y_axis[i] in raw_schema:
                                    x = transfer_feature(dataset=dataset, filter=new_filter, feature=x_axis[i])
                                    y = dataset.to_table(columns=[y_axis[i]], filter=new_filter).column(y_axis[i]).to_numpy()
                                elif y_axis[i] not in raw_schema and x_axis[i] in raw_schema:
                                    x = dataset.to_table(columns=[x_axis[i]], filter=new_filter).column(x_axis[i]).to_numpy()
                                    y = transfer_feature(dataset=dataset, filter=new_filter, feature=y_axis[i])
                                else:
                                    x = transfer_feature(dataset=dataset, filter=new_filter, feature=x_axis[i])
                                    y = transfer_feature(dataset=dataset, filter=new_filter, feature=y_axis[i])
                                axes[i][0].scatter(x=x, y=y,c='#ff7f0e', s=0.1)
                        else: # jointplot
                            if option != 2: # Option 2 means read operation only
                                new_filter = (pc.field("op") =='WRITE') & filter1
                                if x_axis[i] in raw_schema and y_axis[i] in raw_schema:
                                    x = dataset.to_table(columns=[x_axis[i]], filter=new_filter).column(x_axis[i]).to_numpy()
                                    y = dataset.to_table(columns=[y_axis[i]], filter=new_filter).column(y_axis[i]).to_numpy()
                                elif x_axis[i] not in raw_schema and y_axis[i] in raw_schema:
                                    x = transfer_feature(dataset=dataset, filter=new_filter, feature=x_axis[i])
                                    y = dataset.to_table(columns=[y_axis[i]], filter=new_filter).column(y_axis[i]).to_numpy()
                                elif y_axis[i] not in raw_schema and x_axis[i] in raw_schema:
                                    x = dataset.to_table(columns=[x_axis[i]], filter=new_filter).column(x_axis[i]).to_numpy()
                                    y = transfer_feature(dataset=dataset, filter=new_filter, feature=y_axis[i])
                                else:
                                    x = transfer_feature(dataset=dataset, filter=new_filter, feature=x_axis[i])
                                    y = transfer_feature(dataset=dataset, filter=new_filter, feature=y_axis[i])
                                axes[i].scatter(x=x, y=y,c='#1f77b4', s=0.1)
                            if option != 3: # Option 3 means write operation only
                                new_filter = (pc.field("op") =='READ') & filter1
                                if x_axis[i] in raw_schema and y_axis[i] in raw_schema:
                                    x = dataset.to_table(columns=[x_axis[i]], filter=new_filter).column(x_axis[i]).to_numpy()
                                    y = dataset.to_table(columns=[y_axis[i]], filter=new_filter).column(y_axis[i]).to_numpy()
                                elif x_axis[i] not in raw_schema and y_axis[i] in raw_schema:
                                    x = transfer_feature(dataset=dataset, filter=new_filter, feature=x_axis[i])
                                    y = dataset.to_table(columns=[y_axis[i]], filter=new_filter).column(y_axis[i]).to_numpy()
                                elif y_axis[i] not in raw_schema and x_axis[i] in raw_schema:
                                    x = dataset.to_table(columns=[x_axis[i]], filter=new_filter).column(x_axis[i]).to_numpy()
                                    y = transfer_feature(dataset=dataset, filter=new_filter, feature=y_axis[i])
                                else:
                                    x = transfer_feature(dataset=dataset, filter=new_filter, feature=x_axis[i])
                                    y = transfer_feature(dataset=dataset, filter=new_filter, feature=y_axis[i])
                                axes[i].scatter(x=x, y=y,c='#ff7f0e', s=0.1)
                                
                    elif plot_kind[i] == 'histogram':
                        axes[i].hist(dataset.to_table(columns=[x_axis[i]], filter=filter1), bins=int(500), histtype='barstacked', color='teal', rwidth=0.9)
                        axes[i].figure.canvas.draw() # draw the canvas
                    elif plot_kind[i] == 'jointplot':
                        pass
                    elif plot_kind[i] == 'cdf':
                        pass
                    elif plot_kind[i] == 'statistic':
                        pass
            
            ## Add Marker marker

        elif state == 2: # only change canvas
            pass
        
        
        return ans
    
    def sub_thread(self, switch_widget):
        plt.close("all")
        if switch_widget:
            self.clean_subwindow()
        # self.subdata = pd.DataFrame() # clean dataframe

        pass

    def sub_thread_plot(self, axes=None, start_lba=None, end_lba=None, start_poh=None, end_poh=None, lba=None, x_axis=None, y_axis=None, plot_kind=None, option=None, funcindex=None, \
                        saveOrnot=True, title=None, path1=None, state=None):
        # Pass the function to execute
        self.ui.progressBar.setValue(0)
        self.updatepgb.start(500)
        worker = Worker(fn = self.first_click, dataset=self.dataset, axes=axes, start_lba=start_lba, end_lba=end_lba, start_poh=start_poh, end_poh=end_poh, lba=lba, \
                        x_axis=x_axis, y_axis=y_axis, plot_kind=plot_kind, option=option, funcindex=funcindex, saveOrnot=saveOrnot, title=title, path1=path1, state=state) # Any other args, kwargs are passed to the run function
        # worker.signals.result.connect(self.print_output)
        worker.signals.finished.connect(lambda: self.thread_complete(funcindex=funcindex))
        worker.signals.error.connect(self.thread_error)
        
        # Execute
        self.threadpool.start(worker)

    def sub_thread_parse(self):
        pass

    def update_progressbar(self):
        if self.ui.progressBar.value() <= 90:
            self.ui.progressBar.setValue(self.ui.progressBar.value()+1)

    def thread_complete(self, funcindex):
        if os.path.exists("buffer.parquet"):
            # self.result = ds.dataset('buffer.parquet')
            if funcindex == 2:
                self.result = pq.read_table('buffer.parquet').to_pandas().head(int(self.ui.top_n_2.text().strip()))
                show_df_mdiarea(self.ui.mdiArea, self.result, f"Top {self.ui.top_n_2.text()} most accessed")
            else:
                self.result = pq.read_table('buffer.parquet').to_pandas().head(100)
        
        self.updatepgb.stop()
        self.ui.progressBar.setValue(100)
        
    def thread_error(self):
        self.ui.progressBar.setValue(0) 
        question = QtWidgets.QMessageBox.critical(self, "Error", 
                                                  "Previous step occurs error. Please check again.")

    def applyButtonStyle(self):
        for w in self.ui.leftMenuSubContainer.findChildren(QPushButton):
            if w.objectName() != self.sender().objectName():
                w.setStyleSheet("")
        
        self.sender().setStyleSheet("background-color: rgb(140, 207, 103);")

    def return_path(self):
        path1 = os.path.dirname(self.filepath)
        path2 = os.path.splitext(os.path.basename(self.filepath))[0]
        return path1 + '/' + path2 
    
    def update_xy_axis(self):
        self.ui.x_axis_comboBox_1.addItems(['--Select X axis--'] + SCHEMA1)
        self.ui.x_axis_comboBox_4.addItems(['--Select X axis--'] + SCHEMA4)
        self.ui.y_axis_comboBox_1.addItems(['--Select Y axis--'] + SCHEMA1)
        self.ui.y_axis_comboBox_4.addItems(['--Select Y axis--'] + SCHEMA4)

if __name__=="__main__":
    try:
        if os.path.exists('WLTFrameHeader.txt'):
            os.remove('WLTFrameHeader.txt')
        if os.path.exists('WLTMasterFrameHeader.txt'):
            os.remove('WLTMasterFrameHeader.txt')

        app = QApplication(sys.argv)
        UIWindow = WLT_MainWindow()
        app.exec_()
    finally:
        # print(os.getcwd())
        if os.path.exists("buffer.parquet"):
            os.remove("buffer.parquet")