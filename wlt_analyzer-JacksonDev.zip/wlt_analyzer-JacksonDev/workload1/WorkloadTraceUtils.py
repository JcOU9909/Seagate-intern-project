import sys, os
from .PlatformCStructs import *

# ------------------------
# STRUCTURE definitions
# ------------------------
class wltr_common_master_frame_header(c_struct):
    DefinitionText = """
        uint64         DriveSerialNum;
        uint64         TimeStampOfLastSavedFrame;
        uint32         WltrMasterFrameSignature;
        uint32         WltrDiscFileSizeInBytes;
        uint32         NextFrameOffsetInBytes;
        uint32         PrevFrameOffsetInBytes;
        uint32         TotalFrameSizeInBytes;
        """
    def __init__(self, Data=None ):
         c_struct.__init__(self, Data)


class wltr_master_frame_header(c_struct):
    DefinitionText = """
        uint64         DriveSerialNum;
        uint64         TimeStampOfLastSavedFrame;
        uint32         WltrMasterFrameSignature;
        uint32         WltrDiscFileSizeInBytes;
        uint32         NextFrameOffsetInBytes;
        uint32         PrevFrameOffsetInBytes;
        uint32         TotalFrameSizeInBytes;
        uint32         MaxStickyReadsIopsThisCycle;
        uint32         MaxStickyWritesIopsThisCycle;
        uint32         LeastBusyReadStickyFrameIops;
        uint32         LeastBusyWriteStickyFrameIops;
        uint32         BusiestReadStickyFrameIops;
        uint32         BusiestWriteStickyFrameIops;
        uint32         BestStickyReadFrameOffset;
        uint32         BestStickyWriteFrameOffset;
        uint32         TraceRecordingIntervalPowerOnTimeInMinutes;
        uint32         LastCycleCompletedPowerOnTimeInMinutes;
        uint16         NumOfFrames;
        uint16         DefaultSectorSizeInBytes;
        uint16         CycleCount;
        uint8          CurrentStep;
        uint8          IndexOfLastSavedReadStickyFrame;
        uint8          IndexOfLastSavedWriteStickyFrame;
        uint8          IndexOfBusiestReadStickyFrame;
        uint8          IndexOfBusiestWriteStickyFrame;
        uint8          IndexOfLeastBusyReadStickyFrame;
        uint8          IndexOfLeastBusyWriteStickyFrame;
        uint8          Heads;
        uint8          StickyFramesCount;
        uint8          StickyFramesSavedCount;
        uint8          Reserved1;
        uint8          Reserved2;
        uint8          Reserved3;
        uint8          Reserved4;
        """
    def __init__(self, Data=None):
        c_struct.__init__(self, Data)



class  wltr_master_frame_header_legacy(c_struct):
    DefinitionText = """
         uint64         DriveSerialNum;
         uint64         TimeStampOfLastSavedFrame;
         uint32         WltrMasterFrameSignature;
         uint32         WltrDiscFileSizeInBytes;
         uint32         NextFrameOffsetInBytes;
         uint32         PrevFrameOffsetInBytes;
         uint32         TotalFrameSizeInBytes;
         uint32         MaxStickyReadsIopsThisCycle;
         uint32         MaxStickyWritesIopsThisCycle;
         uint32         BestStickyReadFrameOffset;
         uint32         BestStickyWriteFrameOffset;
         uint32         TraceRecordingIntervalPowerOnTimeInMinutes;
         uint32         LastCycleCompletedPowerOnTimeInMinutes;
         uint16         NumOfFrames;
         uint16         DefaultSectorSizeInBytes;
         uint16         CycleCount;
         uint8          CurrentStep;
         uint8          IndexOfLastSavedReadStickyFrame;
         uint8          IndexOfLastSavedWriteStickyFrame;
         uint8          Heads;
         uint8          StickyFramesCount;
         uint8          Reserved1;
         """
    def __init__(self, Data=None ):
         c_struct.__init__(self, Data)

class wltr_master_frame_header_with_sticky_frames(c_struct):
    DefinitionText = """
        uint64         DriveSerialNum;
        uint64         TimeStampOfLastSavedFrame;
        uint32         WltrMasterFrameSignature;
        uint32         WltrDiscFileSizeInBytes;
        uint32         NextFrameOffsetInBytes;
        uint32         PrevFrameOffsetInBytes;
        uint32         TotalFrameSizeInBytes;
        uint32         MaxStickyReadsIopsThisCycle;
        uint32         MaxStickyWritesIopsThisCycle;
        uint32         LeastBusyReadStickyFrameIops;
        uint32         LeastBusyWriteStickyFrameIops;
        uint32         BusiestReadStickyFrameIops;
        uint32         BusiestWriteStickyFrameIops;
        uint32         BestStickyReadFrameOffset;
        uint32         BestStickyWriteFrameOffset;
        uint32         TraceRecordingIntervalPowerOnTimeInMinutes;
        uint32         LastCycleCompletedPowerOnTimeInMinutes;
        uint16         NumOfFrames;
        uint16         DefaultSectorSizeInBytes;
        uint16         CycleCount;
        uint8          CurrentStep;
        uint8          IndexOfLastSavedReadStickyFrame;
        uint8          IndexOfLastSavedWriteStickyFrame;
        uint8          IndexOfBusiestReadStickyFrame;
        uint8          IndexOfBusiestWriteStickyFrame;
        uint8          IndexOfLeastBusyReadStickyFrame;
        uint8          IndexOfLeastBusyWriteStickyFrame;
        uint8          Heads;
        uint8          StickyFramesCount;
        uint8          StickyFramesSavedCount;
        uint8          Reserved;
        uint8          Reserved;
        uint8          Reserved;
        uint8          Reserved;
        uint32         StickyReadFrameIops0;
        uint32         StickyReadFrameIops1;
        uint32         StickyReadFrameIops2;
        uint32         StickyReadFrameIops3;
        uint32         StickyReadFrameIops4;
        uint32         StickyReadFrameIops5;
        uint32         StickyReadFrameIops6;
        uint32         StickyReadFrameIops7;
        uint32         StickyReadFrameIops8;
        uint32         StickyReadFrameIops9;
        uint32         StickyReadFrameIops10;
        uint32         StickyReadFrameIops11;
        uint32         StickyReadFrameIops12;
        uint32         StickyReadFrameIops13;
        uint32         StickyReadFrameIops14;
        uint32         StickyReadFrameIops15;
        uint32         StickyReadFrameIops16;
        uint32         StickyReadFrameIops17;
        uint32         StickyReadFrameIops18;
        uint32         StickyReadFrameIops19;
        uint32         StickyReadFrameIops20;
        uint32         StickyReadFrameIops21;
        uint32         StickyReadFrameIops22;
        uint32         StickyReadFrameIops23;
        uint32         StickyReadFrameIops24;
        uint32         StickyReadFrameIops25;
        uint32         StickyReadFrameIops26;
        uint32         StickyReadFrameIops27;
        uint32         StickyReadFrameIops28;
        uint32         StickyReadFrameIops29;
        uint32         StickyReadFrameIops30;
        uint32         StickyReadFrameIops31;
        uint32         StickyReadFrameIops32;
        uint32         StickyReadFrameIops33;
        uint32         StickyReadFrameIops34;
        uint32         StickyReadFrameIops35;
        uint32         StickyReadFrameIops36;
        uint32         StickyReadFrameIops37;
        uint32         StickyReadFrameIops38;
        uint32         StickyReadFrameIops39;
        uint32         StickyReadFrameIops40;
        uint32         StickyReadFrameIops41;
        uint32         StickyReadFrameIops42;
        uint32         StickyReadFrameIops43;
        uint32         StickyReadFrameIops44;
        uint32         StickyReadFrameIops45;
        uint32         StickyReadFrameIops46;
        uint32         StickyReadFrameIops47;
        uint32         StickyReadFrameIops48;
        uint32         StickyReadFrameIops49;
        uint32         StickyWriteFrameIops0;
        uint32         StickyWriteFrameIops1;
        uint32         StickyWriteFrameIops2;
        uint32         StickyWriteFrameIops3;
        uint32         StickyWriteFrameIops4;
        uint32         StickyWriteFrameIops5;
        uint32         StickyWriteFrameIops6;
        uint32         StickyWriteFrameIops7;
        uint32         StickyWriteFrameIops8;
        uint32         StickyWriteFrameIops9;
        uint32         StickyWriteFrameIops10;
        uint32         StickyWriteFrameIops11;
        uint32         StickyWriteFrameIops12;
        uint32         StickyWriteFrameIops13;
        uint32         StickyWriteFrameIops14;
        uint32         StickyWriteFrameIops15;
        uint32         StickyWriteFrameIops16;
        uint32         StickyWriteFrameIops17;
        uint32         StickyWriteFrameIops18;
        uint32         StickyWriteFrameIops19;
        uint32         StickyWriteFrameIops20;
        uint32         StickyWriteFrameIops21;
        uint32         StickyWriteFrameIops22;
        uint32         StickyWriteFrameIops23;
        uint32         StickyWriteFrameIops24;
        uint32         StickyWriteFrameIops25;
        uint32         StickyWriteFrameIops26;
        uint32         StickyWriteFrameIops27;
        uint32         StickyWriteFrameIops28;
        uint32         StickyWriteFrameIops29;
        uint32         StickyWriteFrameIops30;
        uint32         StickyWriteFrameIops31;
        uint32         StickyWriteFrameIops32;
        uint32         StickyWriteFrameIops33;
        uint32         StickyWriteFrameIops34;
        uint32         StickyWriteFrameIops35;
        uint32         StickyWriteFrameIops36;
        uint32         StickyWriteFrameIops37;
        uint32         StickyWriteFrameIops38;
        uint32         StickyWriteFrameIops39;
        uint32         StickyWriteFrameIops40;
        uint32         StickyWriteFrameIops41;
        uint32         StickyWriteFrameIops42;
        uint32         StickyWriteFrameIops43;
        uint32         StickyWriteFrameIops44;
        uint32         StickyWriteFrameIops45;
        uint32         StickyWriteFrameIops46;
        uint32         StickyWriteFrameIops47;
        uint32         StickyWriteFrameIops48;
        uint32         StickyWriteFrameIops49;
        """
    def __init__(self, Data=None ):
         c_struct.__init__(self, Data)

class  wltr_dataflow_master_frame_header(c_struct):
    DefinitionText = """
         uint64         DriveSerialNum;
         uint64         TimeStampOfLastSavedFrame;
         uint32         WltrMasterFrameSignature;
         uint32         WltrDiscFileSizeInBytes;
         uint32         NextFrameOffsetInBytes;
         uint32         PrevFrameOffsetInBytes;
         uint32         TotalFrameSizeInBytes;
         uint16         NumOfFrames;
         uint16         DefaultSectorSizeInBytes;
         uint16         CycleCount;
         uint8          CurrentStep;
         uint8          Heads;
         uint8          Pad1;
         uint8          Pad2;
         uint8          Pad3;
         uint8          Pad4;
         """
    def __init__(self, Data=None ):
         c_struct.__init__(self, Data)



# 1/22/18 add WrapLocation, TotalNumberOfEvents, divide Pad into two uint8 for Session and Mode, length = 60#/3Ch
class  wltr_frame_header(c_struct):
    DefinitionText = """
        uint32         WltrFrameSignature;
        uint16         FrameNum;
        uint16         Revision;
        uint64         StartTimestamp;
        uint64         EndTimestamp;
        uint32         PrevFrameOffsetInBytes;
        uint16         CycleCount;
        uint8          Session;
        uint8          Mode;
        uint32         FrameSizeInBytes;
        uint32         DurationOfThisFrame;
        uint32         ReadsThisFrame;
        uint32         WritesThisFrame;
        uint32         OneSecondMarkersThisFrame;
        uint32         WrapLocation;
        uint32         TotalNumberOfEvents;
        """
    def __init__(self, Data=None ):
        c_struct.__init__(self, Data)

# Length is 44#/2Ch
class  wltr_dataflow_frame_header(c_struct):
    DefinitionText = """
         uint32         WltrFrameSignature;
         uint16         FrameNum;
         uint16         Revision;
         uint64         StartTimestamp;
         uint64         EndTimestamp;
         uint32         PrevFrameOffsetInBytes;
         uint16         CycleCount;
         uint16         Pad1;
         uint32         FrameSizeInBytes;
         uint32         DurationOfThisFrame;
         uint32         OneSecondMarkersThisFrame;
         """
    def __init__(self, Data=None):
        c_struct.__init__(self, Data)



class  wltr_frame_footer(c_struct):
    DefinitionText = """
         uint32         WltrFrameSignature;
         uint16         Pad1;
         uint16         FrameNum;
         """
    def __init__(self, Data=None ):
        c_struct.__init__(self, Data)

     #1/21/18 added
class  wltr_cdb_info(c_struct):
    DefinitionText = """
        uint16     Header;
        uint16     Feature;
        uint16     Count;
        uint8      DeviceHead;
        uint8      CommandField;
        uint64     TimestampInMicroseconds;
        uint64     LBA;
        uint8      InfoBits1;
        uint8      InfoBits2;
        uint8      QDepth;
        uint8      Tag;
        uint32     Reserved2;
         """
    def __init__(self, Data=None ):
        c_struct.__init__(self, Data)


# -------------------------------
# Frame Header/Footer Signatures
# -------------------------------

WLTR_MASTER_FRAME_SIGNATURE         = 0x4F574C00 + M_ByteSizeOf( wltr_master_frame_header )                     #"LWO "
WLTR_MASTER_FRAME_SIGNATURE_STICKY  = 0x4F574C00 + M_ByteSizeOf( wltr_master_frame_header_with_sticky_frames )  #"LWO "
WLTR_MASTER_FRAME_SIGNATURE_LEGACY  = 0x4E574C00 + M_ByteSizeOf( wltr_master_frame_header_legacy )              #"HLWN"
WLTR_DF_MASTER_FRAME_SIGNATURE      = 0x44574C00 + M_ByteSizeOf( wltr_dataflow_master_frame_header )            #"LWD "

WLTR_FRAME_HEADER_SIGNATURE         = 0x57544800 + M_ByteSizeOf( wltr_frame_header )            #"HTW "
WLTR_DF_FRAME_HEADER_SIGNATURE      = 0x44544800 + M_ByteSizeOf( wltr_dataflow_frame_header )   #"HTD "

WLTR_FRAME_FOOTER_SIGNATURE         = 0x57544600 + M_ByteSizeOf( wltr_frame_footer )            #"FTW "
WLTR_DF_FRAME_FOOTER_SIGNATURE      = 0x44544600 + M_ByteSizeOf( wltr_frame_footer )            #"DFT "

IDBT_FRAME_SIGNATURE_SAS            = 0x57534800 + M_ByteSizeOf( wltr_frame_header )            #"HSW "
IDBT_FRAME_SIGNATURE_SATA           = 0x57544800 + M_ByteSizeOf( wltr_frame_header )            #"HTW "

TransferLengthArray             = [1, 2, 4, 8, 16, 32, 128, 256]
DataFlowTransferLengthArray     = [1, 2, 4, 8, 16, 32, 64, 128, 256]

WLTRStepStrings = [
   "UNINITIALIZED",
   "READY_TO_TRACE_COMMANDS",
   "REQUESTED_IDLE_ACCESS",
   "SAVING_FRAME_TO_DISC",
   "AWAIT_STICKY_FRAME_SAVE_TO_DISC",
   "DORMANT_TILL_NEXT_INTERVAL",
   "DISABLED_DUE_TO_UNRECOVERED_DISC_ERROR"
   "TRACING_PAUSE"
]



# --------------------------------------------------------------------------------------------
# WLTR Dataflow defines
# --------------------------------------------------------------------------------------------
WLTR_DF_DRAM_CACHE_VALIDATION       = 0x00
WLTR_DF_DRAM_CACHE_INVALIDATION     = 0x01
WLTR_DF_DRAM_CACHE_HIT              = 0x02
WLTR_DF_DRAM_CACHE_UPDATE           = 0x03
WLTR_DF_DRAM_CACHE_TRIM             = 0x04
WLTR_DF_DRAM_CACHE_MERGE            = 0x05
WLTR_DF_DRAM_CACHE_FREE             = 0x06
WLTR_DF_DISC_READ                   = 0x10
WLTR_DF_DISC_WRITE                  = 0x11
WLTR_DF_LPC_DISC_READ               = 0x12
WLTR_DF_LPC_DISC_COMPARE            = 0x13
WLTR_DF_LPC_DISC_WRITE              = 0x14
WLTR_DF_SKIPMASK_DISC_READ          = 0x15
WLTR_DF_SKIPMASK_DISC_WRITE         = 0x16
WLTR_DF_UNRECOVERED_ERROR           = 0x17
WLTR_DF_AUTO_REALLOCATION           = 0x18
WLTR_DF_ACTIVE_DISC_ABORTED         = 0x19
WLTR_DF_PENDING_DISC_RD_ABORTED     = 0x1A
WLTR_DF_PENDING_DISC_WR_ABORTED     = 0x1B
WLTR_DF_ATTACHED_HOST_READ          = 0x20
WLTR_DF_ATTACHED_HOST_WRITE         = 0x21
WLTR_DF_DETACHED_HOST_READ          = 0x22
WLTR_DF_DETACHED_HOST_WRITE         = 0x23
WLTR_DF_STREAM_START                = 0x24
WLTR_DF_STREAM_TERMINATION          = 0x25
WLTR_DF_LPC_HOST_READ               = 0x26
WLTR_DF_LPC_HOST_WRITE              = 0x27
WLTR_DF_ATTACHED_SKIP_HOST_READ     = 0x28
WLTR_DF_ATTACHED_SKIP_HOST_WRITE    = 0x29
WLTR_DF_DETACHED_SKIP_HOST_READ     = 0x2A
WLTR_DF_DETACHED_SKIP_HOST_WRITE    = 0x2B
WLTR_DF_ACTIVE_HOST_ABORTED         = 0x2C
WLTR_DF_MCMT_ADD                    = 0x30
WLTR_DF_MCMT_REMOVE                 = 0x31
WLTR_DF_MC_HIT                      = 0x32
WLTR_DF_MC_TRIM                     = 0x33
WLTR_DF_MCMM_FLUSH                  = 0x34
WLTR_DF_MC_ADD_MC_DATA              = 0x35
WLTR_DF_MC_REMOVE_MC_DATA           = 0x36
WLTR_DF_MCMM_FILL                   = 0x37
WLTR_DF_MC_ERROR_INJ_ID_0           = 0x3A
WLTR_DF_MC_ERROR_INJ_ID_1           = 0x3B
WLTR_DF_MC_ERROR_INJ_ID_2           = 0x3C
WLTR_DF_MC_ERROR_INJ_ID_3           = 0x3D
WLTR_DF_MC_ERROR_INJ_ID_4           = 0x3E
WLTR_DF_FLASH_CACHE_VALIDATION      = 0x40
WLTR_DF_FLASH_CACHE_INVALIDATION    = 0x41
WLTR_DF_FLASH_CACHE_HIT             = 0x42
WLTR_DF_CUSTOM_TRACE_0              = 0x50
WLTR_DF_CUSTOM_TRACE_1              = 0x51
WLTR_DF_CUSTOM_TRACE_2              = 0x52
WLTR_DF_CUSTOM_TRACE_3              = 0x53
WLTR_DF_CUSTOM_TRACE_4              = 0x54
WLTR_DF_CUSTOM_TRACE_5              = 0x55
WLTR_DF_CUSTOM_TRACE_6              = 0x56
WLTR_DF_CUSTOM_TRACE_7              = 0x57
WLTR_DF_CUSTOM_TRACE_8              = 0x58
WLTR_DF_CUSTOM_TRACE_9              = 0x59
WLTR_DF_CUSTOM_TRACE_A              = 0x5A
WLTR_DF_CUSTOM_TRACE_B              = 0x5B
WLTR_DF_CUSTOM_TRACE_C              = 0x5C
WLTR_DF_CUSTOM_TRACE_D              = 0x5D
WLTR_DF_CUSTOM_TRACE_E              = 0x5E
WLTR_DF_CUSTOM_TRACE_F              = 0x5F
WLTR_DF_REPEAT_LAST_ENTRY_1X        = 0xD0
WLTR_DF_REPEAT_LAST_ENTRY_16X       = 0xDF
WLTR_DF_REPEAT_LAST_ENCODING_1X     = 0xE0
WLTR_DF_REPEAT_LAST_ENCODING_16X    = 0xEF
WLTR_DF_ONE_SECOND_MARKER           = 0xF0
WLTR_DF_TRACE_HALTED                = 0xF1
WLTR_DF_ADDITIONAL_ENCODE_BYTE      = 0xFF
WLTR_DF_MAX_VALID_OPCODE            = WLTR_DF_CUSTOM_TRACE_F # Last valid non-special opcode


DataFlowOpCodeStrings = [
    "WLTR_DF_DRAM_CACHE_VALIDATION",       # 0x00
    "WLTR_DF_DRAM_CACHE_INVALIDATION",     # 0x01
    "WLTR_DF_DRAM_CACHE_HIT",              # 0x02
    "WLTR_DF_DRAM_CACHE_UPDATE",           # 0x03
    "WLTR_DF_DRAM_CACHE_TRIM",             # 0x04
    "WLTR_DF_DRAM_CACHE_MERGE",            # 0x05
    "WLTR_DF_DRAM_CACHE_FREE",             # 0x06
    0,0,0,0,0,0,0,0,0,                     # 0x07 - 0x0F
    "WLTR_DF_DISC_READ",                   # 0x10
    "WLTR_DF_DISC_WRITE",                  # 0x11
    "WLTR_DF_LPC_DISC_READ",               # 0x12
    "WLTR_DF_LPC_DISC_COMPARE",            # 0x13
    "WLTR_DF_LPC_DISC_WRITE",              # 0x14
    "WLTR_DF_SKIPMASK_DISC_READ",          # 0x15
    "WLTR_DF_SKIPMASK_DISC_WRITE",         # 0x16
    "WLTR_DF_UNRECOVERED_ERROR",           # 0x17
    "WLTR_DF_AUTO_REALLOCATION",           # 0x18
    "WLTR_DF_ACTIVE_DISC_ABORTED",         # 0x19
    "WLTR_DF_PENDING_DISC_RD_ABORTED",     # 0x1A
    "WLTR_DF_PENDING_DISC_WR_ABORTED",     # 0x1B
    0,0,0,0,                               # 0x1C - 0x1F
    "WLTR_DF_ATTACHED_HOST_READ",          # 0x20
    "WLTR_DF_ATTACHED_HOST_WRITE",         # 0x21
    "WLTR_DF_DETACHED_HOST_READ",          # 0x22
    "WLTR_DF_DETACHED_HOST_WRITE",         # 0x23
    "WLTR_DF_STREAM_START",                # 0x24
    "WLTR_DF_STREAM_TERMINATION",          # 0x25
    "WLTR_DF_LPC_HOST_READ",               # 0x26
    "WLTR_DF_LPC_HOST_WRITE",              # 0x27
    "WLTR_DF_ATTACHED_SKIP_HOST_READ",     # 0x28
    "WLTR_DF_ATTACHED_SKIP_HOST_WRITE",    # 0x29
    "WLTR_DF_DETACHED_SKIP_HOST_READ",     # 0x2A
    "WLTR_DF_DETACHED_SKIP_HOST_WRITE",    # 0x2B
    "WLTR_DF_ACTIVE_HOST_ABORTED",         # 0x2C
    0,0,0,                                 # 0x2D - 0x2F
    "WLTR_DF_MCMT_ADD",                    # 0x30
    "WLTR_DF_MCMT_REMOVE",                 # 0x31
    "WLTR_DF_MC_HIT",                      # 0x32
    "WLTR_DF_MC_TRIM",                     # 0x33
    "WLTR_DF_MCMM_FLUSH",                  # 0x34
    "WLTR_DF_MC_ADD_MC_DATA",              # 0x35
    "WLTR_DF_MC_REMOVE_MC_DATA",           # 0x36
    "WLTR_DF_MCMM_FILL",                   # 0x37
    0,0,                                   # 0x38 - 0x39
    "WLTR_DF_MC_ERROR_INJ_ID_0",           # 0x3A
    "WLTR_DF_MC_ERROR_INJ_ID_1",           # 0x3B
    "WLTR_DF_MC_ERROR_INJ_ID_2",           # 0x3C
    "WLTR_DF_MC_ERROR_INJ_ID_3",           # 0x3D
    "WLTR_DF_MC_ERROR_INJ_ID_4",           # 0x3E
    0,                                     # 0x3F
    "WLTR_DF_FLASH_CACHE_VALIDATION",      # 0x40
    "WLTR_DF_FLASH_CACHE_INVALIDATION",    # 0x41
    "WLTR_DF_FLASH_CACHE_HIT",             # 0x42
    0,0,0,0,0,0,0,0,0,0,0,0,0,             # 0x43 - 0x4F
    "WLTR_DF_CUSTOM_TRACE_0",              # 0x50
    "WLTR_DF_CUSTOM_TRACE_1",              # 0x51
    "WLTR_DF_CUSTOM_TRACE_2",              # 0x52
    "WLTR_DF_CUSTOM_TRACE_3",              # 0x53
    "WLTR_DF_CUSTOM_TRACE_4",              # 0x54
    "WLTR_DF_CUSTOM_TRACE_5",              # 0x55
    "WLTR_DF_CUSTOM_TRACE_6",              # 0x56
    "WLTR_DF_CUSTOM_TRACE_7",              # 0x57
    "WLTR_DF_CUSTOM_TRACE_8",              # 0x58
    "WLTR_DF_CUSTOM_TRACE_9",              # 0x59
    "WLTR_DF_CUSTOM_TRACE_A",              # 0x5A
    "WLTR_DF_CUSTOM_TRACE_B",              # 0x5B
    "WLTR_DF_CUSTOM_TRACE_C",              # 0x5C
    "WLTR_DF_CUSTOM_TRACE_D",              # 0x5D
    "WLTR_DF_CUSTOM_TRACE_E",              # 0x5E
    "WLTR_DF_CUSTOM_TRACE_F"               # 0x5F
]

OneSecondMarkerString = "ONE_SECOND_MARKER"

# TBD -- currently not used. For future expansion
DataFlowAdditionalOpCodeStrings = [
   ""
]

# LBA encoding definitions
WLTR_DF_LBA_MASK                    = 0xF0
WLTR_DF_LBA_FIELD_OFFSET            = 4
WLTR_DF_LBA_SIZE_BIT_MASK           = 0x70
WLTR_DF_LBA_SIZE_1_BYTE             = 0x10
WLTR_DF_LBA_SIZE_2_BYTES            = 0x20
WLTR_DF_LBA_SIZE_3_BYTES            = 0x30
WLTR_DF_LBA_SIZE_4_BYTES            = 0x40
WLTR_DF_LBA_SIZE_5_BYTES            = 0x50

WLTR_DF_LBA_SEQUENTIAL_TO_LAST_CMD  = 0x80
WLTR_DF_LBA_SAME_AS_LAST_CMD        = 0xC0

WLTR_DF_LBA_POS_OFFSET_BIT_MASK     = 0x80
WLTR_DF_LBA_NEG_OFFSET_BIT_MASK     = 0xC0
WLTR_DF_LBA_OFFSET_SIZE_MASK        = 0x30

WLTR_DF_LBA_1_BYTE_POS_OFFSET       = 0x90
WLTR_DF_LBA_2_BYTE_POS_OFFSET       = 0xA0
WLTR_DF_LBA_3_BYTE_POS_OFFSET       = 0xB0
WLTR_DF_LBA_1_BYTE_NEG_OFFSET       = 0xD0
WLTR_DF_LBA_2_BYTE_NEG_OFFSET       = 0xE0
WLTR_DF_LBA_3_BYTE_NEG_OFFSET       = 0xF0

# Xfr Length and miscellaneous encoding
WLTR_DF_XFR_LENGTH_MASK             = 0x0F
WLTR_DF_XL_SAME_AS_LAST             = 0x00
WLTR_DF_XL_VERBATIM_1_BYTE          = 0x01
WLTR_DF_XL_VERBATIM_2_BYTES         = 0x02
WLTR_DF_XL_VERBATIM_3_BYTES         = 0x03
WLTR_DF_XL_1_BLK                    = 0x04
WLTR_DF_XL_2_BLKS                   = 0x05
WLTR_DF_XL_4_BLKS                   = 0x06
WLTR_DF_XL_8_BLKS                   = 0x07
WLTR_DF_XL_16_BLKS                  = 0x08
WLTR_DF_XL_32_BLKS                  = 0x09
WLTR_DF_XL_64_BLKS                  = 0x0A
WLTR_DF_XL_128_BLKS                 = 0x0B
WLTR_DF_XL_256_BLKS                 = 0x0C
WLTR_DF_XL_SHIFT_1_BYTE             = 0x0D
WLTR_DF_XL_SHIFT_2_BYTES            = 0x0E
WLTR_DF_XL_INFINITE                 = 0x0F

# --------------------------------------------------------------------------------------------
# Classic WLTR defines
# --------------------------------------------------------------------------------------------
# Start Lba Encoding
WLTR_LBA_MASK                       = 0x03
ABSOLUTE_START_LBA                  = 0         #  NEGATIVE_OFFSET cleared
SINGLE_BYTE_OFFSET                  = 0x01
TWO_BYTE_OFFSET                     = 0x02
THREE_BYTE_OFFSET                   = 0x03
SEQUENTIAL_TO_LAST_CMD              = 0x04      #  NEGATIVE_OFFSET set
NEGATIVE_OFFSET                     = 0x04
WLTR_LBA_FIELD_MASK                 = 0x07
# ------------------------------------------------
# The following are not directly used anywhere
# but have been definedto add clarity to code
# ------------------------------------------------
SINGLE_BYTE_POSITIVE_OFFSET         = 0x01
TWO_BYTE_POSITIVE_OFFSET            = 0x02
THREE_BYTE_POSITIVE_OFFSET          = 0x03
SINGLE_BYTE_NEGATIVE_OFFSET         = 0x05
TWO_BYTE_NEGATIVE_OFFSET            = 0x06
THREE_BYTE_NEGATIVE_OFFSET          = 0x07
# ------------------------------------------------
LBA_INFO_MASK                       = 0x07
# Command type - Read/Write encoding
WRITE_COMMAND_TRACE                 = 0x08

# Xfr Length and miscellaneous encoding
WLTR_XFR_LENGTH_MASK                = 0xF0
ONE_BLOCK                           = 0
TWO_BLOCKS                          = 0x10
FOUR_BLOCKS                         = 0x20
EIGHT_BLOCKS                        = 0x30
SIXTEEN_BLOCKS                      = 0x40
THIRTY_TWO_BLOCKS                   = 0x50
ONE_HUNDRED_TWENTY_EIGHT            = 0x60
TWO_HUNDRED_FIFTY_SIXTY_BLOCKS      = 0x70
XFR_LENGTH_SAME_AS_LAST_CMD         = 0x80
VERBATIM_1_BYTE                     = 0x90
VERBATIM_2_BYTES                    = 0xA0
WLTR_RESERVED_1                     = 0xB0
WLTR_RESERVED_2                     = 0xC0
STREAMING_STARTED                   = 0xD0
STREAMING_TERMINATED                = 0xE0
XFR_LENGTH_EXTENSION                = 0x80

XFR_LENGTH_BIN_MASK_SHIFT_COUNT     = 4

ONE_SECOND_MARKER                   = WLTR_DF_ONE_SECOND_MARKER

# -------------------------------
# Globals
# -------------------------------
# Global counters
NUM_OP_CODES        = 0x100
NUM_LBA_CODES       = 0x10
NUM_XL_CODES        = 0x10
EntriesProcessed    = 0
BytesProcessed      = 0
OpCodeCounters      = [0 for i in range(NUM_OP_CODES)]
AdditionalOpCodeCounters = [0 for i in range(NUM_OP_CODES)]
LbaCodeCounters     = [0 for i in range(NUM_LBA_CODES)]
XLCodeCounters      = [0 for i in range(NUM_XL_CODES)]

# default value for opcode column width output
OpcodeColumnSize = 34

# default 5xxe display
HostBlocksPerDiscSector = 1

# Search range globals
SearchLBAValid  = 0
SearchLBAStart  = 0
SearchLBAEnd    = 0
LBAFoundInFrame = 0

def SetHostBlocksPerDiscSector( newVal ):
    global HostBlocksPerDiscSector
    HostBlocksPerDiscSector = newVal

def SetSearchLBARange( StartLBA, Length ):
    global SearchLBAStart, SearchLBAEnd, SearchLBAValid
    SearchLBAStart = StartLBA
    SearchLBAEnd   = StartLBA + Length
    SearchLBAValid = 1


def PrintGlobalCounters( DataFlowMode ):
    print("...EntriesProcessed   = {0}".format(EntriesProcessed))
    print("...BytesProcessed     = {0}".format(BytesProcessed))

    if EntriesProcessed > 0:
        BytesPerEntry = BytesProcessed / EntriesProcessed
        tempLongLong = (BytesProcessed - (BytesPerEntry * EntriesProcessed)) * 1000 / EntriesProcessed
        BytesPerEntryRemainder = tempLongLong

        print("...Byte(s) per Entry  = {0}.{1:03}".format(BytesPerEntry, BytesPerEntryRemainder))

    NumLbaCodes = NUM_LBA_CODES

    if ( DataFlowMode ):
        print("...OpCodeCounters:")
        for i in range(NUM_OP_CODES):
            if ( OpCodeCounters[i] > 0 ):
                print("   {0:02x}                 = {1}".format(i, OpCodeCounters[i]))
    else:
        print("...Rd/Wr Ops:")
        print("   READS              = {0}".format(OpCodeCounters[0]))
        print("   WRITES             = {0}".format(OpCodeCounters[1]))
        NumLbaCodes = 0x8
    print("...LbaCodeCounters:")
    for i in range(NumLbaCodes):
        print("   {0:1x}                  = {1}".format(i, LbaCodeCounters[i]))
    print("...XLCodeCounters:")
    for i in range(NUM_XL_CODES):
        print("   {0:1x}                  = {1}".format(i, XLCodeCounters[i]))

def FindLongestOpcodeString( ):
    global OpcodeColumnSize
    for word in DataFlowOpCodeStrings:
        if word:
            OpcodeColumnSize = max(OpcodeColumnSize, len(word)+2 )

def FilePrintf(File, string):
    if File:
        File.write(string)
    else:
        sys.stdout.write(string)

def PrintTimeStamp(TimeStampUint64, OutputFile=None):
    RawTimeInUs = (TimeStampUint64 & 0xFFFFFFFFFFFF)
    PowerCycleCount = (TimeStampUint64 & 0xFFFF000000000000) >> 48

    Hours   = RawTimeInUs / 1000 / 1000 / 60 / 60
    Min     = ( RawTimeInUs / (1000 * 1000 * 60) ) % 60
    Sec     = ( RawTimeInUs / (1000 * 1000) ) % 60
    Ms      = ( RawTimeInUs / 1000 ) % 1000
    Us      = RawTimeInUs % 1000

    FilePrintf( OutputFile, "PC: {0:4}, Timestamp: {1:4}:{2:2}:{3:2}.{4:03}_{5:03}\n".format(
        PowerCycleCount,
        Hours, Min, Sec, Ms, Us ) )

def PrintMasterFrameHeader( MasterFrameHeader, fp=None ):
    NonModulo200 = 0
    FilePrintf( fp, "=== Master Frame Header ===\n")
    FilePrintf( fp, "   DriveSerialNum                               {0}{1}{2}{3}{4}{5}{6}{7}\n".
                format(
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x00000000000000ff))),
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x000000000000ff00) >> 8)),
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x0000000000ff0000) >> 16)),
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x00000000ff000000) >> 24)),
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x000000ff00000000) >> 32)),
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x0000ff0000000000) >> 40)),
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x00ff000000000000) >> 48)),
                    str(chr((MasterFrameHeader.DriveSerialNum & 0xff00000000000000) >> 56))))
    FilePrintf( fp, "   TimeStampOfLastSavedFrame          ")
    PrintTimeStamp(MasterFrameHeader.TimeStampOfLastSavedFrame, fp)
    FilePrintf( fp, "   TimeStampOfLastSavedFrame (hours)            {0:f}\n".format((MasterFrameHeader.TimeStampOfLastSavedFrame & 0xFFFFFFFFFFFF)/3600000000.0))     #3/9/18
    FilePrintf( fp, "   TimeStampOfLastSavedFrame (us)               {0:f}\n".format(MasterFrameHeader.TimeStampOfLastSavedFrame & 0xFFFFFFFFFFFF))                    #3/9/18
    FilePrintf( fp, "   WltrMasterFrameSignature                     {0:8x}('{1}{2}{3}{4}')\n".format(
        (MasterFrameHeader.WltrMasterFrameSignature),
        str(chr((MasterFrameHeader.WltrMasterFrameSignature & 0xff000000) >> 24)),
        str(chr((MasterFrameHeader.WltrMasterFrameSignature & 0x00ff0000) >> 16)),
        str(chr((MasterFrameHeader.WltrMasterFrameSignature & 0x0000ff00) >> 8)),
        str(chr((MasterFrameHeader.WltrMasterFrameSignature & 0x000000ff) ))))
    FilePrintf( fp, "   WltrDiscFileSizeInBytes                      {0:08x}\n".format(MasterFrameHeader.WltrDiscFileSizeInBytes))
    FilePrintf( fp, "   NextFrameOffsetInBytes                       {0:08x}\n".format(MasterFrameHeader.NextFrameOffsetInBytes))
    if not MasterFrameHeader.NextFrameOffsetInBytes == 0:
        if MasterFrameHeader.NextFrameOffsetInBytes % 0x200 > 0:
            NonModulo200+=1
    FilePrintf( fp, "   PrevFrameOffsetInBytes                       {0:08x}\n".format(MasterFrameHeader.PrevFrameOffsetInBytes))
    if not MasterFrameHeader.PrevFrameOffsetInBytes == 0:
        if MasterFrameHeader.PrevFrameOffsetInBytes % 0x200 > 0:
            NonModulo200+=2
    FilePrintf( fp, "   TotalFrameSizeInBytes                        {0:08x}\n".format(MasterFrameHeader.TotalFrameSizeInBytes))
    #3/21/18 add filter for MFH Signature
    if ( (MasterFrameHeader.WltrMasterFrameSignature & 0xFFFFFC00 ) == (WLTR_MASTER_FRAME_SIGNATURE  & 0xFFFFFC00) ):
        FilePrintf( fp, "   MaxStickyReadsIopsThisCycle                  {0:08x}\n".format(MasterFrameHeader.MaxStickyReadsIopsThisCycle))
        FilePrintf( fp, "   MaxStickyWritesIopsThisCycle                 {0:08x}\n".format(MasterFrameHeader.MaxStickyWritesIopsThisCycle))
        FilePrintf( fp, "   LeastBusyReadStickyFrameIops                 {0:08x}\n".format(MasterFrameHeader.LeastBusyReadStickyFrameIops))
        FilePrintf( fp, "   LeastBusyWriteStickyFrameIops                {0:08x}\n".format(MasterFrameHeader.LeastBusyWriteStickyFrameIops))
        FilePrintf( fp, "   BusiestReadStickyFrameIops                   {0:08x}\n".format(MasterFrameHeader.BusiestReadStickyFrameIops))
        FilePrintf( fp, "   BusiestWriteStickyFrameIops                  {0:08x}\n".format(MasterFrameHeader.BusiestWriteStickyFrameIops))
        FilePrintf( fp, "   BestStickyReadFrameOffset                    {0:08x}\n".format(MasterFrameHeader.BestStickyReadFrameOffset))
        if not MasterFrameHeader.BestStickyReadFrameOffset == 0:
            if MasterFrameHeader.BestStickyReadFrameOffset % 0x200 > 0:
                NonModulo200+=4
        FilePrintf( fp, "   BestStickyWriteFrameOffset                   {0:08x}\n".format(MasterFrameHeader.BestStickyWriteFrameOffset))
        if not MasterFrameHeader.BestStickyWriteFrameOffset == 0:
            if MasterFrameHeader.BestStickyWriteFrameOffset % 0x200 > 0:
                NonModulo200+=8
        FilePrintf( fp, "   TraceRecordingIntervalPowerOnTimeInMinutes   {0:08x}\n".format(MasterFrameHeader.TraceRecordingIntervalPowerOnTimeInMinutes))
        FilePrintf( fp, "   LastCycleCompletedPowerOnTimeInMinutes       {0:08x}\n".format(MasterFrameHeader.LastCycleCompletedPowerOnTimeInMinutes))
        FilePrintf( fp, "   NumOfFrames                                  {0:04x}\n".format(MasterFrameHeader.NumOfFrames))
        FilePrintf( fp, "   DefaultSectorSizeInBytes                     {0:04x}\n".format(MasterFrameHeader.DefaultSectorSizeInBytes))
        FilePrintf( fp, "   CycleCount                                   {0:04x}\n".format(MasterFrameHeader.CycleCount))
        FilePrintf( fp, "   CurrentStep                                  {0:02x} ({1})\n".format(MasterFrameHeader.CurrentStep, WLTRStepStrings[MasterFrameHeader.CurrentStep]))
        FilePrintf( fp, "   IndexOfLastSavedReadStickyFrame              {0:02x}\n".format(MasterFrameHeader.IndexOfLastSavedReadStickyFrame))
        FilePrintf( fp, "   IndexOfLastSavedWriteStickyFrame             {0:02x}\n".format(MasterFrameHeader.IndexOfLastSavedWriteStickyFrame))
        FilePrintf( fp, "   IndexOfBusiestReadStickyFrame                {0:02x}\n".format(MasterFrameHeader.IndexOfBusiestReadStickyFrame))
        FilePrintf( fp, "   IndexOfBusiestWriteStickyFrame               {0:02x}\n".format(MasterFrameHeader.IndexOfBusiestWriteStickyFrame))
        FilePrintf( fp, "   IndexOfLeastBusyReadStickyFrame              {0:02x}\n".format(MasterFrameHeader.IndexOfLeastBusyReadStickyFrame))
        FilePrintf( fp, "   IndexOfLeastBusyWriteStickyFrame             {0:02x}\n".format(MasterFrameHeader.IndexOfLeastBusyWriteStickyFrame))
        FilePrintf( fp, "   Heads                                        {0:02x}\n".format(MasterFrameHeader.Heads))
        FilePrintf( fp, "   StickyFramesCount                            {0:02x}\n".format(MasterFrameHeader.StickyFramesCount))
        FilePrintf( fp, "   StickyFramesSavedCount                       {0:02x}\n".format(MasterFrameHeader.StickyFramesSavedCount))
    elif ( (MasterFrameHeader.WltrMasterFrameSignature & 0xFFFFFC00 ) == (WLTR_MASTER_FRAME_SIGNATURE_STICKY  & 0xFFFFFC00) ):      #3/21/18 add filter for MFH Signature
        FilePrintf( fp, "   MaxStickyReadsIopsThisCycle                  {0:08x}\n".format(MasterFrameHeader.MaxStickyReadsIopsThisCycle))
        FilePrintf( fp, "   MaxStickyWritesIopsThisCycle                 {0:08x}\n".format(MasterFrameHeader.MaxStickyWritesIopsThisCycle))
        FilePrintf( fp, "   LeastBusyReadStickyFrameIops                 {0:08x}\n".format(MasterFrameHeader.LeastBusyReadStickyFrameIops))
        FilePrintf( fp, "   LeastBusyWriteStickyFrameIops                {0:08x}\n".format(MasterFrameHeader.LeastBusyWriteStickyFrameIops))
        FilePrintf( fp, "   BusiestReadStickyFrameIops                   {0:08x}\n".format(MasterFrameHeader.BusiestReadStickyFrameIops))
        FilePrintf( fp, "   BusiestWriteStickyFrameIops                  {0:08x}\n".format(MasterFrameHeader.BusiestWriteStickyFrameIops))
        FilePrintf( fp, "   BestStickyReadFrameOffset                    {0:08x}\n".format(MasterFrameHeader.BestStickyReadFrameOffset))
        FilePrintf( fp, "   BestStickyWriteFrameOffset                   {0:08x}\n".format(MasterFrameHeader.BestStickyWriteFrameOffset))
        FilePrintf( fp, "   TraceRecordingIntervalPowerOnTimeInMinutes   {0:08x}\n".format(MasterFrameHeader.TraceRecordingIntervalPowerOnTimeInMinutes))
        FilePrintf( fp, "   LastCycleCompletedPowerOnTimeInMinutes       {0:08x}\n".format(MasterFrameHeader.LastCycleCompletedPowerOnTimeInMinutes))
        FilePrintf( fp, "   NumOfFrames                                  {0:04x}\n".format(MasterFrameHeader.NumOfFrames))
        FilePrintf( fp, "   DefaultSectorSizeInBytes                     {0:04x}\n".format(MasterFrameHeader.DefaultSectorSizeInBytes))
        FilePrintf( fp, "   CycleCount                                   {0:04x}\n".format(MasterFrameHeader.CycleCount))
        FilePrintf( fp, "   CurrentStep                                  {0:02x} ({1})\n".format(MasterFrameHeader.CurrentStep, WLTRStepStrings[MasterFrameHeader.CurrentStep]))
        FilePrintf( fp, "   IndexOfLastSavedReadStickyFrame              {0:02x}\n".format(MasterFrameHeader.IndexOfLastSavedReadStickyFrame))
        FilePrintf( fp, "   IndexOfLastSavedWriteStickyFrame             {0:02x}\n".format(MasterFrameHeader.IndexOfLastSavedWriteStickyFrame))
        FilePrintf( fp, "   IndexOfBusiestReadStickyFrame                {0:02x}\n".format(MasterFrameHeader.IndexOfBusiestReadStickyFrame))
        FilePrintf( fp, "   IndexOfBusiestWriteStickyFrame               {0:02x}\n".format(MasterFrameHeader.IndexOfBusiestWriteStickyFrame))
        FilePrintf( fp, "   IndexOfLeastBusyReadStickyFrame              {0:02x}\n".format(MasterFrameHeader.IndexOfLeastBusyReadStickyFrame))
        FilePrintf( fp, "   IndexOfLeastBusyWriteStickyFrame             {0:02x}\n".format(MasterFrameHeader.IndexOfLeastBusyWriteStickyFrame))
        FilePrintf( fp, "   Heads                                        {0:02x}\n".format(MasterFrameHeader.Heads))
        FilePrintf( fp, "   StickyFramesCount                            {0:02x}\n".format(MasterFrameHeader.StickyFramesCount))
        FilePrintf( fp, "   StickyFramesSavedCount                       {0:02x}\n".format(MasterFrameHeader.StickyFramesSavedCount))
    elif ( (MasterFrameHeader.WltrMasterFrameSignature & 0xFFFFFC00 ) == (WLTR_MASTER_FRAME_SIGNATURE_LEGACY & 0xFFFFFC00) ):      #3/21/18 add filter for MFH Signature
        FilePrintf( fp, "   MaxStickyReadsIopsThisCycle                  {0:08x}\n".format(MasterFrameHeader.MaxStickyReadsIopsThisCycle))
        FilePrintf( fp, "   MaxStickyWritesIopsThisCycle                 {0:08x}\n".format(MasterFrameHeader.MaxStickyWritesIopsThisCycle))
        FilePrintf( fp, "   BestStickyReadFrameOffset                    {0:08x}\n".format(MasterFrameHeader.BestStickyReadFrameOffset))
        FilePrintf( fp, "   BestStickyWriteFrameOffset                   {0:08x}\n".format(MasterFrameHeader.BestStickyWriteFrameOffset))
        FilePrintf( fp, "   TraceRecordingIntervalPowerOnTimeInMinutes   {0:08x}\n".format(MasterFrameHeader.TraceRecordingIntervalPowerOnTimeInMinutes))
        FilePrintf( fp, "   LastCycleCompletedPowerOnTimeInMinutes       {0:08x}\n".format(MasterFrameHeader.LastCycleCompletedPowerOnTimeInMinutes))
        FilePrintf( fp, "   NumOfFrames                                  {0:04x}\n".format(MasterFrameHeader.NumOfFrames))
        FilePrintf( fp, "   DefaultSectorSizeInBytes                     {0:04x}\n".format(MasterFrameHeader.DefaultSectorSizeInBytes))
        FilePrintf( fp, "   CycleCount                                   {0:04x}\n".format(MasterFrameHeader.CycleCount))
        FilePrintf( fp, "   CurrentStep                                  {0:02x} ({1})\n".format(MasterFrameHeader.CurrentStep, WLTRStepStrings[MasterFrameHeader.CurrentStep]))
        FilePrintf( fp, "   IndexOfLastSavedReadStickyFrame              {0:02x}\n".format(MasterFrameHeader.IndexOfLastSavedReadStickyFrame))
        FilePrintf( fp, "   IndexOfLastSavedWriteStickyFrame             {0:02x}\n".format(MasterFrameHeader.IndexOfLastSavedWriteStickyFrame))
        FilePrintf( fp, "   Heads                                        {0:02x}\n".format(MasterFrameHeader.Heads))
        FilePrintf( fp, "   StickyFramesCount                            {0:02x}\n".format(MasterFrameHeader.StickyFramesCount))
    elif ( (MasterFrameHeader.WltrMasterFrameSignature  & 0xFFFFFC00 )== (WLTR_DF_MASTER_FRAME_SIGNATURE & 0xFFFFFC00) ):          #3/21/18 add filter for MFH Signature
        FilePrintf( fp, "   NumOfFrames                                  {0:04x}\n".format(MasterFrameHeader.NumOfFrames))
        FilePrintf( fp, "   DefaultSectorSizeInBytes                     {0:04x}\n".format(MasterFrameHeader.DefaultSectorSizeInBytes))
        FilePrintf( fp, "   CycleCount                                   {0:04x}\n".format(MasterFrameHeader.CycleCount))
        FilePrintf( fp, "   CurrentStep                                  {0:02x} ({1})\n".format(MasterFrameHeader.CurrentStep, WLTRStepStrings[MasterFrameHeader.CurrentStep]))
        FilePrintf( fp, "   Heads                                        {0:02x}\n".format(MasterFrameHeader.Heads))
    return NonModulo200



def PrintMasterFrameHeaderSummary( MasterFrameHeader, fp=None ):
    # "=== Master Frame Header ===\n")
    FilePrintf( fp, "{0}{1}{2}{3}{4}{5}{6}{7},".
                format(
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x00000000000000ff))),
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x000000000000ff00) >> 8)),
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x0000000000ff0000) >> 16)),
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x00000000ff000000) >> 24)),
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x000000ff00000000) >> 32)),
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x0000ff0000000000) >> 40)),
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x00ff000000000000) >> 48)),
                    str(chr((MasterFrameHeader.DriveSerialNum & 0xff00000000000000) >> 56))))
    #FilePrintf( fp, "   TimeStampOfLastSavedFrame          ")
    #PrintTimeStamp(MasterFrameHeader.TimeStampOfLastSavedFrame, fp)
    FilePrintf( fp, "{0:f},".format((MasterFrameHeader.TimeStampOfLastSavedFrame & 0xFFFFFFFFFFFF)/3600000000.0))     #3/9/18
    FilePrintf( fp, "{0:8x}('{1}{2}{3}{4}'),".format(
        (MasterFrameHeader.WltrMasterFrameSignature),
        str(chr((MasterFrameHeader.WltrMasterFrameSignature & 0xff000000) >> 24)),
        str(chr((MasterFrameHeader.WltrMasterFrameSignature & 0x00ff0000) >> 16)),
        str(chr((MasterFrameHeader.WltrMasterFrameSignature & 0x0000ff00) >> 8)),
        str(chr((MasterFrameHeader.WltrMasterFrameSignature & 0x000000ff) ))))
    FilePrintf( fp, "{0},".format(MasterFrameHeader.WltrDiscFileSizeInBytes))
    FilePrintf( fp, "{0:08x}h,".format(MasterFrameHeader.NextFrameOffsetInBytes))
    FilePrintf( fp, "{0:08x}h,".format(MasterFrameHeader.PrevFrameOffsetInBytes))
    if not MasterFrameHeader.PrevFrameOffsetInBytes == 0:
        if MasterFrameHeader.PrevFrameOffsetInBytes % 0x200 > 0:
            NonModulo200+=2
    FilePrintf( fp, "{0:08x}h,".format(MasterFrameHeader.TotalFrameSizeInBytes))
    #3/21/18 add filter for MFH Signature
    if ( (MasterFrameHeader.WltrMasterFrameSignature & 0xFFFFFC00 ) == (WLTR_MASTER_FRAME_SIGNATURE  & 0xFFFFFC00) ):
        FilePrintf( fp, "{0},".format(MasterFrameHeader.MaxStickyReadsIopsThisCycle))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.MaxStickyWritesIopsThisCycle))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.LeastBusyReadStickyFrameIops))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.LeastBusyWriteStickyFrameIops))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.BusiestReadStickyFrameIops))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.BusiestWriteStickyFrameIops))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.BestStickyReadFrameOffset))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.BestStickyWriteFrameOffset))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.TraceRecordingIntervalPowerOnTimeInMinutes))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.LastCycleCompletedPowerOnTimeInMinutes))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.NumOfFrames))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.DefaultSectorSizeInBytes))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.CycleCount))
        FilePrintf( fp, "{0},{1},".format(MasterFrameHeader.CurrentStep, WLTRStepStrings[MasterFrameHeader.CurrentStep]))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.IndexOfLastSavedReadStickyFrame))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.IndexOfLastSavedWriteStickyFrame))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.IndexOfBusiestReadStickyFrame))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.IndexOfBusiestWriteStickyFrame))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.IndexOfLeastBusyReadStickyFrame))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.IndexOfLeastBusyWriteStickyFrame))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.Heads))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.StickyFramesCount))
        FilePrintf( fp, "{0},\n".format(MasterFrameHeader.StickyFramesSavedCount))
    elif ( (MasterFrameHeader.WltrMasterFrameSignature & 0xFFFFFC00 ) == (WLTR_MASTER_FRAME_SIGNATURE_STICKY  & 0xFFFFFC00) ):      #3/21/18 add filter for MFH Signature
        FilePrintf( fp, "{0},".format(MasterFrameHeader.MaxStickyReadsIopsThisCycle))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.MaxStickyWritesIopsThisCycle))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.LeastBusyReadStickyFrameIops))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.LeastBusyWriteStickyFrameIops))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.BusiestReadStickyFrameIops))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.BusiestWriteStickyFrameIops))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.BestStickyReadFrameOffset))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.BestStickyWriteFrameOffset))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.TraceRecordingIntervalPowerOnTimeInMinutes))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.LastCycleCompletedPowerOnTimeInMinutes))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.NumOfFrames))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.DefaultSectorSizeInBytes))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.CycleCount))
        FilePrintf( fp, "{0},{1},".format(MasterFrameHeader.CurrentStep, WLTRStepStrings[MasterFrameHeader.CurrentStep]))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.IndexOfLastSavedReadStickyFrame))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.IndexOfLastSavedWriteStickyFrame))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.IndexOfBusiestReadStickyFrame))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.IndexOfBusiestWriteStickyFrame))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.IndexOfLeastBusyReadStickyFrame))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.IndexOfLeastBusyWriteStickyFrame))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.Heads))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.StickyFramesCount))
        FilePrintf( fp, "{0},\n".format(MasterFrameHeader.StickyFramesSavedCount))
    elif ( (MasterFrameHeader.WltrMasterFrameSignature & 0xFFFFFC00 ) == (WLTR_MASTER_FRAME_SIGNATURE_LEGACY & 0xFFFFFC00) ):
        FilePrintf( fp, "{0},".format(MasterFrameHeader.MaxStickyReadsIopsThisCycle))
        FilePrintf( fp, "{0},,,".format(MasterFrameHeader.MaxStickyWritesIopsThisCycle))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.BestStickyReadFrameOffset))
        FilePrintf( fp, "{0},,,".format(MasterFrameHeader.BestStickyWriteFrameOffset))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.TraceRecordingIntervalPowerOnTimeInMinutes))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.LastCycleCompletedPowerOnTimeInMinutes))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.NumOfFrames))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.DefaultSectorSizeInBytes))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.CycleCount))
        FilePrintf( fp, "{0},{1},".format(MasterFrameHeader.CurrentStep, WLTRStepStrings[MasterFrameHeader.CurrentStep]))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.IndexOfLastSavedReadStickyFrame))
        FilePrintf( fp, "{0},,,,,".format(MasterFrameHeader.IndexOfLastSavedWriteStickyFrame))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.Heads))
        FilePrintf( fp, "{0},,\n".format(MasterFrameHeader.StickyFramesCount))
    elif ( (MasterFrameHeader.WltrMasterFrameSignature  & 0xFFFFFC00 )== (WLTR_DF_MASTER_FRAME_SIGNATURE & 0xFFFFFC00) ):
        FilePrintf( fp, ",,,,,,,,,,{0},".format(MasterFrameHeader.NumOfFrames))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.DefaultSectorSizeInBytes))
        FilePrintf( fp, "{0},".format(MasterFrameHeader.CycleCount))
        FilePrintf( fp, "{0},{1},,,,,,,".format(MasterFrameHeader.CurrentStep, WLTRStepStrings[MasterFrameHeader.CurrentStep]))
        FilePrintf( fp, "{0},,,\n".format(MasterFrameHeader.Heads))
    return


def PrintMasterFrameHeaderSummaryTitle( MasterFrameHeader, fp=None ):
    # 3/22/18
    # "=== Master Frame Header ===\n")
    FilePrintf( fp, "DriveSN,")
    FilePrintf( fp, "TSLastSaved,")
    FilePrintf( fp, "MFSign,")
    FilePrintf( fp, "DiscSize,")
    FilePrintf( fp, "NextOffset,")
    FilePrintf( fp, "PrevOffset,")
    FilePrintf( fp, "FrameSize,")
    FilePrintf( fp, "StkyRdIOPsMax,")
    FilePrintf( fp, "StkyWtIOPsMax,")
    FilePrintf( fp, "StkyRdIOPsMin,")
    FilePrintf( fp, "StkyWtIOPsMin,")
    FilePrintf( fp, "StkyRdIOPsBusy,")
    FilePrintf( fp, "StkyWtIOPsBusy,")
    FilePrintf( fp, "StkyRdOffsetMax,")
    FilePrintf( fp, "StkyWtOffsetMax,")
    FilePrintf( fp, "TraceTime(min),")
    FilePrintf( fp, "EndTs(min),")
    FilePrintf( fp, "NumFrames,")
    FilePrintf( fp, "SectSize,")
    FilePrintf( fp, "Cycle,")
    FilePrintf( fp, "CurrStep,")
    FilePrintf( fp, "WLTRStep,")
    FilePrintf( fp, "StkyRdNdx,")
    FilePrintf( fp, "StkyWtNdx,")
    FilePrintf( fp, "StkyRdMaxNdx,")
    FilePrintf( fp, "StkyWtMaxNdx,")
    FilePrintf( fp, "StkyRdMinNdx,")
    FilePrintf( fp, "StkyRdMinNdx,")
    FilePrintf( fp, "NumHeads,")
    FilePrintf( fp, "StkyFrmCnt,")
    FilePrintf( fp, "StkySaveCnt,\n")
    return



def PrintFrameHeader( CurFrameHeader, fp=None ):
    FilePrintf( fp, "=== Frame Header ===\n")
    FilePrintf( fp, "   WltrFrameSignature                           {0:08x}('{1}{2}{3}{4}')\n".format(
        CurFrameHeader.WltrFrameSignature,
        str(chr((CurFrameHeader.WltrFrameSignature & 0xff000000) >> 24)),
        str(chr((CurFrameHeader.WltrFrameSignature & 0x00ff0000) >> 16)),
        str(chr((CurFrameHeader.WltrFrameSignature & 0x0000ff00) >> 8)),
        str(chr((CurFrameHeader.WltrFrameSignature & 0x000000ff)))) )
    FilePrintf( fp, "   FrameNum                                     {0:04x}\n".format(CurFrameHeader.FrameNum) )
    FilePrintf( fp, "   Revision                                     {0:04x}\n".format(CurFrameHeader.Revision) )
    FilePrintf( fp, "   StartTimestamp                     ")
    PrintTimeStamp( CurFrameHeader.StartTimestamp, fp )
    FilePrintf( fp, "   StartTimestamp (hours)                       {0:f}\n".format((CurFrameHeader.StartTimestamp & 0xFFFFFFFFFFFF)/3600000000.0))     #3/9/18
    FilePrintf( fp, "   EndTimestamp                       ")
    PrintTimeStamp( CurFrameHeader.EndTimestamp, fp )
    FilePrintf( fp, "   EndTimeStamp (hours)                         {0:f}\n".format((CurFrameHeader.EndTimestamp & 0xFFFFFFFFFFFF)/3600000000.0))     #3/9/18

    FilePrintf( fp, "   PrevFrameOffsetInBytes                       {0:08x}\n".format(CurFrameHeader.PrevFrameOffsetInBytes) )
    FilePrintf( fp, "   CycleCount                                   {0:04x}\n".format(CurFrameHeader.CycleCount) )
    if (CurFrameHeader.WltrFrameSignature & 0xFFFFFF00) == (WLTR_FRAME_HEADER_SIGNATURE  & 0xFFFFFF00):
        FilePrintf( fp, "   Session                                      {0:04x}\n".format(CurFrameHeader.Session) )
        FilePrintf( fp, "   Mode                                         {0:04x}\n".format(CurFrameHeader.Mode) )
    else:
        FilePrintf( fp, "   Pad1                                         {0:04x}\n".format(CurFrameHeader.Pad1) )
    FilePrintf( fp, "   FrameSizeInBytes                             {0:08x}\n".format(CurFrameHeader.FrameSizeInBytes) )
    FilePrintf( fp, "   DurationOfThisFrame                          {0:08x}\n".format(CurFrameHeader.DurationOfThisFrame) )
    if (CurFrameHeader.WltrFrameSignature & 0xFFFFFF00) == (WLTR_FRAME_HEADER_SIGNATURE  & 0xFFFFFF00):
        FilePrintf( fp, "   ReadsThisFrame                               {0:08x}\n".format(CurFrameHeader.ReadsThisFrame) )
        FilePrintf( fp, "   WritesThisFrame                              {0:08x}\n".format(CurFrameHeader.WritesThisFrame) )
    FilePrintf( fp, "   OneSecondMarkersThisFrame                    {0:08x}\n".format(CurFrameHeader.OneSecondMarkersThisFrame) )
    if (CurFrameHeader.WltrFrameSignature & 0xFFFFFF00) == (WLTR_FRAME_HEADER_SIGNATURE  & 0xFFFFFF00):
        FilePrintf( fp, "   WrapLocation                                 {0:08x}\n".format(CurFrameHeader.WrapLocation) )
        FilePrintf( fp, "   TotalNumberOfEvents                          {0:08x}\n".format(CurFrameHeader.TotalNumberOfEvents) )
    #  3/9/18 output a tab delimited file for this also, if verbose is enabled

def PrintFrameHeaderSummary( CurFrameHeader, MasterFrameHeader, fp=None ):
    #3/21/18
    FilePrintf( fp, "{0}{1}{2}{3}{4}{5}{6}{7},".
                format(
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x00000000000000ff))),
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x000000000000ff00) >> 8)),
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x0000000000ff0000) >> 16)),
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x00000000ff000000) >> 24)),
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x000000ff00000000) >> 32)),
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x0000ff0000000000) >> 40)),
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x00ff000000000000) >> 48)),
                    str(chr((MasterFrameHeader.DriveSerialNum & 0xff00000000000000) >> 56))))
    FilePrintf( fp, "{0:08x}h,".format(CurFrameHeader.WltrFrameSignature ))
    FilePrintf( fp, "{0},".format(CurFrameHeader.FrameNum) )
    FilePrintf( fp, "{0},".format(CurFrameHeader.Revision) )
    FilePrintf( fp, "{0:f},".format((CurFrameHeader.StartTimestamp & 0xFFFFFFFFFFFF)/3600000000.0))
    FilePrintf( fp, "{0:f},".format((CurFrameHeader.EndTimestamp & 0xFFFFFFFFFFFF)/3600000000.0))
    FilePrintf( fp, "{0:08x}h,".format(CurFrameHeader.PrevFrameOffsetInBytes) )
    FilePrintf( fp, "{0},".format(CurFrameHeader.CycleCount) )
    if (CurFrameHeader.WltrFrameSignature & 0xFFFFFF00) == (WLTR_FRAME_HEADER_SIGNATURE  & 0xFFFFFF00):
        FilePrintf( fp, "{0},".format(CurFrameHeader.Session) )
        FilePrintf( fp, "{0},".format(CurFrameHeader.Mode) )
    else:
        FilePrintf( fp, ",,")
    FilePrintf( fp, "{0},".format(CurFrameHeader.FrameSizeInBytes) )
    FilePrintf( fp, "{0},".format(CurFrameHeader.DurationOfThisFrame) )
    if (CurFrameHeader.WltrFrameSignature & 0xFFFFFF00) == (WLTR_FRAME_HEADER_SIGNATURE  & 0xFFFFFF00):
        FilePrintf( fp, "{0},".format(CurFrameHeader.ReadsThisFrame) )
        FilePrintf( fp, "{0},".format(CurFrameHeader.WritesThisFrame) )
    else:
        FilePrintf( fp, ",,")
    FilePrintf( fp, "{0},".format(CurFrameHeader.OneSecondMarkersThisFrame) )
    if (CurFrameHeader.WltrFrameSignature & 0xFFFFFF00) == (WLTR_FRAME_HEADER_SIGNATURE  & 0xFFFFFF00):
        FilePrintf( fp, "{0:08x}h,".format(CurFrameHeader.WrapLocation) )
        FilePrintf( fp, "{0},\n".format(CurFrameHeader.TotalNumberOfEvents) )
    else:
        FilePrintf( fp, ",,\n")

def PrintFrameHeaderSummaryTitles( fp=None ):
    #3/21/18
    FilePrintf( fp, "DriveSN,")
    FilePrintf( fp, "FrmSign,")
    FilePrintf( fp, "FrameNum,")
    FilePrintf( fp, "Rev,")
    FilePrintf( fp, "StartTS,")
    FilePrintf( fp, "EndTS,")
    FilePrintf( fp, "PrevOff,")
    FilePrintf( fp, "Cycles,")
    FilePrintf( fp, "Session,")
    FilePrintf( fp, "Mode,")
    FilePrintf( fp, "FrameSize,")
    FilePrintf( fp, "Duration,")
    FilePrintf( fp, "Reads,")
    FilePrintf( fp, "Writes,")
    FilePrintf( fp, "SecMarks,")
    FilePrintf( fp, "Wraploc,")
    FilePrintf( fp, "NumEvts,\n")


#output 1 line of header info before frame contents are output
def PrintFrameHeaderInfo(CurFrameHeader, OutputFile=None):
    FilePrintf( OutputFile, "=== Frame {0}, Sig: {1:08x}, Cyc: {2}, Duration: {3} s, Sec Mrks: {4}, Start and End Time:  {5} / {6} |  StartTime: ".format(
        CurFrameHeader.FrameNum,
        CurFrameHeader.WltrFrameSignature,
        CurFrameHeader.CycleCount,
        CurFrameHeader.DurationOfThisFrame,
        CurFrameHeader.OneSecondMarkersThisFrame,
        ((CurFrameHeader.StartTimestamp & 0xFFFFFFFFFFFF)/3600000000.0),          #3/9/18 add
        ((CurFrameHeader.EndTimestamp & 0xFFFFFFFFFFFF)/3600000000.0) ))          #3/9/18 add
    PrintTimeStamp( CurFrameHeader.StartTimestamp, OutputFile )

def PrintColumnHeader(Verbose, OutputFile=None):
    global OpcodeColumnSize

    FilePrintf( OutputFile, "EntryIdx File Loc StartLBA   XfrLen   calcEndLba ")
    if ( Verbose ):
        FilePrintf( OutputFile, "{0} ".format("Opcode").ljust(OpcodeColumnSize))
        FilePrintf( OutputFile, " RawOp RawLB RawXL LBAOffset\n")
    else:
        FilePrintf(OutputFile, "Opcode\n")
    FilePrintf( OutputFile, "======== ======== ========== ======== ========== ")

    for i in range(OpcodeColumnSize):
        FilePrintf( OutputFile, "=")

    if ( Verbose ):
        FilePrintf(OutputFile, " ===== ===== ===== ==========\n")
    else:
        FilePrintf( OutputFile, "\n")

def PrintColumnHeaderCSV(Verbose, OutputFileCSV=None):
    global OpcodeColumnSize

    FilePrintf( OutputFileCSV, "DriveSN,EntryIdx,Time,Time-Hr,FileLoc,StartLBA,XfrLen,calcEndLba")
    if ( Verbose ):
        FilePrintf(OutputFileCSV, ",Opcode,RawOp,RawLB,RawXL,LBAOffset\n")
    else:
        FilePrintf(OutputFileCSV, ",Opcode\n")

def GetHostSectorForEntry( LbaField, OpCode ):
    if (OpCode >= WLTR_DF_DISC_READ) and (OpCode < WLTR_DF_ACTIVE_DISC_ABORTED):
        return LbaField * HostBlocksPerDiscSector
    return LbaField

def IsLBAFieldOffset( LbaCode, DataFlowMode ):
    if DataFlowMode:
        LbaCode = LbaCode << WLTR_DF_LBA_FIELD_OFFSET
        if ( LbaCode >= WLTR_DF_LBA_1_BYTE_POS_OFFSET and
             LbaCode <= WLTR_DF_LBA_3_BYTE_NEG_OFFSET and
             LbaCode != WLTR_DF_LBA_SAME_AS_LAST_CMD ):
            return 1
        else:
            return 0
    else:
        if ( LbaCode != SEQUENTIAL_TO_LAST_CMD and
             LbaCode != ABSOLUTE_START_LBA ):
            return 1
        else:
            return 0

def OutputEntryIfLBAFound( EntryLBA, EntryXfrLength, EntryOutput, EntryOutputCSV, CurFrameHeader, Verbose ):
    global LBAFoundInFrame, SearchLBAValid, SearchLBAStart, SearchLBAEnd

    if SearchLBAValid:
        EntryEndLBA = EntryLBA + EntryXfrLength
        if (EntryLBA < SearchLBAEnd) and (EntryEndLBA > SearchLBAStart):
            if LBAFoundInFrame == 0:
                LBAFoundInFrame = 1
                PrintFrameHeaderInfo( CurFrameHeader )
                PrintColumnHeader( Verbose )
            FilePrintf(None, EntryOutput)
            #FilePrintf(None, EntryOutputCSV)           #3/8/18 need to pass more stuff to do this.

def ParseFrameContents( MasterFrameHeader, CurFrameHeader, OutputFile, OutputFileComma, RawData, IndexOffset, ExpectedFrameEnd, Verbose, CheckFooter, OutputFileOption ):
    global EntriesProcessed, BytesProcessed, OpCodeCounters, LbaCodeCounters, XLCodeCounters, LBAFoundInFrame

    #initialize local vars
    CurStartLBACode     = 0
    CurOpCode           = 0
    AdditionalOpcode    = 0
    CurXfrLengthCode    = 0
    PriorOpcode         = 0
    CurrentLBA          = 0
    CurrentOffset       = 0
    CurrentXfrLen       = 0
    CurEntryIdx         = 0
    MarkerCount         = 0
    CurFileOffset       = 0
    FrameStartOffset    = 0
    CurOpCodeString     = None
    MarkerString        = None
    RunningTimeStamp    = 0.0
    RunningTimeStamp    = CurFrameHeader.StartTimestamp & 0xFFFFFFFFFFFF    #12/15/17 way to track a running timestamp   3/9/18 remove Power cycles from field
    PriorXfrLen         = 0               #3/7/18
    ExpectedLastFrameOffset = 0         #3/12/18

    # print RunningTimeStamp
    DriveSNString = (str(chr((MasterFrameHeader.DriveSerialNum & 0x00000000000000ff)))+
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x000000000000ff00) >> 8))+
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x0000000000ff0000) >> 16))+
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x00000000ff000000) >> 24))+
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x000000ff00000000) >> 32))+
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x0000ff0000000000) >> 40))+
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x00ff000000000000) >> 48))+
                    str(chr((MasterFrameHeader.DriveSerialNum & 0xff00000000000000) >> 56)))


    LBAFoundInFrame = 0
    #print "...cur file location = {0:08x}".format(IndexOffset)
    #3/21/18 add filter for MFH Signature
    if ( ( (MasterFrameHeader.WltrMasterFrameSignature & 0xFFFFFC00 )== (WLTR_MASTER_FRAME_SIGNATURE & 0xFFFFFC00) ) or
         ( (MasterFrameHeader.WltrMasterFrameSignature & 0xFFFFFC00 ) == (WLTR_MASTER_FRAME_SIGNATURE_LEGACY& 0xFFFFFC00) ) ):
        DataFlowMode = 0
        ExpectedFrameFooterSignature = WLTR_FRAME_FOOTER_SIGNATURE
    elif ( (MasterFrameHeader.WltrMasterFrameSignature & 0xFFFFFC00 ) == (WLTR_DF_MASTER_FRAME_SIGNATURE & 0xFFFFFC00) ):
        DataFlowMode = 1
        ExpectedFrameFooterSignature = WLTR_DF_FRAME_FOOTER_SIGNATURE
    else:
        print("***Unexpected Master Frame Signature found {0:08x}\n".format(MasterFrameHeader.WltrMasterFrameSignature))
        return 2

    DefaultSectorSize = MasterFrameHeader.DefaultSectorSizeInBytes

    FrameStartOffset = IndexOffset
    
    if OutputFile != None and (OutputFileOption & 2) == 0:
        #4/2/18 exclude normal text file output filename
        PrintColumnHeader(Verbose, OutputFile)

    if OutputFileComma != None and (OutputFileOption & 1) == 1:
        PrintColumnHeaderCSV(Verbose, OutputFileComma)

    ExpectedLastFrameOffset = FrameStartOffset + MasterFrameHeader.TotalFrameSizeInBytes            # 0x80000        #3/12/18 need to not make it a fixed 80000h, but from the master header value. 3/21/20 done.

    while ( IndexOffset < ExpectedFrameEnd ):

        CurFileOffset = IndexOffset
        try:
            CurByte = ord(RawData[IndexOffset])
        except:
            CurByte = 0
            if Verbose:
                print("***Unexpected End of Frame encountered, Loc: {0}\n".format(hex(IndexOffset)))

        IndexOffset += 1

        # DataFlowMode = 0
        if ( DataFlowMode ):
            # -----------------------------------------------------------------------------------
            # DataFlow WLTR mode
            # -----------------------------------------------------------------------------------
            if ( ( CurByte & 0xF0 ) == WLTR_DF_REPEAT_LAST_ENTRY_1X ):
                RepeatCount = ( CurByte & 0x0F ) + 1
                OpCodeCounters[CurByte] += 1

                if ( CurOpCodeString == None ):
                    if Verbose:
                        print("***Unexpected Repeat token encountered, Loc: {0}\n".format(hex(CurFileOffset)))
                    #return 1
                    continue

                OutputString = "{0:8} {1:08x} {2:010x} {3:08x} {4:010x} {5}".format(
                    CurEntryIdx, CurFileOffset,
                    CurrentHostLBA,
                    CurrentHostXfrLen,
                    CurrentHostLBA + CurrentHostXfrLen - 1,
                    CurOpCodeString.ljust(OpcodeColumnSize))

                OutputStringCSV = "{0},{1:8},{2:08x},{3:010x},{4:08x},{5:010x},{6}".format(
                    DriveSNString, CurEntryIdx, CurFileOffset,
                    CurrentHostLBA,
                    CurrentHostXfrLen,
                    CurrentHostLBA + CurrentHostXfrLen - 1,
                    CurOpCodeString)

                if Verbose:
                    OutputString = "{0} {1:02x}\n".format(OutputString, CurByte)
                    OutputStringCSV = "{0},{1}\n".format(OutputStringCSV, CurByte)
                else:
                    OutputString = "{0}\n".format(OutputString)
                    OutputStringCSV = "{0}\n".format(OutputStringCSV)

                for i in range(RepeatCount):
                    if OutputFile != None and (OutputFileOption & 2) == 0:
                        #4/2/18 exclude normal text file output filename
                        FilePrintf(OutputFile, OutputString)
                    if OutputFileComma != None and (OutputFileOption & 1) == 1:
                        FilePrintf(OutputFile, OutputStringCSV)
                    #if seaching for a specific LBA, then output this entry to stdout if it overlaps
                    OutputEntryIfLBAFound( CurrentHostLBA, CurrentHostXfrLen, OutputString, OutputStringCSV, CurFrameHeader, Verbose )

                    CurEntryIdx += 1
                    if ( ( PriorOpcode & 0xFF ) == WLTR_DF_ADDITIONAL_ENCODE_BYTE ):
                        AdditionalOpCodeCounters[PriorOpcode >> 8] += 1
                    else:
                        OpCodeCounters[PriorOpcode] += 1
                EntriesProcessed += RepeatCount
                continue
            elif ( ( CurByte & 0xF0 ) == WLTR_DF_REPEAT_LAST_ENCODING_1X ):
                RepeatCount = ( CurByte & 0x0F ) + 1
                OpCodeCounters[CurByte] += 1

                # Special repeat token
                for i in range(RepeatCount):
                    if CurOpCode == WLTR_DF_ONE_SECOND_MARKER:
                        # print ("Before: ", RunningTimeStamp)
                        #12/20/18 Suppose one second should be +=1000000, could have been due to truncated file
                        #         from FA (?) due to the tranfer length handling on system 4K drives.
                        RunningTimeStamp+=1000000    #12/15/17 25 ms.
                        # print ("After: ", RunningTimeStamp)
                        MarkerString = "{0}({1})".format(OneSecondMarkerString, MarkerCount).ljust(OpcodeColumnSize)
                        MarkerStringCSV = "{0},{1},{2},{3},{4}".format(DriveSNString, RunningTimeStamp, RunningTimeStamp/3600000000.0, OneSecondMarkerString, MarkerCount)

                        MarkerCount += 1
                        # ONE_SECOND_MARKER
                        if OutputFile != None and (OutputFileOption & 2) == 0:
                            FilePrintf(OutputFile, "{0:8} {1:08x} ---------- -------- ---------- {2}".format(
                                CurEntryIdx, CurFileOffset, MarkerString))
                        if OutputFileComma != None and (OutputFileOption & 1) == 1:
                            FilePrintf(OutputFileComma, "{0},{1},{2}".format(
                                CurEntryIdx, CurFileOffset, MarkerStringCSV))

                        CurEntryIdx += 1

                        if OutputFile != None and (OutputFileOption & 2) == 0:
                            if ( Verbose ):
                                FilePrintf(OutputFile, " {0:02x}\n".format(CurByte))
                            else:
                                FilePrintf(OutputFile, "\n")
                        if OutputFileComma != None and (OutputFileOption & 1) == 1:
                            if ( Verbose ):
                                FilePrintf(OutputFileComma, ",{0:02x}\n".format(CurByte))
                            else:
                                FilePrintf(OutputFileComma, "\n")

                    else:
                        if CurOpCodeString == None:
                            if Verbose:
                                print("***Unexpected Repeat token encountered, Loc: {0}\n".format(hex(CurFileOffset)))
                            #return 1
                            continue

                        if ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_SEQUENTIAL_TO_LAST_CMD:
                            # Sequential to Prev
                            CurrentLBA = PriorLBA + PriorXfrLen
                        elif ( ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_1_BYTE_POS_OFFSET ) or
                               ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_2_BYTE_POS_OFFSET ) or
                               ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_3_BYTE_POS_OFFSET ) ):
                            # Positive Sequential
                            CurrentLBA = PriorLBA + CurrentOffset
                        elif ( ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_1_BYTE_NEG_OFFSET ) or
                               ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_2_BYTE_NEG_OFFSET ) or
                               ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_3_BYTE_NEG_OFFSET ) ):
                            # Negative Sequential
                            CurrentLBA = PriorLBA - CurrentOffset

                        PriorLBA = CurrentLBA

                        CurrentHostLBA      = GetHostSectorForEntry(CurrentLBA, PriorOpcode)
                        if CurXfrLengthCode == WLTR_DF_XL_INFINITE:
                            CurrentHostXfrLen = CurrentXfrLen
                        else:
                            CurrentHostXfrLen = GetHostSectorForEntry(CurrentXfrLen, PriorOpcode)
                        OutputString = "{0:8} {1:08x} {2:010x} {3:08x} {4:010x} {5}".format(
                            CurEntryIdx, CurFileOffset, CurrentHostLBA, CurrentHostXfrLen,
                            CurrentHostLBA + CurrentHostXfrLen - 1,
                            CurOpCodeString.ljust(OpcodeColumnSize))
                        # 12/15/17 change formats to comma delimited
                        OutputStringCSV = "{0},{1},{2},{3},{4},{5},{6},{7},{8}".format(
                            DriveSNString, CurEntryIdx, RunningTimeStamp, RunningTimeStamp/3600000000.0, CurFileOffset, CurrentHostLBA, CurrentHostXfrLen,
                            CurrentHostLBA + CurrentHostXfrLen - 1,
                            CurOpCodeString)

                        if ( Verbose ):
                            OutputString = "{0} {1:02x}\n".format(OutputString, CurByte)
                        else:
                            OutputString = "{0}\n".format(OutputString)

                        if OutputFileComma != None and (OutputFileOption & 1) == 1:
                            if ( Verbose ):
                                FilePrintf(OutputFileComma, ",{0},{1:02x}\n".format(OutputString, CurByte))
                            else:
                                FilePrintf(OutputFileComma, "\n")

                        if OutputFile != None and (OutputFileOption & 2) == 0:
                            FilePrintf(OutputFile, OutputString)
                        if OutputFileComma != None and (OutputFileOption & 1) == 1:
                            FilePrintf(OutputFileComma, OutputStringCSV)

                        #if seaching for a specific LBA, then output this entry to stdout if it overlaps
                        OutputEntryIfLBAFound( CurrentHostLBA, CurrentHostXfrLen, OutputString, OutputStringCSV, CurFrameHeader, Verbose )
                        CurEntryIdx += 1
                        if ( ( PriorOpcode & 0xFF ) == WLTR_DF_ADDITIONAL_ENCODE_BYTE ):
                            AdditionalOpCodeCounters[PriorOpcode >> 8] += 1
                        else:
                            OpCodeCounters[PriorOpcode] += 1
                EntriesProcessed += RepeatCount
                continue

            CurOpCode = CurByte
            OpCodeCounters[CurOpCode] += 1

            if ( CurOpCode == WLTR_DF_ONE_SECOND_MARKER ):
                # print ("Before: ", RunningTimeStamp)
                RunningTimeStamp+=25000    #12/15/17 25 ms.
                # print ("After: ", RunningTimeStamp)

                MarkerString = "{0} ({1})".format(OneSecondMarkerString, MarkerCount).ljust(OpcodeColumnSize)
                MarkerStringCSV =  "{0},{1},{2},{3},{4}".format(DriveSNString,RunningTimeStamp, RunningTimeStamp/3600000000.0, OneSecondMarkerString, MarkerCount)
                MarkerCount += 1
                # ONE_SECOND_MARKER
                if OutputFile != None and (OutputFileOption & 2) == 0:
                    FilePrintf(OutputFile, "{0:8} {1:08x} ---------- -------- ---------- {2}".format(
                        CurEntryIdx, CurFileOffset, MarkerString))
                if OutputFileComma != None and (OutputFileOption & 1) == 1:
                    FilePrintf(OutputFileComma, "{0},{1},{2},{3}".format(
                        DriveSNString, CurEntryIdx, CurFileOffset, MarkerStringCSV))

                CurEntryIdx += 1
                EntriesProcessed += 1

                if OutputFile != None and (OutputFileOption & 2) == 0:
                    if ( Verbose ):
                        FilePrintf( OutputFile, " {0:02x}\n".format(CurByte) )
                    else:
                        FilePrintf(OutputFile, "\n")
                if OutputFileComma != None and (OutputFileOption & 1) == 1:
                    if ( Verbose ):
                        FilePrintf( OutputFileComma, ",{0:02x}\n".format(CurByte) )
                    else:
                        FilePrintf(OutputFileComma, "\n")
                continue
            elif ( CurOpCode == WLTR_DF_TRACE_HALTED ):
                HaltedOpCodeString = "WLTR_DF_TRACE_HALTED"
                if OutputFile != None and (OutputFileOption & 2) == 0:
                    FilePrintf(OutputFile, "{0:8} {1:08x} ---------- -------- ---------- {2}".format(
                        CurEntryIdx, CurFileOffset, HaltedOpCodeString.ljust(OpcodeColumnSize)))
                if OutputFileComma != None and (OutputFileOption & 1) == 1:
                    FilePrintf(OutputFileComma, "{0:8} {1:08x} ---------- -------- ---------- {2}".format(
                        CurEntryIdx, CurFileOffset, HaltedOpCodeString.ljust(OpcodeColumnSize)))
                CurEntryIdx += 1
                EntriesProcessed += 1
                if OutputFile != None and (OutputFileOption & 2) == 0:
                    if ( Verbose ):
                        FilePrintf(OutputFile, " {0:02x}\n".format(CurOpCode))
                    else:
                        FilePrintf(OutputFile, "\n")
                if OutputFileComma != None and (OutputFileOption & 1) == 1:
                    if ( Verbose ):
                        FilePrintf(OutputFileComma, ",{0:02x}\n".format(CurOpCode))
                    else:
                        FilePrintf(OutputFileComma, "\n")

                sys.stdout.write("...WARNING: Trace Halt detected in Frame {0}, Entry {1}\n".format(
                    CurFrameHeader.FrameNum, CurEntryIdx - 1))
                continue

            # Need an additional encode byte
            CurByte = ord(RawData[IndexOffset])
            IndexOffset += 1

            if ( IndexOffset > ExpectedFrameEnd ):
                if Verbose:
                    print("1-***Unexpected End-of-Frame detected, expected encode byte at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                #return 1
                continue

            CurStartLBACode   = (CurByte & WLTR_DF_LBA_MASK) >> WLTR_DF_LBA_FIELD_OFFSET
            CurXfrLengthCode  = (CurByte & WLTR_DF_XFR_LENGTH_MASK)

            LbaCodeCounters[CurStartLBACode] += 1
            XLCodeCounters[CurXfrLengthCode] += 1

            # OpCode encoding
            if ( CurOpCode == WLTR_DF_ADDITIONAL_ENCODE_BYTE ):
                # Need an additional encode byte
                try:        #3/21/20
                    CurByte = ord(RawData[IndexOffset])
                except:
                    CurByte = 0
                IndexOffset += 1
                if ( IndexOffset > ExpectedFrameEnd ):
                    if Verbose:
                        print("2-***Unexpected End-of-Frame detected, expected additional encode byte at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                    #return 1
                    continue
                AdditionalOpcode = CurByte
                # debug
                # printf("...AddOp:%02x\n", AdditionalOpcode)
                CurOpCodeString = DataFlowAdditionalOpCodeStrings[AdditionalOpcode]
                PriorOpcode = CurOpCode + (AdditionalOpcode << 8)
            elif ( CurOpCode > WLTR_DF_MAX_VALID_OPCODE ) or ( DataFlowOpCodeStrings[CurOpCode] == 0 ):
                if Verbose:
                    print("*** Unexpected OpCode ({0:02x}), Loc:{1}\n".format(CurOpCode, hex(CurFileOffset)))
                #return 1
                CurOpCodeString = "UNKNOWN_{0:02x}".format(CurOpCode)
                PriorOpcode = CurOpCode
            else:
                CurOpCodeString = DataFlowOpCodeStrings[CurOpCode]
                PriorOpcode = CurOpCode

            #
            # Transfer Length decode
            #
            if ( CurXfrLengthCode == WLTR_DF_XL_SAME_AS_LAST ):
                CurrentXfrLen = PriorXfrLen
            elif ( ( CurXfrLengthCode == WLTR_DF_XL_VERBATIM_1_BYTE ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_VERBATIM_2_BYTES ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_VERBATIM_3_BYTES ) ):
                CurrentXfrLen = 0
                for i in range(CurXfrLengthCode):
                    try:        #3/21/20
                        CurByte = ord(RawData[IndexOffset])
                    except:
                        CurByte = 0
                    IndexOffset += 1
                    if ( IndexOffset > ExpectedFrameEnd ):
                        if Verbose:
                            print("3-***Unexpected End-of-Frame detected, expected Transfer Length field at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                        break
                        #return 1
                    CurrentXfrLen |= (CurByte << (i * 8))
                if ( IndexOffset > ExpectedFrameEnd ):      #1/23/18 break out of the loop
                    continue

            elif ( ( CurXfrLengthCode == WLTR_DF_XL_1_BLK ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_2_BLKS ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_4_BLKS ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_8_BLKS ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_16_BLKS ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_32_BLKS ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_64_BLKS ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_128_BLKS ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_256_BLKS ) ):
                CurrentXfrLen = DataFlowTransferLengthArray[CurXfrLengthCode - 4]
            elif ( ( CurXfrLengthCode == WLTR_DF_XL_SHIFT_1_BYTE ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_SHIFT_2_BYTES ) ):
                # Shifted by 8 bits
                CurrentXfrLen = 0
                for i in range(CurXfrLengthCode - 0xC):
                    try:        #3/21/20
                        CurByte = ord(RawData[IndexOffset])
                    except:
                        CurByte = 0
                    IndexOffset += 1
                    if ( IndexOffset > ExpectedFrameEnd ):
                        if Verbose:
                            print("4-***Unexpected End-of-Frame detected, expected Transfer Length field at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                        break
                        #return 1
                    CurrentXfrLen |= (CurByte << (i * 8))
                if ( IndexOffset > ExpectedFrameEnd ):      #1/23/18 break out of the loop
                    continue

                CurrentXfrLen = CurrentXfrLen << 8
            elif ( CurXfrLengthCode == WLTR_DF_XL_INFINITE ):
                CurrentXfrLen = 0xFFFFFFFF
            else:
                if Verbose:
                    print("*** Unexpected OpCode ({0:02x}), Loc:{1}\n".format(CurXfrLengthCode, hex(CurFileOffset)))
                continue
                #return 1

            #
            # Start LBA decode
            #
            if ( ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_SIZE_1_BYTE ) or
                 ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_SIZE_2_BYTES ) or
                 ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_SIZE_3_BYTES ) or
                 ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_SIZE_4_BYTES ) or
                 ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_SIZE_5_BYTES ) ):
                CurrentLBA = 0
                for i in range(CurStartLBACode):
                    try:        #3/21/20
                        CurByte = ord(RawData[IndexOffset])
                    except:
                        CurByte = 0
                    IndexOffset += 1
                    if ( IndexOffset > ExpectedFrameEnd ):
                        if Verbose:
                            print("5-***Unexpected End-of-Frame detected, expected Start LBA field at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                        break
                        #return 1
                    CurrentLBA |= (CurByte << (i * 8))
                if ( IndexOffset > ExpectedFrameEnd ):      #1/23/18 break out of the loop
                    continue
                #print "...LBA:{0:08x}".format(CurrentLBA)
                if ( ( CurByte == 0x00 ) and ( i > 1 ) ):
                    # high order byte is unexpectedly 0
                    if Verbose:
                        print("*** Unexpected value for CurStartLBACode, Loc:{0}\n".format(CurFileOffset))
            elif ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET) ==  WLTR_DF_LBA_SEQUENTIAL_TO_LAST_CMD ):
                # Sequential
                CurrentLBA = PriorLBA + PriorXfrLen
            elif ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_SAME_AS_LAST_CMD ):
                # Same as prev
                CurrentLBA = PriorLBA
            elif ( ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_1_BYTE_POS_OFFSET ) or
                   ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_2_BYTE_POS_OFFSET ) or
                   ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_3_BYTE_POS_OFFSET ) or
                   ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_1_BYTE_NEG_OFFSET ) or
                   ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_2_BYTE_NEG_OFFSET ) or
                   ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_3_BYTE_NEG_OFFSET ) ):
                # Offset, either positive or negative.
                CurrentOffset = 0
                for i in range(CurStartLBACode & 0x03):
                    try:        #3/21/20
                        CurByte = ord(RawData[IndexOffset])
                    except:
                        CurByte = 0
                    IndexOffset += 1
                    if ( IndexOffset > ExpectedFrameEnd ):
                        if Verbose:
                            print("6-***Unexpected End-of-Frame detected, expected LBA Offset field at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                        break
                        #return 1
                    CurrentOffset |= (CurByte << (i * 8))
                if ( IndexOffset > ExpectedFrameEnd ):      #1/23/18 break out of the loop
                    continue

                # print ("...LBO:{0:08x}".format(CurrentOffset))
                if ( ( CurByte == 0x00 ) and ( i > 1 ) ):
                    # high order byte is unexpectedly 0
                    if Verbose:
                        print("*** Unexpected value for CurrentOffset, Loc: {0}\n".format(hex(CurFileOffset)))
                if ( CurrentOffset == 0 ):
                    if Verbose:
                        print("***Unexpected zero offset, Loc: {0}\n".format(hex(CurFileOffset)))

                if ( CurStartLBACode & 0x04 ):
                    CurrentLBA = PriorLBA - CurrentOffset
                else:
                    CurrentLBA = PriorLBA + CurrentOffset
            else:
               if Verbose:
                   print("***Unexpected value for LBA Code({0:02x}), Loc:{1}\n".format(CurStartLBACode, hex(CurFileOffset)))
               continue
               #return 1

            CurrentHostLBA      = GetHostSectorForEntry(CurrentLBA, PriorOpcode)
            if CurXfrLengthCode == WLTR_DF_XL_INFINITE:
                CurrentHostXfrLen = CurrentXfrLen
            else:
                CurrentHostXfrLen = GetHostSectorForEntry(CurrentXfrLen, PriorOpcode)

            OutputString = "{0:8} {1:08x} {2:010x} {3:08x} {4:010x} {5}".format(
                CurEntryIdx, CurFileOffset, CurrentHostLBA, CurrentHostXfrLen,
                CurrentHostLBA + CurrentHostXfrLen - 1,
                CurOpCodeString.ljust(OpcodeColumnSize))

            OutputStringCSV = "{0},{1},{2},{3},{4},{5}".format(
                CurEntryIdx, CurFileOffset, CurrentHostLBA, CurrentHostXfrLen,
                CurrentHostLBA + CurrentHostXfrLen - 1,
                CurOpCodeString)

            if ( Verbose ):
                OutputString = "{0} {1:02x}    {2:1x}     {3:1x}".format(
                    OutputString, CurOpCode, CurStartLBACode, CurXfrLengthCode )
                OutputStringCSV = ",{0},{1},{2},{3}".format(
                    OutputStringCSV, CurOpCode, CurStartLBACode, CurXfrLengthCode )

                if IsLBAFieldOffset(CurStartLBACode, DataFlowMode):
                    OutputString = "{0}     {1:08x}\n".format(OutputString, CurrentOffset)
                    OutputStringCSV = ",{0},{1}\n".format(OutputString, CurrentOffset)
                else:
                    OutputString = "{0}\n".format(OutputString)
                    OutputStringCSV = ",{0}\n".format(OutputString)
            else:
                OutputString = "{0}\n".format(OutputString)
                OutputStringCSV = ",{0}\n".format(OutputString)


            if OutputFile != None and (OutputFileOption & 2) == 0:
                FilePrintf(OutputFile, OutputString)
            if OutputFileComma != None and (OutputFileOption & 1) == 1:
                FilePrintf(OutputFileComma, OutputStringCSV)

            #if seaching for a specific LBA, then output this entry to stdout if it overlaps
            OutputEntryIfLBAFound( CurrentHostLBA, CurrentHostXfrLen, OutputString, OutputStringCSV, CurFrameHeader, Verbose )

            CurEntryIdx += 1
            EntriesProcessed += 1

        # End Dataflow WLTR mode
        else:
            # -----------------------------------------------------------------------------------
            # Classic WLTR mode
            # -----------------------------------------------------------------------------------
            CurStartLBACode = (CurByte & WLTR_LBA_FIELD_MASK)
            CurOpCode = (CurByte & WRITE_COMMAND_TRACE) >> 3
            CurXfrLengthCode = (CurByte >> XFR_LENGTH_BIN_MASK_SHIFT_COUNT)

            XLCodeCounters[CurXfrLengthCode] += 1

            SkipLBACheck = 0

            if ( ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == ONE_BLOCK ) or
                 ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == TWO_BLOCKS ) or
                 ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == FOUR_BLOCKS ) or
                 ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == EIGHT_BLOCKS ) or
                 ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == SIXTEEN_BLOCKS ) or
                 ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == THIRTY_TWO_BLOCKS ) or
                 ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == ONE_HUNDRED_TWENTY_EIGHT ) or
                 ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == TWO_HUNDRED_FIFTY_SIXTY_BLOCKS ) ):
                CurrentXfrLen = TransferLengthArray[CurXfrLengthCode]
            elif ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == XFR_LENGTH_SAME_AS_LAST_CMD ):
                CurrentXfrLen = PriorXfrLen
            elif ( ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == VERBATIM_1_BYTE ) or
                   ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == VERBATIM_2_BYTES ) ):
                CurrentXfrLen = 0
                for i in range(CurXfrLengthCode - 8):
                    try:        #3/21/20
                        CurByte = ord(RawData[IndexOffset])
                    except:
                        CurByte = 0
                    IndexOffset += 1
                    if ( IndexOffset > ExpectedFrameEnd ):
                        if Verbose:
                            print("7-***Unexpected End-of-Frame detected, expected Transfer Length field at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                        #return 1
                        break
                    CurrentXfrLen |= (CurByte << (i * 8))
                if ( IndexOffset >= ExpectedFrameEnd ):      #1/23/18 break out of the loop  3/21/20 make it >= from >
                    continue
            elif ( ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == WLTR_RESERVED_1 ) or
                   ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == WLTR_RESERVED_2 ) ):
                if Verbose:
                    print("***Unexpected RESERVED value for CurXfrLengthCode({0:02x}), Loc:{1}\n".format(CurXfrLengthCode, hex(CurFileOffset)))
                SkipLBACheck = 1
            elif ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == STREAMING_STARTED ):
                # Streaming Started
                CurrentLBA = 0
                for i in range(5):
                    if ( IndexOffset >= ExpectedFrameEnd ):      #1/23/18 break out of the loop  3/21/20 make it ">=" from ">" and   move it above the pull
                        if Verbose:
                            print("8-***Unexpected End-of-Frame detected, expected Stream LBA field at offset {0}pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                        #return 1
                        break
                    try:        #3/21/20
                        CurByte = ord(RawData[IndexOffset])
                    except:
                        CurByte = 0
                    IndexOffset += 1
                    CurrentLBA |= (CurByte << (i * 8))
                if ( IndexOffset >= ExpectedFrameEnd ):      #1/23/18 break out of the loop  3/21/20 make it >= from >
                    continue
                CurrentXfrLen = PriorXfrLen
                SkipLBACheck = 1
            elif ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == STREAMING_TERMINATED ):
                CurrentLBA = 0
                for i in range(5):
                    if ( IndexOffset > ExpectedFrameEnd ):
                        if Verbose:
                            print("9-***Unexpected End-of-Frame detected, expected Stream LBA field at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                        #return 1
                        break
                    try:        #3/21/20
                        CurByte = ord(RawData[IndexOffset])
                    except:
                        CurByte = 0
                    IndexOffset += 1
                    CurrentLBA |= (CurByte << (i * 8))
                if ( IndexOffset >= ExpectedFrameEnd ):      #1/23/18 break out of the loop  3/21/20 make it >= from >
                    continue
                CurrentXfrLen = PriorXfrLen
                SkipLBACheck = 1
            elif ( ( CurXfrLengthCode << WLTR_DF_LBA_FIELD_OFFSET ) == ONE_SECOND_MARKER ):
                SkipLBACheck = 1
                #RunningTimeStamp+=25000    #12/15/17 25ms

            if ( SkipLBACheck == 0 ):
                LbaCodeCounters[CurStartLBACode] += 1

                if ( CurStartLBACode == ABSOLUTE_START_LBA ):
                    CurrentLBA = 0
                    if ( (IndexOffset+5) >= ExpectedFrameEnd ):       # 3/21/20 move above loop
                        if Verbose:
                            print("10-***Unexpected End-of-Frame detected, expected LBA field at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                        #return 1
                        break
                    for i in range(5):
                        try:        #3/21/20
                            CurByte = ord(RawData[IndexOffset])
                        except:
                            CurByte = 0
                        IndexOffset += 1
                        CurrentLBA |= (CurByte << (i * 8))
                    if ( IndexOffset >= ExpectedFrameEnd ):      #1/23/18 break out of the loop  3/21/20 make it >= from >
                        continue
                elif ( ( CurStartLBACode == SINGLE_BYTE_OFFSET ) or
                       ( CurStartLBACode == TWO_BYTE_OFFSET ) or
                       ( CurStartLBACode == THREE_BYTE_OFFSET ) ):
                    CurrentOffset = 0
                    if ( (IndexOffset+CurStartLBACode) >= ExpectedFrameEnd ):       # 3/21/20 move above loop
                        if Verbose:
                            print("11-***Unexpected End-of-Frame detected, expected LBA Offset field at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                        #return 1
                        break
                    for i in range(CurStartLBACode):
                        try:        #3/21/20
                            CurByte = ord(RawData[IndexOffset])
                        except:
                            CurByte = 0
                        IndexOffset += 1
                        CurrentOffset |= (CurByte << (i * 8))
                    CurrentLBA = PriorLBA + CurrentOffset
                    if ( IndexOffset >= ExpectedFrameEnd ):      #1/23/18 break out of the loop  3/21/20 make it >= from >
                        continue
                elif ( CurStartLBACode == SEQUENTIAL_TO_LAST_CMD ):
                    CurrentLBA = PriorLBA + PriorXfrLen
                elif ( ( CurStartLBACode == SINGLE_BYTE_NEGATIVE_OFFSET ) or
                       ( CurStartLBACode == TWO_BYTE_NEGATIVE_OFFSET ) or
                       ( CurStartLBACode == THREE_BYTE_NEGATIVE_OFFSET ) ):
                    CurrentOffset = 0
                    if ( (IndexOffset + CurStartLBACode - SINGLE_BYTE_NEGATIVE_OFFSET + 1) >= ExpectedFrameEnd ):       # 3/21/20 move above loop
                        if Verbose:
                            print("12-***Unexpected End-of-Frame detected, expected LBA Offset field at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                        #return 1
                        break
                    for i in range(CurStartLBACode - SINGLE_BYTE_NEGATIVE_OFFSET + 1):
                        try:        #3/21/20
                            CurByte = ord(RawData[IndexOffset])
                        except:
                            CurByte = 0
                        IndexOffset += 1
                        CurrentOffset |= (CurByte << (i * 8))
                    if ( IndexOffset >= ExpectedFrameEnd ):      #1/23/18 break out of the loop  3/21/20 make it >= from >
                        continue
                    CurrentLBA = PriorLBA - CurrentOffset

            if ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == STREAMING_STARTED ):
                CurOpCodeString = "STREAMING STARTED"
                OutputString = "{0:8} {1:08x} {2:010x} -------- ---------- {3}".format(
                    CurEntryIdx, CurFileOffset, CurrentLBA, CurOpCodeString.ljust(OpcodeColumnSize))
                # 12/15/17
                OutputStringCSV = "{0},{1},{2},{3},{4},{5},,{6}".format(
                    DriveSNString, CurEntryIdx, RunningTimeStamp, RunningTimeStamp/36000000000.0, CurFileOffset, CurrentLBA, CurOpCodeString)
            elif ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == STREAMING_TERMINATED ):
                CurOpCodeString = "STREAMING TERMINATED"
                OutputString = "{0:8} {1:08x} {2:010x} -------- ---------- {3}".format(
                    CurEntryIdx, CurFileOffset, CurrentLBA, CurOpCodeString.ljust(OpcodeColumnSize))
                # 12/15/17
                OutputStringCSV = "{0},{1},{2},{3},{4},{5},,,{6}".format(
                    DriveSNString, CurEntryIdx, RunningTimeStamp, RunningTimeStamp/36000000000.0, CurFileOffset, CurrentLBA, CurOpCodeString)
            elif ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == ONE_SECOND_MARKER ):
                RunningTimeStamp+=25000    #12/15/17 25 ms.
                CurOpCodeString = "{0}({1})".format(OneSecondMarkerString, MarkerCount)
                MarkerCount += 1
                OutputString = "{0:8} {1:08x} ---------- -------- ---------- {2}".format(
                    CurEntryIdx, CurFileOffset, CurOpCodeString.ljust(OpcodeColumnSize))
                #12/15/17
                OutputStringCSV = "{0},{1},{2},{3},{4},,,,{5}".format(
                    DriveSNString, CurEntryIdx, RunningTimeStamp, RunningTimeStamp/36000000000.0, CurFileOffset, CurOpCodeString)
            else:
                OpCodeCounters[CurOpCode] += 1
                if CurOpCode:
                    CurOpCodeString = "WRITE"
                else:
                    CurOpCodeString = "READ"
                OutputString = "{0:8} {1:08x} {2:010x} {3:08x} {4:010x} {5}".format(
                    CurEntryIdx, CurFileOffset, CurrentLBA, CurrentXfrLen,
                    CurrentLBA + CurrentXfrLen - 1,
                    CurOpCodeString.ljust(OpcodeColumnSize))
                12/15/17
                OutputStringCSV = "{0},{1},{2},{3},{4},{5},{6},{7},{8}".format(
                    DriveSNString, CurEntryIdx, RunningTimeStamp, RunningTimeStamp/36000000000.0, CurFileOffset, CurrentLBA, CurrentXfrLen,
                    CurrentLBA + CurrentXfrLen - 1,
                    CurOpCodeString)
            if Verbose:
                OutputString = "{0} {1:1x}     {2:1x}     {3:1x}".format(
                    OutputString,
                    CurOpCode, CurStartLBACode, CurXfrLengthCode )
                OutputStringCSV = "{0},{1},{2},{3}".format(
                    OutputStringCSV,
                    CurOpCode, CurStartLBACode, CurXfrLengthCode )
                if ( ( SkipLBACheck == 0 ) and
                     IsLBAFieldOffset( CurStartLBACode, DataFlowMode ) ):
                    OutputString = "{0}     {1:08x}\n".format(OutputString, CurrentOffset)
                    OutputStringCSV = "{0},{1}\n".format(OutputStringCSV, CurrentOffset)
                else:
                    OutputString = "{0}\n".format(OutputString)
                    OutputStringCSV = "{0}\n".format(OutputStringCSV)
            else:
                OutputString = "{0}\n".format(OutputString)
                OutputStringCSV = "{0}\n".format(OutputStringCSV)

            if OutputFile != None and (OutputFileOption & 2) == 0:
                FilePrintf( OutputFile, OutputString )
            if OutputFileComma != None and (OutputFileOption & 1) == 1:
                FilePrintf( OutputFileComma, OutputStringCSV )

            if SkipLBACheck == 0:
                OutputEntryIfLBAFound( CurrentLBA, CurrentXfrLen, OutputString, OutputStringCSV, CurFrameHeader, Verbose )

            CurEntryIdx += 1
            EntriesProcessed += 1

            if IndexOffset > ExpectedLastFrameOffset and Verbose:
                print("!***Current offset is beyond End-of-Frame location has been detected, Current offset = ({0:08x}) End of Frame = {1:08x}\n".format(IndexOffset, ExpectedLastFrameOffset))

        # End classic WLTR mode

        # preserve the current information as a prior amount
        PriorLBA = CurrentLBA
        PriorXfrLen = CurrentXfrLen

    CurFileOffset = IndexOffset
    BytesProcessed += (CurFileOffset - FrameStartOffset)

    #print "...checking footer"

    # Check frame footer
    if ( CheckFooter != 0 ):
        if ( IndexOffset > ExpectedFrameEnd and Verbose):
            print("***Unexpected End-of-Frame detected, expecting footer offset = ({0:08x}) EoFrame = {1:08x}\n".format(IndexOffset, ExpectedFrameEnd))
            # return 1



        if DataFlowMode:
            # Round up to the nearest sector size
            CurFileOffset = ( ( CurFileOffset + M_ByteSizeOf(wltr_frame_footer) + DefaultSectorSize - 1 ) /
                DefaultSectorSize *
                DefaultSectorSize ) - M_ByteSizeOf(wltr_frame_footer)
        else:
            # Seek to the end of the current frame
            if ( MasterFrameHeader.TotalFrameSizeInBytes == 0 ):
                # older code may not populate TotalFrameSizeInBytes, hardcode 0x80000
                FrameSizeInByte = 0x80000
            else:
                FrameSizeInByte = MasterFrameHeader.TotalFrameSizeInBytes
            CurFileOffset = ( ( FrameStartOffset - M_ByteSizeOf(wltr_frame_header) ) +
                FrameSizeInByte ) - M_ByteSizeOf(wltr_frame_footer)

        CurFrameFooter = wltr_frame_footer(RawData[CurFileOffset:CurFileOffset+M_ByteSizeOf(wltr_frame_footer)])

        if ( CurFrameFooter.WltrFrameSignature != ExpectedFrameFooterSignature and Verbose):
            print("***Unexpected footer signature found ({0:08x}) offset = {1}\n".format(CurFrameFooter.WltrFrameSignature, hex(CurFileOffset)))
            # return 1
        elif ( CurFrameFooter.FrameNum != CurFrameHeader.FrameNum and Verbose):
            print("***Unexpected Frame Number in Frame Footer ({0:08x})\n".format(CurFrameFooter.FrameNum))
            # return 1
    return 0


def ParseFrameContents2( MasterFrameHeader, CurFrameHeader, OutputFile, OutputFileComma, RawData, IndexOffset, ExpectedFrameEnd, Verbose, CheckFooter, OutputFileOption ):
    global EntriesProcessed, BytesProcessed, OpCodeCounters, LbaCodeCounters, XLCodeCounters, LBAFoundInFrame

    #initialize local vars
    CurStartLBACode     = 0
    CurOpCode           = 0
    AdditionalOpcode    = 0
    CurXfrLengthCode    = 0
    PriorOpcode         = 0
    CurrentLBA          = 0
    CurrentOffset       = 0
    CurrentXfrLen       = 0
    CurEntryIdx         = 0
    MarkerCount         = 0
    CurFileOffset       = 0
    FrameStartOffset    = 0
    CurOpCodeString     = None
    MarkerString        = None
    RunningTimeStamp    = 0.0
    RunningTimeStamp    = CurFrameHeader.StartTimestamp & 0xFFFFFFFFFFFF    #12/15/17 way to track a running timestamp   3/9/18 remove Power cycles from field
    PriorXfrLen         = 0               #3/7/18
    ExpectedLastFrameOffset = 0         #3/12/18
    OutputCSV = "op,time(ms),start_lba,xfer_length\n"

    # print RunningTimeStamp
    DriveSNString = (str(chr((MasterFrameHeader.DriveSerialNum & 0x00000000000000ff)))+
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x000000000000ff00) >> 8))+
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x0000000000ff0000) >> 16))+
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x00000000ff000000) >> 24))+
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x000000ff00000000) >> 32))+
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x0000ff0000000000) >> 40))+
                    str(chr((MasterFrameHeader.DriveSerialNum & 0x00ff000000000000) >> 48))+
                    str(chr((MasterFrameHeader.DriveSerialNum & 0xff00000000000000) >> 56)))


    LBAFoundInFrame = 0
    #print "...cur file location = {0:08x}".format(IndexOffset)
    #3/21/18 add filter for MFH Signature
    if ( ( (MasterFrameHeader.WltrMasterFrameSignature & 0xFFFFFC00 )== (WLTR_MASTER_FRAME_SIGNATURE & 0xFFFFFC00) ) or
         ( (MasterFrameHeader.WltrMasterFrameSignature & 0xFFFFFC00 ) == (WLTR_MASTER_FRAME_SIGNATURE_LEGACY& 0xFFFFFC00) ) ):
        DataFlowMode = 0
        ExpectedFrameFooterSignature = WLTR_FRAME_FOOTER_SIGNATURE
    elif ( (MasterFrameHeader.WltrMasterFrameSignature & 0xFFFFFC00 ) == (WLTR_DF_MASTER_FRAME_SIGNATURE & 0xFFFFFC00) ):
        DataFlowMode = 1
        ExpectedFrameFooterSignature = WLTR_DF_FRAME_FOOTER_SIGNATURE
    else:
        print("***Unexpected Master Frame Signature found {0:08x}\n".format(MasterFrameHeader.WltrMasterFrameSignature))
        return 2

    DefaultSectorSize = MasterFrameHeader.DefaultSectorSizeInBytes

    FrameStartOffset = IndexOffset
    
    if OutputFile != None and (OutputFileOption & 2) == 0:
        #4/2/18 exclude normal text file output filename
        PrintColumnHeader(Verbose, OutputFile)

    if OutputFileComma != None and (OutputFileOption & 1) == 1:
        # PrintColumnHeaderCSV(Verbose, OutputFileComma)
        pass

    ExpectedLastFrameOffset = FrameStartOffset + MasterFrameHeader.TotalFrameSizeInBytes            # 0x80000        #3/12/18 need to not make it a fixed 80000h, but from the master header value. 3/21/20 done.

    while ( IndexOffset < ExpectedFrameEnd ):

        CurFileOffset = IndexOffset
        try:
            CurByte = ord(RawData[IndexOffset])
        except:
            CurByte = 0
            if Verbose:
                print("***Unexpected End of Frame encountered, Loc: {0}\n".format(hex(IndexOffset)))

        IndexOffset += 1

        # DataFlowMode = 0
        if ( DataFlowMode ):
            # -----------------------------------------------------------------------------------
            # DataFlow WLTR mode
            # -----------------------------------------------------------------------------------
            if ( ( CurByte & 0xF0 ) == WLTR_DF_REPEAT_LAST_ENTRY_1X ):
                RepeatCount = ( CurByte & 0x0F ) + 1
                OpCodeCounters[CurByte] += 1

                if ( CurOpCodeString == None ):
                    if Verbose:
                        print("***Unexpected Repeat token encountered, Loc: {0}\n".format(hex(CurFileOffset)))
                    #return 1
                    continue

                OutputString = "{0:8} {1:08x} {2:010x} {3:08x} {4:010x} {5}".format(
                    CurEntryIdx, CurFileOffset,
                    CurrentHostLBA,
                    CurrentHostXfrLen,
                    CurrentHostLBA + CurrentHostXfrLen - 1,
                    CurOpCodeString.ljust(OpcodeColumnSize))

                OutputStringCSV = "{0},{1:8},{2:08x},{3:010x},{4:08x},{5:010x},{6}".format(
                    DriveSNString, CurEntryIdx, CurFileOffset,
                    CurrentHostLBA,
                    CurrentHostXfrLen,
                    CurrentHostLBA + CurrentHostXfrLen - 1,
                    CurOpCodeString)

                if Verbose:
                    OutputString = "{0} {1:02x}\n".format(OutputString, CurByte)
                    OutputStringCSV = "{0},{1}\n".format(OutputStringCSV, CurByte)
                else:
                    OutputString = "{0}\n".format(OutputString)
                    OutputStringCSV = "{0}\n".format(OutputStringCSV)

                for i in range(RepeatCount):
                    if OutputFile != None and (OutputFileOption & 2) == 0:
                        #4/2/18 exclude normal text file output filename
                        FilePrintf(OutputFile, OutputString)
                    if OutputFileComma != None and (OutputFileOption & 1) == 1:
                        FilePrintf(OutputFile, OutputStringCSV)
                    #if seaching for a specific LBA, then output this entry to stdout if it overlaps
                    OutputEntryIfLBAFound( CurrentHostLBA, CurrentHostXfrLen, OutputString, OutputStringCSV, CurFrameHeader, Verbose )

                    CurEntryIdx += 1
                    if ( ( PriorOpcode & 0xFF ) == WLTR_DF_ADDITIONAL_ENCODE_BYTE ):
                        AdditionalOpCodeCounters[PriorOpcode >> 8] += 1
                    else:
                        OpCodeCounters[PriorOpcode] += 1
                EntriesProcessed += RepeatCount
                continue
            elif ( ( CurByte & 0xF0 ) == WLTR_DF_REPEAT_LAST_ENCODING_1X ):
                RepeatCount = ( CurByte & 0x0F ) + 1
                OpCodeCounters[CurByte] += 1

                # Special repeat token
                for i in range(RepeatCount):
                    if CurOpCode == WLTR_DF_ONE_SECOND_MARKER:
                        # print ("Before: ", RunningTimeStamp)
                        #12/20/18 Suppose one second should be +=1000000, could have been due to truncated file
                        #         from FA (?) due to the tranfer length handling on system 4K drives.
                        RunningTimeStamp+=1000000    #12/15/17 25 ms.
                        # print ("After: ", RunningTimeStamp)
                        MarkerString = "{0}({1})".format(OneSecondMarkerString, MarkerCount).ljust(OpcodeColumnSize)
                        MarkerStringCSV = "{0},{1},{2},{3},{4}".format(DriveSNString, RunningTimeStamp, RunningTimeStamp/3600000000.0, OneSecondMarkerString, MarkerCount)

                        MarkerCount += 1
                        # ONE_SECOND_MARKER
                        if OutputFile != None and (OutputFileOption & 2) == 0:
                            FilePrintf(OutputFile, "{0:8} {1:08x} ---------- -------- ---------- {2}".format(
                                CurEntryIdx, CurFileOffset, MarkerString))
                        if OutputFileComma != None and (OutputFileOption & 1) == 1:
                            FilePrintf(OutputFileComma, "{0},{1},{2}".format(
                                CurEntryIdx, CurFileOffset, MarkerStringCSV))

                        CurEntryIdx += 1

                        if OutputFile != None and (OutputFileOption & 2) == 0:
                            if ( Verbose ):
                                FilePrintf(OutputFile, " {0:02x}\n".format(CurByte))
                            else:
                                FilePrintf(OutputFile, "\n")
                        if OutputFileComma != None and (OutputFileOption & 1) == 1:
                            if ( Verbose ):
                                FilePrintf(OutputFileComma, ",{0:02x}\n".format(CurByte))
                            else:
                                FilePrintf(OutputFileComma, "\n")

                    else:
                        if CurOpCodeString == None:
                            if Verbose:
                                print("***Unexpected Repeat token encountered, Loc: {0}\n".format(hex(CurFileOffset)))
                            #return 1
                            continue

                        if ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_SEQUENTIAL_TO_LAST_CMD:
                            # Sequential to Prev
                            CurrentLBA = PriorLBA + PriorXfrLen
                        elif ( ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_1_BYTE_POS_OFFSET ) or
                               ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_2_BYTE_POS_OFFSET ) or
                               ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_3_BYTE_POS_OFFSET ) ):
                            # Positive Sequential
                            CurrentLBA = PriorLBA + CurrentOffset
                        elif ( ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_1_BYTE_NEG_OFFSET ) or
                               ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_2_BYTE_NEG_OFFSET ) or
                               ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_3_BYTE_NEG_OFFSET ) ):
                            # Negative Sequential
                            CurrentLBA = PriorLBA - CurrentOffset

                        PriorLBA = CurrentLBA

                        CurrentHostLBA      = GetHostSectorForEntry(CurrentLBA, PriorOpcode)
                        if CurXfrLengthCode == WLTR_DF_XL_INFINITE:
                            CurrentHostXfrLen = CurrentXfrLen
                        else:
                            CurrentHostXfrLen = GetHostSectorForEntry(CurrentXfrLen, PriorOpcode)
                        OutputString = "{0:8} {1:08x} {2:010x} {3:08x} {4:010x} {5}".format(
                            CurEntryIdx, CurFileOffset, CurrentHostLBA, CurrentHostXfrLen,
                            CurrentHostLBA + CurrentHostXfrLen - 1,
                            CurOpCodeString.ljust(OpcodeColumnSize))
                        # 12/15/17 change formats to comma delimited
                        OutputStringCSV = "{0},{1},{2},{3},{4},{5},{6},{7},{8}".format(
                            DriveSNString, CurEntryIdx, RunningTimeStamp, RunningTimeStamp/3600000000.0, CurFileOffset, CurrentHostLBA, CurrentHostXfrLen,
                            CurrentHostLBA + CurrentHostXfrLen - 1,
                            CurOpCodeString)

                        if ( Verbose ):
                            OutputString = "{0} {1:02x}\n".format(OutputString, CurByte)
                        else:
                            OutputString = "{0}\n".format(OutputString)

                        if OutputFileComma != None and (OutputFileOption & 1) == 1:
                            if ( Verbose ):
                                FilePrintf(OutputFileComma, ",{0},{1:02x}\n".format(OutputString, CurByte))
                            else:
                                FilePrintf(OutputFileComma, "\n")

                        if OutputFile != None and (OutputFileOption & 2) == 0:
                            FilePrintf(OutputFile, OutputString)
                        if OutputFileComma != None and (OutputFileOption & 1) == 1:
                            FilePrintf(OutputFileComma, OutputStringCSV)

                        #if seaching for a specific LBA, then output this entry to stdout if it overlaps
                        OutputEntryIfLBAFound( CurrentHostLBA, CurrentHostXfrLen, OutputString, OutputStringCSV, CurFrameHeader, Verbose )
                        CurEntryIdx += 1
                        if ( ( PriorOpcode & 0xFF ) == WLTR_DF_ADDITIONAL_ENCODE_BYTE ):
                            AdditionalOpCodeCounters[PriorOpcode >> 8] += 1
                        else:
                            OpCodeCounters[PriorOpcode] += 1
                EntriesProcessed += RepeatCount
                continue

            CurOpCode = CurByte
            OpCodeCounters[CurOpCode] += 1

            if ( CurOpCode == WLTR_DF_ONE_SECOND_MARKER ):
                # print ("Before: ", RunningTimeStamp)
                RunningTimeStamp+=25000    #12/15/17 25 ms.
                # print ("After: ", RunningTimeStamp)

                MarkerString = "{0} ({1})".format(OneSecondMarkerString, MarkerCount).ljust(OpcodeColumnSize)
                MarkerStringCSV =  "{0},{1},{2},{3},{4}".format(DriveSNString,RunningTimeStamp, RunningTimeStamp/3600000000.0, OneSecondMarkerString, MarkerCount)
                MarkerCount += 1
                # ONE_SECOND_MARKER
                if OutputFile != None and (OutputFileOption & 2) == 0:
                    FilePrintf(OutputFile, "{0:8} {1:08x} ---------- -------- ---------- {2}".format(
                        CurEntryIdx, CurFileOffset, MarkerString))
                if OutputFileComma != None and (OutputFileOption & 1) == 1:
                    FilePrintf(OutputFileComma, "{0},{1},{2},{3}".format(
                        DriveSNString, CurEntryIdx, CurFileOffset, MarkerStringCSV))

                CurEntryIdx += 1
                EntriesProcessed += 1

                if OutputFile != None and (OutputFileOption & 2) == 0:
                    if ( Verbose ):
                        FilePrintf( OutputFile, " {0:02x}\n".format(CurByte) )
                    else:
                        FilePrintf(OutputFile, "\n")
                if OutputFileComma != None and (OutputFileOption & 1) == 1:
                    if ( Verbose ):
                        FilePrintf( OutputFileComma, ",{0:02x}\n".format(CurByte) )
                    else:
                        FilePrintf(OutputFileComma, "\n")
                continue
            elif ( CurOpCode == WLTR_DF_TRACE_HALTED ):
                HaltedOpCodeString = "WLTR_DF_TRACE_HALTED"
                if OutputFile != None and (OutputFileOption & 2) == 0:
                    FilePrintf(OutputFile, "{0:8} {1:08x} ---------- -------- ---------- {2}".format(
                        CurEntryIdx, CurFileOffset, HaltedOpCodeString.ljust(OpcodeColumnSize)))
                if OutputFileComma != None and (OutputFileOption & 1) == 1:
                    FilePrintf(OutputFileComma, "{0:8} {1:08x} ---------- -------- ---------- {2}".format(
                        CurEntryIdx, CurFileOffset, HaltedOpCodeString.ljust(OpcodeColumnSize)))
                CurEntryIdx += 1
                EntriesProcessed += 1
                if OutputFile != None and (OutputFileOption & 2) == 0:
                    if ( Verbose ):
                        FilePrintf(OutputFile, " {0:02x}\n".format(CurOpCode))
                    else:
                        FilePrintf(OutputFile, "\n")
                if OutputFileComma != None and (OutputFileOption & 1) == 1:
                    if ( Verbose ):
                        FilePrintf(OutputFileComma, ",{0:02x}\n".format(CurOpCode))
                    else:
                        FilePrintf(OutputFileComma, "\n")

                sys.stdout.write("...WARNING: Trace Halt detected in Frame {0}, Entry {1}\n".format(
                    CurFrameHeader.FrameNum, CurEntryIdx - 1))
                continue

            # Need an additional encode byte
            CurByte = ord(RawData[IndexOffset])
            IndexOffset += 1

            if ( IndexOffset > ExpectedFrameEnd ):
                if Verbose:
                    print("1-***Unexpected End-of-Frame detected, expected encode byte at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                #return 1
                continue

            CurStartLBACode   = (CurByte & WLTR_DF_LBA_MASK) >> WLTR_DF_LBA_FIELD_OFFSET
            CurXfrLengthCode  = (CurByte & WLTR_DF_XFR_LENGTH_MASK)

            LbaCodeCounters[CurStartLBACode] += 1
            XLCodeCounters[CurXfrLengthCode] += 1

            # OpCode encoding
            if ( CurOpCode == WLTR_DF_ADDITIONAL_ENCODE_BYTE ):
                # Need an additional encode byte
                try:        #3/21/20
                    CurByte = ord(RawData[IndexOffset])
                except:
                    CurByte = 0
                IndexOffset += 1
                if ( IndexOffset > ExpectedFrameEnd ):
                    if Verbose:
                        print("2-***Unexpected End-of-Frame detected, expected additional encode byte at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                    #return 1
                    continue
                AdditionalOpcode = CurByte
                # debug
                # printf("...AddOp:%02x\n", AdditionalOpcode)
                CurOpCodeString = DataFlowAdditionalOpCodeStrings[AdditionalOpcode]
                PriorOpcode = CurOpCode + (AdditionalOpcode << 8)
            elif ( CurOpCode > WLTR_DF_MAX_VALID_OPCODE ) or ( DataFlowOpCodeStrings[CurOpCode] == 0 ):
                if Verbose:
                    print("*** Unexpected OpCode ({0:02x}), Loc:{1}\n".format(CurOpCode, hex(CurFileOffset)))
                #return 1
                CurOpCodeString = "UNKNOWN_{0:02x}".format(CurOpCode)
                PriorOpcode = CurOpCode
            else:
                CurOpCodeString = DataFlowOpCodeStrings[CurOpCode]
                PriorOpcode = CurOpCode

            #
            # Transfer Length decode
            #
            if ( CurXfrLengthCode == WLTR_DF_XL_SAME_AS_LAST ):
                CurrentXfrLen = PriorXfrLen
            elif ( ( CurXfrLengthCode == WLTR_DF_XL_VERBATIM_1_BYTE ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_VERBATIM_2_BYTES ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_VERBATIM_3_BYTES ) ):
                CurrentXfrLen = 0
                for i in range(CurXfrLengthCode):
                    try:        #3/21/20
                        CurByte = ord(RawData[IndexOffset])
                    except:
                        CurByte = 0
                    IndexOffset += 1
                    if ( IndexOffset > ExpectedFrameEnd ):
                        if Verbose:
                            print("3-***Unexpected End-of-Frame detected, expected Transfer Length field at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                        break
                        #return 1
                    CurrentXfrLen |= (CurByte << (i * 8))
                if ( IndexOffset > ExpectedFrameEnd ):      #1/23/18 break out of the loop
                    continue

            elif ( ( CurXfrLengthCode == WLTR_DF_XL_1_BLK ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_2_BLKS ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_4_BLKS ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_8_BLKS ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_16_BLKS ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_32_BLKS ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_64_BLKS ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_128_BLKS ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_256_BLKS ) ):
                CurrentXfrLen = DataFlowTransferLengthArray[CurXfrLengthCode - 4]
            elif ( ( CurXfrLengthCode == WLTR_DF_XL_SHIFT_1_BYTE ) or
                   ( CurXfrLengthCode == WLTR_DF_XL_SHIFT_2_BYTES ) ):
                # Shifted by 8 bits
                CurrentXfrLen = 0
                for i in range(CurXfrLengthCode - 0xC):
                    try:        #3/21/20
                        CurByte = ord(RawData[IndexOffset])
                    except:
                        CurByte = 0
                    IndexOffset += 1
                    if ( IndexOffset > ExpectedFrameEnd ):
                        if Verbose:
                            print("4-***Unexpected End-of-Frame detected, expected Transfer Length field at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                        break
                        #return 1
                    CurrentXfrLen |= (CurByte << (i * 8))
                if ( IndexOffset > ExpectedFrameEnd ):      #1/23/18 break out of the loop
                    continue

                CurrentXfrLen = CurrentXfrLen << 8
            elif ( CurXfrLengthCode == WLTR_DF_XL_INFINITE ):
                CurrentXfrLen = 0xFFFFFFFF
            else:
                if Verbose:
                    print("*** Unexpected OpCode ({0:02x}), Loc:{1}\n".format(CurXfrLengthCode, hex(CurFileOffset)))
                continue
                #return 1

            #
            # Start LBA decode
            #
            if ( ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_SIZE_1_BYTE ) or
                 ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_SIZE_2_BYTES ) or
                 ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_SIZE_3_BYTES ) or
                 ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_SIZE_4_BYTES ) or
                 ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_SIZE_5_BYTES ) ):
                CurrentLBA = 0
                for i in range(CurStartLBACode):
                    try:        #3/21/20
                        CurByte = ord(RawData[IndexOffset])
                    except:
                        CurByte = 0
                    IndexOffset += 1
                    if ( IndexOffset > ExpectedFrameEnd ):
                        if Verbose:
                            print("5-***Unexpected End-of-Frame detected, expected Start LBA field at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                        break
                        #return 1
                    CurrentLBA |= (CurByte << (i * 8))
                if ( IndexOffset > ExpectedFrameEnd ):      #1/23/18 break out of the loop
                    continue
                #print "...LBA:{0:08x}".format(CurrentLBA)
                if ( ( CurByte == 0x00 ) and ( i > 1 ) ):
                    # high order byte is unexpectedly 0
                    if Verbose:
                        print("*** Unexpected value for CurStartLBACode, Loc:{0}\n".format(CurFileOffset))
            elif ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET) ==  WLTR_DF_LBA_SEQUENTIAL_TO_LAST_CMD ):
                # Sequential
                CurrentLBA = PriorLBA + PriorXfrLen
            elif ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_SAME_AS_LAST_CMD ):
                # Same as prev
                CurrentLBA = PriorLBA
            elif ( ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_1_BYTE_POS_OFFSET ) or
                   ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_2_BYTE_POS_OFFSET ) or
                   ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_3_BYTE_POS_OFFSET ) or
                   ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_1_BYTE_NEG_OFFSET ) or
                   ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_2_BYTE_NEG_OFFSET ) or
                   ( ( CurStartLBACode << WLTR_DF_LBA_FIELD_OFFSET ) == WLTR_DF_LBA_3_BYTE_NEG_OFFSET ) ):
                # Offset, either positive or negative.
                CurrentOffset = 0
                for i in range(CurStartLBACode & 0x03):
                    try:        #3/21/20
                        CurByte = ord(RawData[IndexOffset])
                    except:
                        CurByte = 0
                    IndexOffset += 1
                    if ( IndexOffset > ExpectedFrameEnd ):
                        if Verbose:
                            print("6-***Unexpected End-of-Frame detected, expected LBA Offset field at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                        break
                        #return 1
                    CurrentOffset |= (CurByte << (i * 8))
                if ( IndexOffset > ExpectedFrameEnd ):      #1/23/18 break out of the loop
                    continue

                # print ("...LBO:{0:08x}".format(CurrentOffset))
                if ( ( CurByte == 0x00 ) and ( i > 1 ) ):
                    # high order byte is unexpectedly 0
                    if Verbose:
                        print("*** Unexpected value for CurrentOffset, Loc: {0}\n".format(hex(CurFileOffset)))
                if ( CurrentOffset == 0 ):
                    if Verbose:
                        print("***Unexpected zero offset, Loc: {0}\n".format(hex(CurFileOffset)))

                if ( CurStartLBACode & 0x04 ):
                    CurrentLBA = PriorLBA - CurrentOffset
                else:
                    CurrentLBA = PriorLBA + CurrentOffset
            else:
               if Verbose:
                   print("***Unexpected value for LBA Code({0:02x}), Loc:{1}\n".format(CurStartLBACode, hex(CurFileOffset)))
               continue
               #return 1

            CurrentHostLBA      = GetHostSectorForEntry(CurrentLBA, PriorOpcode)
            if CurXfrLengthCode == WLTR_DF_XL_INFINITE:
                CurrentHostXfrLen = CurrentXfrLen
            else:
                CurrentHostXfrLen = GetHostSectorForEntry(CurrentXfrLen, PriorOpcode)

            OutputString = "{0:8} {1:08x} {2:010x} {3:08x} {4:010x} {5}".format(
                CurEntryIdx, CurFileOffset, CurrentHostLBA, CurrentHostXfrLen,
                CurrentHostLBA + CurrentHostXfrLen - 1,
                CurOpCodeString.ljust(OpcodeColumnSize))

            OutputStringCSV = "{0},{1},{2},{3},{4},{5}".format(
                CurEntryIdx, CurFileOffset, CurrentHostLBA, CurrentHostXfrLen,
                CurrentHostLBA + CurrentHostXfrLen - 1,
                CurOpCodeString)

            if ( Verbose ):
                OutputString = "{0} {1:02x}    {2:1x}     {3:1x}".format(
                    OutputString, CurOpCode, CurStartLBACode, CurXfrLengthCode )
                OutputStringCSV = ",{0},{1},{2},{3}".format(
                    OutputStringCSV, CurOpCode, CurStartLBACode, CurXfrLengthCode )

                if IsLBAFieldOffset(CurStartLBACode, DataFlowMode):
                    OutputString = "{0}     {1:08x}\n".format(OutputString, CurrentOffset)
                    OutputStringCSV = ",{0},{1}\n".format(OutputString, CurrentOffset)
                else:
                    OutputString = "{0}\n".format(OutputString)
                    OutputStringCSV = ",{0}\n".format(OutputString)
            else:
                OutputString = "{0}\n".format(OutputString)
                OutputStringCSV = ",{0}\n".format(OutputString)


            if OutputFile != None and (OutputFileOption & 2) == 0:
                FilePrintf(OutputFile, OutputString)
            if OutputFileComma != None and (OutputFileOption & 1) == 1:
                FilePrintf(OutputFileComma, OutputStringCSV)

            #if seaching for a specific LBA, then output this entry to stdout if it overlaps
            OutputEntryIfLBAFound( CurrentHostLBA, CurrentHostXfrLen, OutputString, OutputStringCSV, CurFrameHeader, Verbose )

            CurEntryIdx += 1
            EntriesProcessed += 1

        # End Dataflow WLTR mode
        else:
            # -----------------------------------------------------------------------------------
            # Classic WLTR mode
            # -----------------------------------------------------------------------------------
            CurStartLBACode = (CurByte & WLTR_LBA_FIELD_MASK)
            CurOpCode = (CurByte & WRITE_COMMAND_TRACE) >> 3
            CurXfrLengthCode = (CurByte >> XFR_LENGTH_BIN_MASK_SHIFT_COUNT)

            XLCodeCounters[CurXfrLengthCode] += 1

            SkipLBACheck = 0

            if ( ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == ONE_BLOCK ) or
                 ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == TWO_BLOCKS ) or
                 ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == FOUR_BLOCKS ) or
                 ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == EIGHT_BLOCKS ) or
                 ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == SIXTEEN_BLOCKS ) or
                 ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == THIRTY_TWO_BLOCKS ) or
                 ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == ONE_HUNDRED_TWENTY_EIGHT ) or
                 ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == TWO_HUNDRED_FIFTY_SIXTY_BLOCKS ) ):
                CurrentXfrLen = TransferLengthArray[CurXfrLengthCode]
            elif ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == XFR_LENGTH_SAME_AS_LAST_CMD ):
                CurrentXfrLen = PriorXfrLen
            elif ( ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == VERBATIM_1_BYTE ) or
                   ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == VERBATIM_2_BYTES ) ):
                CurrentXfrLen = 0
                for i in range(CurXfrLengthCode - 8):
                    try:        #3/21/20
                        CurByte = ord(RawData[IndexOffset])
                    except:
                        CurByte = 0
                    IndexOffset += 1
                    if ( IndexOffset > ExpectedFrameEnd ):
                        if Verbose:
                            print("7-***Unexpected End-of-Frame detected, expected Transfer Length field at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                        #return 1
                        break
                    CurrentXfrLen |= (CurByte << (i * 8))
                if ( IndexOffset >= ExpectedFrameEnd ):      #1/23/18 break out of the loop  3/21/20 make it >= from >
                    continue
            elif ( ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == WLTR_RESERVED_1 ) or
                   ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == WLTR_RESERVED_2 ) ):
                if Verbose:
                    print("***Unexpected RESERVED value for CurXfrLengthCode({0:02x}), Loc:{1}\n".format(CurXfrLengthCode, hex(CurFileOffset)))
                SkipLBACheck = 1
            elif ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == STREAMING_STARTED ):
                # Streaming Started
                CurrentLBA = 0
                for i in range(5):
                    if ( IndexOffset >= ExpectedFrameEnd ):      #1/23/18 break out of the loop  3/21/20 make it ">=" from ">" and   move it above the pull
                        if Verbose:
                            print("8-***Unexpected End-of-Frame detected, expected Stream LBA field at offset {0}pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                        #return 1
                        break
                    try:        #3/21/20
                        CurByte = ord(RawData[IndexOffset])
                    except:
                        CurByte = 0
                    IndexOffset += 1
                    CurrentLBA |= (CurByte << (i * 8))
                if ( IndexOffset >= ExpectedFrameEnd ):      #1/23/18 break out of the loop  3/21/20 make it >= from >
                    continue
                CurrentXfrLen = PriorXfrLen
                SkipLBACheck = 1
            elif ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == STREAMING_TERMINATED ):
                CurrentLBA = 0
                for i in range(5):
                    if ( IndexOffset > ExpectedFrameEnd ):
                        if Verbose:
                            print("9-***Unexpected End-of-Frame detected, expected Stream LBA field at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                        #return 1
                        break
                    try:        #3/21/20
                        CurByte = ord(RawData[IndexOffset])
                    except:
                        CurByte = 0
                    IndexOffset += 1
                    CurrentLBA |= (CurByte << (i * 8))
                if ( IndexOffset >= ExpectedFrameEnd ):      #1/23/18 break out of the loop  3/21/20 make it >= from >
                    continue
                CurrentXfrLen = PriorXfrLen
                SkipLBACheck = 1
            elif ( ( CurXfrLengthCode << WLTR_DF_LBA_FIELD_OFFSET ) == ONE_SECOND_MARKER ):
                SkipLBACheck = 1
                #RunningTimeStamp+=25000    #12/15/17 25ms

            if ( SkipLBACheck == 0 ):
                LbaCodeCounters[CurStartLBACode] += 1

                if ( CurStartLBACode == ABSOLUTE_START_LBA ):
                    CurrentLBA = 0
                    if ( (IndexOffset+5) >= ExpectedFrameEnd ):       # 3/21/20 move above loop
                        if Verbose:
                            print("10-***Unexpected End-of-Frame detected, expected LBA field at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                        #return 1
                        break
                    for i in range(5):
                        try:        #3/21/20
                            CurByte = ord(RawData[IndexOffset])
                        except:
                            CurByte = 0
                        IndexOffset += 1
                        CurrentLBA |= (CurByte << (i * 8))
                    if ( IndexOffset >= ExpectedFrameEnd ):      #1/23/18 break out of the loop  3/21/20 make it >= from >
                        continue
                elif ( ( CurStartLBACode == SINGLE_BYTE_OFFSET ) or
                       ( CurStartLBACode == TWO_BYTE_OFFSET ) or
                       ( CurStartLBACode == THREE_BYTE_OFFSET ) ):
                    CurrentOffset = 0
                    if ( (IndexOffset+CurStartLBACode) >= ExpectedFrameEnd ):       # 3/21/20 move above loop
                        if Verbose:
                            print("11-***Unexpected End-of-Frame detected, expected LBA Offset field at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                        #return 1
                        break
                    for i in range(CurStartLBACode):
                        try:        #3/21/20
                            CurByte = ord(RawData[IndexOffset])
                        except:
                            CurByte = 0
                        IndexOffset += 1
                        CurrentOffset |= (CurByte << (i * 8))
                    CurrentLBA = PriorLBA + CurrentOffset
                    if ( IndexOffset >= ExpectedFrameEnd ):      #1/23/18 break out of the loop  3/21/20 make it >= from >
                        continue
                elif ( CurStartLBACode == SEQUENTIAL_TO_LAST_CMD ):
                    CurrentLBA = PriorLBA + PriorXfrLen
                elif ( ( CurStartLBACode == SINGLE_BYTE_NEGATIVE_OFFSET ) or
                       ( CurStartLBACode == TWO_BYTE_NEGATIVE_OFFSET ) or
                       ( CurStartLBACode == THREE_BYTE_NEGATIVE_OFFSET ) ):
                    CurrentOffset = 0
                    if ( (IndexOffset + CurStartLBACode - SINGLE_BYTE_NEGATIVE_OFFSET + 1) >= ExpectedFrameEnd ):       # 3/21/20 move above loop
                        if Verbose:
                            print("12-***Unexpected End-of-Frame detected, expected LBA Offset field at offset {0} pointer beyond expected end of frame {1}\n".format(IndexOffset, ExpectedFrameEnd))
                        #return 1
                        break
                    for i in range(CurStartLBACode - SINGLE_BYTE_NEGATIVE_OFFSET + 1):
                        try:        #3/21/20
                            CurByte = ord(RawData[IndexOffset])
                        except:
                            CurByte = 0
                        IndexOffset += 1
                        CurrentOffset |= (CurByte << (i * 8))
                    if ( IndexOffset >= ExpectedFrameEnd ):      #1/23/18 break out of the loop  3/21/20 make it >= from >
                        continue
                    CurrentLBA = PriorLBA - CurrentOffset

            if ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == STREAMING_STARTED ):
                OutputStringCSV = ''
                # CurOpCodeString = "STREAMING STARTED"
                # OutputString = "{0:8} {1:08x} {2:010x} -------- ---------- {3}".format(
                #     CurEntryIdx, CurFileOffset, CurrentLBA, CurOpCodeString.ljust(OpcodeColumnSize))
                # # 12/15/17
                # OutputStringCSV = "{0},{1},{2},{3},{4},{5},,{6}".format(
                #     DriveSNString, CurEntryIdx, RunningTimeStamp, RunningTimeStamp/36000000000.0, CurFileOffset, CurrentLBA, CurOpCodeString)
            elif ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == STREAMING_TERMINATED ):
                OutputStringCSV = ''
            #     CurOpCodeString = "STREAMING TERMINATED"
            #     OutputString = "{0:8} {1:08x} {2:010x} -------- ---------- {3}".format(
            #         CurEntryIdx, CurFileOffset, CurrentLBA, CurOpCodeString.ljust(OpcodeColumnSize))
            #     # 12/15/17
            #     OutputStringCSV = "{0},{1},{2},{3},{4},{5},,,{6}".format(
            #         DriveSNString, CurEntryIdx, RunningTimeStamp, RunningTimeStamp/36000000000.0, CurFileOffset, CurrentLBA, CurOpCodeString)
            elif ( ( CurXfrLengthCode << XFR_LENGTH_BIN_MASK_SHIFT_COUNT ) == ONE_SECOND_MARKER ):
                RunningTimeStamp+=25000    #12/15/17 25 ms.
                OutputStringCSV = ''
                # CurOpCodeString = "{0}({1})".format(OneSecondMarkerString, MarkerCount)
                # MarkerCount += 1
                # OutputString = "{0:8} {1:08x} ---------- -------- ---------- {2}".format(
                #     CurEntryIdx, CurFileOffset, CurOpCodeString.ljust(OpcodeColumnSize))
                # #12/15/17
                # OutputStringCSV = "{0},{1},{2},{3},{4},,,,{5}".format(
                #     DriveSNString, CurEntryIdx, RunningTimeStamp, RunningTimeStamp/36000000000.0, CurFileOffset, CurOpCodeString)
            else:
                OpCodeCounters[CurOpCode] += 1
                if CurOpCode:
                    CurOpCodeString = "WRITE"
                else:
                    CurOpCodeString = "READ"
                OutputString = "{0:8} {1:08x} {2:010x} {3:08x} {4:010x} {5}".format(
                    CurEntryIdx, CurFileOffset, CurrentLBA, CurrentXfrLen,
                    CurrentLBA + CurrentXfrLen - 1,
                    CurOpCodeString.ljust(OpcodeColumnSize))
                12/15/17
                OutputStringCSV = "{0},{1},{2},{3}".format(
                    CurOpCodeString, round(RunningTimeStamp*0.001), CurrentLBA, CurrentXfrLen)
                # verbose = 0
            if Verbose:
                OutputString = "{0} {1:1x}     {2:1x}     {3:1x}".format(
                    OutputString,
                    CurOpCode, CurStartLBACode, CurXfrLengthCode )
                OutputStringCSV = "{0},{1},{2},{3}".format(
                    OutputStringCSV,
                    CurOpCode, CurStartLBACode, CurXfrLengthCode )
                if ( ( SkipLBACheck == 0 ) and
                    IsLBAFieldOffset( CurStartLBACode, DataFlowMode ) ):
                    OutputString = "{0}     {1:08x}\n".format(OutputString, CurrentOffset)
                    OutputStringCSV = "{0},{1}\n".format(OutputStringCSV, CurrentOffset)
                else:
                    OutputString = "{0}\n".format(OutputString)
                    OutputStringCSV = "{0}\n".format(OutputStringCSV)
            else:
                # OutputString = "{0}\n".format(OutputString)
                OutputStringCSV = "{0}\n".format(OutputStringCSV)

            if OutputFileComma != None and (OutputFileOption & 1) == 1 and CurrentLBA > 0:
                OutputCSV += OutputStringCSV
            # if OutputFile != None and (OutputFileOption & 2) == 0:
            #     FilePrintf( OutputFile, OutputString )
            # if OutputFileComma != None and (OutputFileOption & 1) == 1:
            #     FilePrintf( OutputFileComma, OutputStringCSV )
            if SkipLBACheck == 0:
                OutputEntryIfLBAFound( CurrentLBA, CurrentXfrLen, OutputString, OutputStringCSV, CurFrameHeader, Verbose )

            CurEntryIdx += 1
            EntriesProcessed += 1

            if IndexOffset > ExpectedLastFrameOffset and Verbose:
                print("!***Current offset is beyond End-of-Frame location has been detected, Current offset = ({0:08x}) End of Frame = {1:08x}\n".format(IndexOffset, ExpectedLastFrameOffset))

        # End classic WLTR mode

        # preserve the current information as a prior amount
        PriorLBA = CurrentLBA
        PriorXfrLen = CurrentXfrLen

    CurFileOffset = IndexOffset
    BytesProcessed += (CurFileOffset - FrameStartOffset)

    #print "...checking footer"

    # Check frame footer
    if ( CheckFooter != 0 ):
        if ( IndexOffset > ExpectedFrameEnd and Verbose):
            print("***Unexpected End-of-Frame detected, expecting footer offset = ({0:08x}) EoFrame = {1:08x}\n".format(IndexOffset, ExpectedFrameEnd))
            # return 1

        if DataFlowMode:
            # Round up to the nearest sector size
            CurFileOffset = ( ( CurFileOffset + M_ByteSizeOf(wltr_frame_footer) + DefaultSectorSize - 1 ) /
                DefaultSectorSize *
                DefaultSectorSize ) - M_ByteSizeOf(wltr_frame_footer)
        else:
            # Seek to the end of the current frame
            if ( MasterFrameHeader.TotalFrameSizeInBytes == 0 ):
                # older code may not populate TotalFrameSizeInBytes, hardcode 0x80000
                FrameSizeInByte = 0x80000
            else:
                FrameSizeInByte = MasterFrameHeader.TotalFrameSizeInBytes
            CurFileOffset = ( ( FrameStartOffset - M_ByteSizeOf(wltr_frame_header) ) +
                FrameSizeInByte ) - M_ByteSizeOf(wltr_frame_footer)

        CurFrameFooter = wltr_frame_footer(RawData[CurFileOffset:CurFileOffset+M_ByteSizeOf(wltr_frame_footer)])

        if ( CurFrameFooter.WltrFrameSignature != ExpectedFrameFooterSignature and Verbose):
            print("***Unexpected footer signature found ({0:08x}) offset = {1}\n".format(CurFrameFooter.WltrFrameSignature, hex(CurFileOffset)))
            # return 1
        elif ( CurFrameFooter.FrameNum != CurFrameHeader.FrameNum and Verbose):
            print("***Unexpected Frame Number in Frame Footer ({0:08x})\n".format(CurFrameFooter.FrameNum))
            # return 1
    
    return 0, OutputCSV