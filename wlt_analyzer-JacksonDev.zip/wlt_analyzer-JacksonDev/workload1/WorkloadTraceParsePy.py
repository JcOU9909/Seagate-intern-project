import sys, os
import time
from PlatformCStructs import *
from WorkloadTraceParseRTO import *
from WorkloadTraceUtils import *
from IBTParserPy import *

def main():
    Verbose         = 0
    DiscFile        = 1
    StartOffset     = 0
    DataFlowMode    = 0
    SearchLBAValid  = 0
    HostBlocksPerDiscSector = 1
    OutputFilename  = None
    OutputFile      = None
    OutputFileComma = None
    ReturnStatus    = 0
    OutputFileOption= 0       # By default get text output, csv would be optiona1  bit 0 means output CSV  bit 1 means exclude normal text output
    FileDoneNotation= 0

    # added NumEntry to passes parameters
    InputFilename, Verbose, DiscFile, StartOffset, DataFlowMode, SearchLBAValid, HostBlocksPerDiscSector, OutputFilename, OutputFile, OutputFileComma, OutputFileOption, FileDoneNotation, NumEntry = WorkLoadTraceCommandLineHandler()
    ReturnStatus = ParseWorkloadTrace(InputFilename, Verbose, DiscFile, StartOffset, DataFlowMode, SearchLBAValid, HostBlocksPerDiscSector, OutputFilename, OutputFile, OutputFileComma, OutputFileOption, NumEntry )

    # 3/13/18 add this for higher level calling function
    if (not FileDoneNotation == 0):
        DoneOutputFile = open("ParseDone2004.txt","w")
        DoneOutputFile.write(time.asctime() + '\n')
        # 12/7/18 added output error notation.
        if ReturnStatus == 1:
            DoneOutputFile.write('File Size too Large\n')
        elif ReturnStatus == 2:
            DoneOutputFile.write('Error opening input file\n')
        elif ReturnStatus == 3:
            DoneOutputFile.write('Too Few Command Line Input Parameters\n')
        elif ReturnStatus == 4:
            DoneOutputFile.write('Unexpected Master Frame Signature Detected\n')
        elif ReturnStatus == 5:
            DoneOutputFile.write('Unexpected Frame Signature Detected\n')
        DoneOutputFile.close()


if __name__ == "__main__":
    main()
    print("Helloworld")