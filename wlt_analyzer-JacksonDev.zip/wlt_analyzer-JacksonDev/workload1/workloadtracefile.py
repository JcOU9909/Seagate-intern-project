# setup.py
# Batch to Create a DOS called file to call the
# TimeOrder.py code for doing a UDS Segmented file into a TimeOrdered File
from distutils.core import setup
import py2exe
      
# setup(console=["timeorder.py"])
setup(console=["WorkLoadTraceParsePy.py"])
