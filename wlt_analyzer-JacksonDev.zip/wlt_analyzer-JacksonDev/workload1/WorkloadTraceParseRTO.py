import sys, os
from .PlatformCStructs import *
from .WorkloadTraceUtils import *
from .IBTParserPy import *              #3/5/18
import traceback

Version = "v1.2 02/28/2023"

##############################################################################################
#
# Print help
#
##############################################################################################
def Usage(Msg=None):

    if Msg != None:
         print( "***** %s\n\n" % Msg )

    print("WorkloadTraceParsePy " + Version + "   Platform OS:" + sys.platform )
    print("Usage: WorkloadTraceParsePy Inputfile (options) | ")
    print(" Seagate Technology, PLC")
    print(" Copyright 2015-2020, All Rights Reserved")
    print("  Where:")
    print("   inputfile        - binary WorkloadTrace disc or buffer frame file")
    print("   options:")
    print("   -f <outputfile>  - Text output file base name.")
    print("                      Because the parsed files may be large, there may be")
    print("                      multiple files created. These files will have the format")
    print("                      'outputfile'_n.txt, where 'n' is the frame number")
    print("   -csv             - CSV Text Output. Outputs CSV Format file")
    print("                      entry encoding, output filename is 'outputfile'_n_csv.txt,")
    print("   -notext          - Do not output standard Text Output.")
    print("                      entry encoding, output filename is 'outputfile'_n_csv.txt,")
    print("   -v               - Verbose mode. Outputs additional information on trace")
    print("                      entry encoding")
    print("   -bf              - Buffer File. Indicates the input file is a frame buffer,")
    print("                      not from disc")
    print("   -s <hex offset>  - specify a starting frame offset in hex")
    print("                         (Doesn't apply to Buffer File)")
    print("   -l <hex LBA> (XL)- Output entries overlapping a specific LBA, or LBA range")
    print("                        if a 2nd XL parameter follows")
    print("   -entry <value>   - Limits the number of entries to most recent")
    print("   -e               - specifies 5xxe, translates disc opcode LBA entries to")
    print("                      host blocks")
    print("   -d               - File Done notation")
    return

def WorkLoadTraceCommandLineHandler():
    
    if len(sys.argv) < 2:
          Usage()
          print("Too Few Command Line Input Parameters\n")
          sys.exit(1)
    
    InputFilename = sys.argv[1]

    Verbose         = 0
    DiscFile        = 1
    StartOffset     = 0
    DataFlowMode    = 0
    SearchLBAValid  = 0
    HostBlocksPerDiscSector = 1
    OutputFilename  = None
    OutputFile      = None
    OutputFileNameCSV = None      # 12/18/17
    OutputFileOption= 0         # 3/8/18 default, need cmd line option to do this bit 0=1:CSV Enabled, bit 1=1 (value of 2) Text disabled
    FileDoneNotation= 0
    NumEntry        = 0         #12/12/18 limit the number of entries / records to process

    # parse options
    ArgSkip = 0
    for i in range(2,len(sys.argv)):
        if ArgSkip:
            ArgSkip -= 1
            continue
        if sys.argv[i] == "-f":
            if len(sys.argv) >= i+2:
                OutputFilename = sys.argv[i+1]
                ArgSkip += 1
                OutputFileOption|=4     #3/23/20 add this option...
                # print ("...Output file base name = '{0}'".format(OutputFilename))
        elif sys.argv[i] == "-csv":
            OutputFileOption |= 1
            # print ("...CSV enabled")
        elif sys.argv[i] == "-notext":
            OutputFileOption |= 2
            # print ("...No Text enabled")
        elif sys.argv[i] == "-v":
            Verbose = 1
            # print ("...Verbose enabled")
        elif sys.argv[i] == "-bf":
            DiscFile = 0
            # print ("...Buffer File enabled")
        elif sys.argv[i] == "-d":
            FileDoneNotation = 1
            # print ("...File Done Notation enabled")
        elif sys.argv[i] == "-s":
            if len(sys.argv) >= i+2:
                try:
                    StartOffset = int(sys.argv[i+1], 16)
                except:
                    print ("*** Invalid parameter '{0}'".format(sys.argv[i+1]))
                else:
                    ArgSkip += 1
                    print ("...Starting Offset = 0x{0:1x}".format(StartOffset))
            else:
               print ("...'{0}' detected, but no parameter found".format(sys.argv[i]))
        elif sys.argv[i] == "-entry":
            if len(sys.argv) >= i+2:
                try:
                    NumEntry = int(sys.argv[i+1], 16)
                except:
                    print ("*** Invalid parameter '{0}'".format(sys.argv[i+1]))
                else:
                    ArgSkip += 1
                    print ("...Starting Offset = 0x{0:1x}".format(StartOffset))
            else:
               print ("...'{0}' detected, but no parameter found".format(sys.argv[i]))
        elif sys.argv[i] == "-l":
            if len(sys.argv) >= i+2:
                SearchLBAStart = int(sys.argv[i+1], 16)
                SearchLBAValid = 1
                ArgSkip += 1
                # check for another param which could be a length parameter
                try:
                    SearchTransferLen = int(sys.argv[i+2], 16)
                except:
                    SearchTransferLen = 1
                else:
                    # don't allow a zero or negative transfer length
                    if SearchTransferLen <= 0:
                        SearchTransferLen = 1
                    else:
                        ArgSkip += 1
                SetSearchLBARange(SearchLBAStart, SearchTransferLen)
                if SearchTransferLen != 1:
                    print ("...Search LBA range = ", SearchLBAStart, (SearchLBAStart + SearchTransferLen - 1))
                else:
                    print ("...Search LBA = ", (SearchLBAStart))
            else:
                print ("... detected, but no parameter found ", (sys.argv[i]))
        elif sys.argv[i] == "-e":
            HostBlocksPerDiscSector = 8
            SetHostBlocksPerDiscSector( HostBlocksPerDiscSector )
            #print ("...5xxe enabled, {0} host blocks per disc sector".format(HostBlocksPerDiscSector))
        else:
            print ("*** Unknown option ", (sys.argv[i]))
    if (OutputFileOption & 1) == 1:
            OutputFileNameCSV = OutputFilename  #4/9/18  don't add extension at this point, just define the base name for the CSV file.
    # print ("Input FileName: ", InputFilename)
    return InputFilename, Verbose, DiscFile, StartOffset, DataFlowMode, SearchLBAValid, HostBlocksPerDiscSector, OutputFilename, OutputFile, OutputFileNameCSV, OutputFileOption, FileDoneNotation, NumEntry


def ParseWorkloadTrace(InputFilename, Verbose, DiscFile, StartOffset, DataFlowMode, SearchLBAValid, HostBlockPerDiscSector, OutputFilename, OutputFile, OutputFileNameCSV, OutputFileOption, NumEntry):
    NonModulo200Alignment = 0 
    SavedPreviousFrameOffset = 0                    #3/8/18
    LastUsedWorkaroundPreviousFrameOffset = 0       #3/8/18
    StepOffset = 0x80000                            #Default workload trace frame size
    OutputFilePtrCSV = None                         #
    RawData = ''


    #MaxFileToRead = 980000000                       #1GB file fails to read in Python, set the default file size to read 900000000 was ok, 910000000, now set to 950000000 (3/22/20)
    MaxFileToRead = 0x3bf2e000                       # have seen files as high as 1005772800/0x3bf2e000
    print("WorkloadTraceParse Version %s\n" % Version)
    
    # 3/21/20 convert file handling to an entire file read into a file handler with a flag for the file method....
    OutputFileMethodContent = 0     # 0 = current file method reading the whole file, 1= passing the file handler....
    #print InputFilename    #, InputFilename.tell()
    # Read the input file
    if OutputFileMethodContent == 0:
        try:
            InFileHander = open(InputFilename, 'rb')
            RawData = InFileHander.read(4096)  # only read the header for now
        except:
            print("Couldn't open input file '%s'\n" % InputFilename)
            print(traceback.format_exc())
        InFileHander.seek(0)
    else:
        try:
            filehandle = open(InputFilename, 'rb')
        except:
            sys.stderr.write("Couldn't open input file '%s'\n" % InputFilename)
            Usage()
        filehandle.seek(0,2)   # whence argument equals to 2 means the end of the file
        FileEndOffset = filehandle.tell()    #5/21/18 added, the current position of the file pointer
        filehandle.seek(0)
        RawData = filehandle.read(4096)
        # print ("Size of the file to process %d\n"%FileEndOffset)
    
    RawData = RawData.decode('latin-1')
    
    MasterFrameHeader = wltr_common_master_frame_header(RawData[0:M_ByteSizeOf(wltr_common_master_frame_header())])
    BufferFrameHeader = wltr_frame_header(RawData[0:M_ByteSizeOf(wltr_frame_header())])     #4/2/18
   
    ExpectedFrameHeaderSignature = WLTR_FRAME_HEADER_SIGNATURE

    if (MasterFrameHeader.WltrMasterFrameSignature & 0xFFFFFC00) == (WLTR_MASTER_FRAME_SIGNATURE & 0xFFFFFC00):
        MasterFrameHeader = wltr_master_frame_header(RawData[0:M_ByteSizeOf(wltr_master_frame_header)])
        if Verbose:
            print ("...Detected WLTR signature")
    elif (MasterFrameHeader.WltrMasterFrameSignature & 0xFFFFFC00) == (WLTR_MASTER_FRAME_SIGNATURE_LEGACY & 0xFFFFFC00):
        MasterFrameHeader = wltr_master_frame_header_legacy(RawData[0:M_ByteSizeOf(wltr_master_frame_header_legacy)])
        if Verbose:
            print ("...Detected WLTR Legacy signature")
    elif (MasterFrameHeader.WltrMasterFrameSignature & 0xFFFFFC00) == (WLTR_MASTER_FRAME_SIGNATURE_STICKY & 0xFFFFFC00):
        MasterFrameHeader = wltr_master_frame_header_with_sticky_frames(RawData[0:M_ByteSizeOf(wltr_master_frame_header_with_sticky_frames)])
        if Verbose:
            print ("...Detected WLTR Sticky signature")
    elif (MasterFrameHeader.WltrMasterFrameSignature & 0xFFFFFC00) == (WLTR_DF_MASTER_FRAME_SIGNATURE & 0xFFFFFC00):
        MasterFrameHeader = wltr_dataflow_master_frame_header(RawData[0:M_ByteSizeOf(wltr_dataflow_master_frame_header)])
        FindLongestOpcodeString( )
        DataFlowMode = 1
        ExpectedFrameHeaderSignature = WLTR_DF_FRAME_HEADER_SIGNATURE
        if Verbose:
            print ("...Detected WLTR DataFlow signature")
    elif (BufferFrameHeader.WltrFrameSignature & 0xFFFFFC00) == (WLTR_FRAME_HEADER_SIGNATURE & 0xFFFFFC00):          #3/7/18
        BufferFrameHeader = wltr_frame_header(RawData[0:M_ByteSizeOf(wltr_frame_header)])
        # should this set the DiscFile = 0 to be a buffer data ??
        DiscFile = 0   #4/2/18
        if Verbose:
            print ("...Detected WLTR Data Frame signature")
    elif (BufferFrameHeader.WltrFrameSignature & 0xFFFFFC00) == (IDBT_FRAME_SIGNATURE_SATA & 0xFFFFFC00):          #4/2/18
        BufferFrameHeader = wltr_frame_header(RawData[0:M_ByteSizeOf(wltr_frame_header)])
        # should this set the DiscFile = 0 to be a buffer data ??
        DiscFile = 0   #4/2/18
        if Verbose:
            print ("...Detected WLTR-IBT SATA Data Frame signature")
    elif (BufferFrameHeader.WltrFrameSignature & 0xFFFFFC00) == (IDBT_FRAME_SIGNATURE_SAS & 0xFFFFFC00):          #4/2/18
        BufferFrameHeader = wltr_frame_header(RawData[0:M_ByteSizeOf(wltr_frame_header)])
        # should this set the DiscFile = 0 to be a buffer data ??
        DiscFile = 0   #4/2/18
        if Verbose:
            print ("...Detected WLTR-IBT SAS Data Frame signature")
        ExpectedFrameHeaderSignature = IDBT_FRAME_SIGNATURE_SAS     #4/2/18
    elif (BufferFrameHeader.WltrFrameSignature & 0xFFFFFC00) == (WLTR_DF_FRAME_HEADER_SIGNATURE & 0xFFFFFC00):          #4/2/18
        BufferFrameHeader = wltr_frame_header(RawData[0:M_ByteSizeOf(wltr_frame_header)])
        # should this set the DiscFile = 0 to be a buffer data ??
        DiscFile = 0   #4/2/18
        FindLongestOpcodeString( )
        DataFlowMode = 1
        if Verbose:
            print ("...Detected WLTR Data Flow Data Frame signature")
        ExpectedFrameHeaderSignature = WLTR_DF_FRAME_HEADER_SIGNATURE     #4/2/18
    else:
        print("***Unexpected Master Frame Signature detected {0:8x}".format(MasterFrameHeader.WltrMasterFrameSignature))
        print("***Unexpected        Frame Signature detected {0:8x}".format(BufferFrameHeader.WltrFrameSignature))
        print("*** Master Frame Signature Normal     {0:8x}".format(WLTR_MASTER_FRAME_SIGNATURE))
        print("*** Master Frame Signature Sticky     {0:8x}".format(WLTR_MASTER_FRAME_SIGNATURE_STICKY))
        print("*** Master Frame Signature Legacy     {0:8x}".format(WLTR_MASTER_FRAME_SIGNATURE_LEGACY))
        print("*** Master Frame Signature Data Flow  {0:8x}".format(WLTR_DF_MASTER_FRAME_SIGNATURE))
        print("*** Frame Signature                   {0:8x}".format(WLTR_FRAME_HEADER_SIGNATURE))
        print("*** Frame Signature Data Flow         {0:8x}".format(WLTR_DF_FRAME_HEADER_SIGNATURE))
        print("*** Frame Signature Bus Trace SATA    {0:8x}".format(IDBT_FRAME_SIGNATURE_SATA))
        print("*** Frame Signature Bus Trace SAS     {0:8x}".format(IDBT_FRAME_SIGNATURE_SAS))
        #sys.exit(1)
        return(4)

    if DiscFile == 1:       #4/2/18
        print("***Master Frame Signature detected {0:8x}".format(MasterFrameHeader.WltrMasterFrameSignature))
        DefaultSectorSize = MasterFrameHeader.DefaultSectorSizeInBytes
        # 3/21/18 now that a master signature or a frame signature has been found output information.
        AddHeaderCheck = os.path.isfile("WLTMasterFrameHeader.txt")
        # print AddHeaderCheck, os.path.isfile("WLTMasterFrameHeader.txt")
        MasterFrameFile = open("WLTMasterFrameHeader.txt","a")
        if not AddHeaderCheck:
            # print the headers
            PrintMasterFrameHeaderSummaryTitle(MasterFrameHeader, MasterFrameFile)
        NonModulo200Alignment = PrintMasterFrameHeader(MasterFrameHeader)
        PrintMasterFrameHeaderSummary( MasterFrameHeader, MasterFrameFile)
    else:
        print("***Frame Signature detected {0:8x}".format(BufferFrameHeader.WltrFrameSignature))
        DefaultSectorSize = 0    #4/3/18 since there is not a master frame header, this doesn't need to be defined.




    # 3/23/20 now try to get as much data as we can based upon memory availability.
    if OutputFileMethodContent == 0:
        InFileHander.seek(0)
        try:
            # 3/23/20 read the whole file, if possible.
            RawData = InFileHander.read(MasterFrameHeader.WltrDiscFileSizeInBytes).decode('latin-1')       # only read the header for now.....
            print(type(RawData))
        except:
            print("Error opening input file '%s'\n" % InputFilename)
            TestMaxFile, RawData = FindMaxFileSizeToSupport(InFileHander, MasterFrameHeader.WltrDiscFileSizeInBytes)
            if RawData == '':
                print("Couldn't open input file '%s'\n" % InputFilename)
                return(2)
        InFileHander.seek(0)
        FileEndOffset = len(RawData)

    if Verbose:
        print("...Input file is bytes", (InputFilename, hex(FileEndOffset)))

    AddHeaderCheck = os.path.isfile("WLTFrameHeader.txt")
    # print AddHeaderCheck, os.path.isfile("WLTFrameHeader.txt")
    FrameFile = open("WLTFrameHeader.txt","a")
    if not AddHeaderCheck:
        # print the headers
        PrintFrameHeaderSummaryTitles(FrameFile)
    if OutputFilename == None and (OutputFileOption & 2) == 0:   #4/9/18
        OutputFilename = os.path.splitext(InputFilename)[0]       #InputFilename[:-4]          3/23/20
    if OutputFileNameCSV == None and (OutputFileOption & 1) == 1:   #4/9/18
        # remove the extension
        OutputFileNameCSV = os.path.splitext(InputFilename)[0]   # 3/23/20
        # OutputFileNameCSV = InputFilename[:-4]

    # print(OutputFileOption)
    # print(DiscFile)
    # print("##################")
    if OutputFilename != None:
        #4/2/18 exclude normal text file output filename
        if (OutputFileOption & 2) == 0:
            OutputFile = open("{0}.txt".format(OutputFilename),"w")

    #12/18/17 have a tab delimited output filename
    if (OutputFileOption & 1) == 1:
        # OutputFilePtrCSV = file("{0}_csv.txt".format(OutputFilename),"w")
        # 4/5/18   4/9/18 add the CSV here.
        OutputFilePtrCSV = open("{0}.csv".format(OutputFileNameCSV),"w")

    if DiscFile == 0:
        print ("DiscFile ", DiscFile, OutputFilename)
        # Frame Buffer mode

        # FileEndOffset = len(RawData)        #3/21/20 done earlier, comment out here

        IndexOffset = DefaultSectorSize
        if  DataFlowMode:
            CurFrameHeader = wltr_dataflow_frame_header( RawData[DefaultSectorSize:DefaultSectorSize+M_ByteSizeOf(wltr_dataflow_frame_header)] )
            IndexOffset += M_ByteSizeOf(wltr_dataflow_frame_header)
        else:
            CurFrameHeader = wltr_frame_header( RawData[DefaultSectorSize:DefaultSectorSize+M_ByteSizeOf(wltr_frame_header)] )
            IndexOffset += M_ByteSizeOf(wltr_frame_header)

        # if ( CurFrameHeader.WltrFrameSignature != ExpectedFrameHeaderSignature ):
        if ( (CurFrameHeader.WltrFrameSignature & 0xFFFFFC00) != (ExpectedFrameHeaderSignature & 0xFFFFFC00) ):
            if Verbose:
                print("1-Unexpected Frame Signature detected  {0:08x} at offset {1:08x}".format(CurFrameHeader.WltrFrameSignature, DefaultSectorSize))
                print("1-Expected Frame Signature to detect {0:8x}".format(ExpectedFrameHeaderSignature))
            # 3/7/18 why exit, continue on.
            #sys.exit(1)
            return(5)
        # 3/7/18 still calculate the next location and set the next location to check
        if ( CurFrameHeader.FrameSizeInBytes ):
            ExpectedFrameEnd = DefaultSectorSize + CurFrameHeader.FrameSizeInBytes
        else:
            ExpectedFrameEnd = FileEndOffset
        # 3/7/18 parse if if the signatures are valid.
        if ( (CurFrameHeader.WltrFrameSignature & 0xFFFFFC00) == (ExpectedFrameHeaderSignature & 0xFFFFFC00) ):
            #4/2/18 exclude normal text file output filename
            if (OutputFileOption & 2) == 0:
                PrintFrameHeader( CurFrameHeader, OutputFile  )
            #3/21/18
            PrintFrameHeaderSummary( CurFrameHeader, MasterFrameHeader, FrameFile)
            #if Verbose:
            #    print "...Parsing Frame buffer data"
            print ("...Workload Trace: Parsing Frame {0} at offset {1:08x}".format(CurFrameHeader.FrameNum, IndexOffset))
            # ParseFrameContents( MasterFrameHeader, CurFrameHeader, OutputFile, OutputFilePtrCSV, RawData, IndexOffset, ExpectedFrameEnd, Verbose, 0, OutputFileOption)

            # 4/2/18
            if CurFrameHeader.Mode == 0:         #Encoded Mode
                # print("***Workload Trace Mode\n")
                ReturnPFCStatus = ParseFrameContents( MasterFrameHeader, CurFrameHeader, OutputFile, OutputFilePtrCSV, RawData, IndexOffset,
                        FrameOffsets[FrameOffsetIndex-1] + CurFrameHeader.FrameSizeInBytes, Verbose, 1, OutputFileOption )
                if ( ReturnPFCStatus != 0 ):
                    print("***Error Parsing Frame Contents in Frame {0} Offset {1:08x} Status {2}".format(CurFrameHeader.FrameNum, IndexOffset, ReturnPFCStatus))
                    # break     #3/7/18 comment out.
            elif CurFrameHeader.Mode == 1:       #CDB Mode  (IBT mode)
                # print("***In Bus Trace Mode\n")
                if OutputFile == None:
                    print ("None", OutputFileOption)
                # 3/5/18
                # OutputFileNameCSV  OutputFilePtrCSV
                IBTParseUpperLevelPointers(RawData, OutputFile, OutputFilename , OutputFileNameCSV + ".csv", 0, Verbose, OutputFileOption)
        else:
            print ("not found")

    else:
        # Disc file mode
        print ("DiscFile ", DiscFile)
        FramesFound = 0
        if StartOffset:
            PriorFrameLocation = StartOffset
        else:
            PriorFrameLocation = MasterFrameHeader.PrevFrameOffsetInBytes
        NumOfFrames = MasterFrameHeader.NumOfFrames
        if Verbose:
            print("...{0} Frame Count reported in Master Frame header".format(NumOfFrames))
        FrameOffsets = []
        FrameNumbers = []
        # 3/20/20  Reduce the processing size of the data to be below the max size limit that Python supported (e.g. basically tossing frames)
        if OutputFileMethodContent == 0:
            if ( PriorFrameLocation >= FileEndOffset ):
                LostFrameCounts = 0
                print("Prior Frame offset({0:08x}) exceeds input file size({1:08x}), reducing starting offset\n".format(
                    PriorFrameLocation, FileEndOffset))
                while PriorFrameLocation >= FileEndOffset:
                    # Backed off until it is below the python max string size
                    PriorFrameLocation-=MasterFrameHeader.TotalFrameSizeInBytes
                    # print(" ({0:08x}) |".format(PriorFrameLocation))
                    print(" %8X |"%PriorFrameLocation)
                    LostFrameCounts+=1
                PriorFrameLocation-=MasterFrameHeader.TotalFrameSizeInBytes
                # print(" ({0:08x}) |".format(PriorFrameLocation))
                print(" %8X |"%PriorFrameLocation)
                LostFrameCounts+=1
                print ('Tossed Frames %d\n'%LostFrameCounts + '  Delta between last PriorFrame and end of data string %x - %x - %x'% (PriorFrameLocation , FileEndOffset, FileEndOffset - PriorFrameLocation ) )
        if ( PriorFrameLocation >= FileEndOffset ):
            print("Prior Frame offset({0:08x}) exceeds input file size({1:08x})".format(
                PriorFrameLocation, FileEndOffset))
            #sys.exit(1)        #3/7/18 comment out, add else: below.
            # 3/20/20.......
            # can this be backed off until it is below the max file size????
            # MasterFrameHeader.TotalFrameSizeInBytes
        else:
            # build a list of Frames by traversing from most recent to least recent
            if OutputFileMethodContent == 0:
                if  DataFlowMode:
                    CurFrameHeader = wltr_dataflow_frame_header( RawData[PriorFrameLocation:PriorFrameLocation+M_ByteSizeOf(wltr_dataflow_frame_header)] )
                else:
                    if NonModulo200Alignment == 0:
                        CurFrameHeader = wltr_frame_header( RawData[PriorFrameLocation:PriorFrameLocation+M_ByteSizeOf(wltr_frame_header)] )
                    else:
                        CurFrameHeader = wltr_frame_header( RawData[(PriorFrameLocation-0xE00):(PriorFrameLocation-0xE00)+M_ByteSizeOf(wltr_frame_header)] )
                        if Verbose:
                            print ("using NonModulo200Alignment")
            else:
                filehandle.seek(PriorFrameLocation)
                RawData = filehandle.read(M_ByteSizeOf(wltr_frame_header))
                if  DataFlowMode:
                    CurFrameHeader = wltr_dataflow_frame_header( RawData)
                else:
                    if NonModulo200Alignment == 0:
                        CurFrameHeader = wltr_frame_header( RawData)
                    else:
                        filehandle.seek(PriorFrameLocation-0xE00)
                        RawData = filehandle.read(M_ByteSizeOf(wltr_frame_header))
                        CurFrameHeader = wltr_frame_header( RawData )
                        if Verbose:
                            sys.stderr.write ("using NonModulo200Alignment\n")

            # Check for valid signature  (At PrevFrameOffsetInBytes location)
            if ( (CurFrameHeader.WltrFrameSignature & 0xFFFFFC00) != (ExpectedFrameHeaderSignature & 0xFFFFFC00) ):
                print("2-Unexpected Frame Signature detected  {0:08x} at offset {1:08x}  Expecting {2:08x}".format(CurFrameHeader.WltrFrameSignature, PriorFrameLocation, ExpectedFrameHeaderSignature))

                # 1/22/18 need to search up from the current index.
                if NumOfFrames > 0:
                    if Verbose:
                        print("Need to find the last valid frame in this file Signature {0:08x} with modulo offset {1:04x}".format(CurFrameHeader.WltrFrameSignature, (PriorFrameLocation & 0x1200)))

                    Done = 0
                    Index = PriorFrameLocation
                    # does this have the correct 200h offset point, have seen a 0x1000 issue?  3/1/18 workaround for some weird stuff being seen.
                    if not (Index % 0x200):
                        Index-=0xE00
                        if Verbose:
                            print("2-Changing Previous offset to a module 0x200, new value is {0:08x}".format(Index))
                    #if (Index % 0x1000):
                    #    Index-=0xE00
                    #    print("1-Changing Previous offset to a module 0x1000, new value is {0:08x}\n".format(Index))
                    if Verbose:
                        print("wltr_frame_header structure is {0:08x}".format(M_ByteSizeOf(wltr_frame_header)))

                    while Done == 0:
                        if OutputFileMethodContent == 0:
                            if Index >0:
                                if  DataFlowMode:
                                    CurFrameHeader = wltr_dataflow_frame_header( RawData[Index:Index+M_ByteSizeOf(wltr_dataflow_frame_header)] )
                                else:
                                    CurFrameHeader = wltr_frame_header( RawData[Index:Index+M_ByteSizeOf(wltr_frame_header)] )
                                if ( (CurFrameHeader.WltrFrameSignature & 0xFFFFFC00) == (ExpectedFrameHeaderSignature & 0xFFFFFC00) ):
                                    Done = 1
                                    sys.stderr.write("Valid Frame Signature detected {0:08x} at offset {1:08x}\n".format(CurFrameHeader.WltrFrameSignature, Index))
                                    if NonModulo200Alignment == 0:      # obviously the non-modulo worked, force this if it hasn't been set.
                                        NonModulo200Alignment |= 16
                                    PriorFrameLocation = Index
                                    if SavedPreviousFrameOffset == Index and SavedPreviousFrameOffset > 0:           # this means the last search was equal to this searched
                                        if NonModulo200Alignment == 0:         #4/2/18
                                            LastUsedWorkaroundPreviousFrameOffset-=StepOffset
                                        else:
                                            LastUsedWorkaroundPreviousFrameOffset-=0x10000
                                        PriorFrameLocation = LastUsedWorkaroundPreviousFrameOffset          #3/8/18
                                        if Verbose:
                                            print ("using last workaround")
                            else:
                                Done = 1
                                if Verbose:
                                    print("Searching did not find a valid signature")
                                #sys.exit(1)        #3/7/18 don't exit.
                        else:
                            filehandle.seek(Index)
                            RawData = filehandle.read(M_ByteSizeOf(wltr_frame_header))
                            if  DataFlowMode:
                                CurFrameHeader = wltr_dataflow_frame_header( RawData)
                            else:
                                CurFrameHeader = wltr_frame_header( RawData )
                            # print("        Frame Signature {0:08x} at offset {1:08x}".format(CurFrameHeader.WltrFrameSignature, Index))

                            if ( (CurFrameHeader.WltrFrameSignature & 0xFFFFFC00) == (ExpectedFrameHeaderSignature & 0xFFFFFC00) ):
                                Done = 1
                                print("Valid Frame Signature detected {0:08x} at offset {1:08x}".format(CurFrameHeader.WltrFrameSignature, Index))
                                if NonModulo200Alignment == 0:      # obviously the non-modulo worked, force this if it hasn't been set.
                                    NonModulo200Alignment |= 16
                                PriorFrameLocation = Index
                                if SavedPreviousFrameOffset == Index and SavedPreviousFrameOffset > 0:           # this means the last search was equal to this searched
                                    if NonModulo200Alignment == 0:         #4/2/18
                                        LastUsedWorkaroundPreviousFrameOffset-=StepOffset
                                    else:
                                        LastUsedWorkaroundPreviousFrameOffset-=0x10000

                                    PriorFrameLocation = LastUsedWorkaroundPreviousFrameOffset          #3/8/18
                                    if Verbose:
                                        print ("Using last workaround")
                            else:
                                Done = 1
                                if Verbose:
                                    print("Searching did not find a valid signature")
                                #sys.exit(1)        #3/7/18 don't exit.
                        # if DefaultSectorSize == 0x200:       #3/14/18
                        if NonModulo200Alignment == 0:         #4/2/18
                            Index-=StepOffset       # MasterFrameHeader.TotalFrameSizeInBytes
                        else:
                            Index-=0x10000          # the truncated date size, 1/8th of the data is present.
                    Done = 0       #4/2/18
                #sys.exit(1)            # was originally, just exiting, added the search routine above.

            # 3/8/18 change from "else:" to comparing frame
            if ( (CurFrameHeader.WltrFrameSignature & 0xFFFFFC00) == (ExpectedFrameHeaderSignature & 0xFFFFFC00) ):
                if Verbose:
                    print ("A-Signature Found")
                FrameNumbers.append(CurFrameHeader.FrameNum)
                FrameOffsets.append(PriorFrameLocation)
                FramesFound += 1
                PriorFrameNum = CurFrameHeader.FrameNum
                if Verbose:
                    print("Starting Offset {0:08x} and PriorFrame Location {1:08x}".format(StartOffset, PriorFrameLocation))
                if StartOffset == 0:
                    if NonModulo200Alignment == 0:          #3/12/18 this was the original code that used the frame header information verbatim    3/20/18 change it if no issues have been found
                        if Verbose:
                            print ("Standard Loop\n")
                        # loop backwards through the frames to get a list in reverse order
                        while ( ( CurFrameHeader.PrevFrameOffsetInBytes != PriorFrameLocation ) and
                                ( (CurFrameHeader.WltrFrameSignature & 0xFFFFFC00) == (ExpectedFrameHeaderSignature & 0xFFFFFC00) ) ):
                            if NonModulo200Alignment > 0 and PriorFrameLocation == 0:       #3/8/18 workaround for non-modulo 200h offset values (seeing 1000h)    3/20/18 comment out
                                PriorFrameLocation-=0xE00
                                if Verbose:
                                    print ("Non-Modulo 200h Setting Offset to {0:08x}".format(PriorFrameLocation))
                            elif not (NonModulo200Alignment > 0 and PriorFrameLocation > 0):
                                PriorFrameLocation = CurFrameHeader.PrevFrameOffsetInBytes
                            if Verbose:
                                print ("Setting Offset to {0:08x}\n".format(PriorFrameLocation))
                            if ( MasterFrameHeader.PrevFrameOffsetInBytes == PriorFrameLocation ):
                                if Verbose:
                                    print ("Wrap condition breaking out of search loop")
                                # wrap condition
                                break
                            if OutputFileMethodContent == 0:
                                if  DataFlowMode:
                                    CurFrameHeader = wltr_dataflow_frame_header( RawData[PriorFrameLocation:PriorFrameLocation+M_ByteSizeOf(wltr_dataflow_frame_header)] )
                                else:
                                    CurFrameHeader = wltr_frame_header( RawData[PriorFrameLocation:PriorFrameLocation+M_ByteSizeOf(wltr_frame_header)] )
                            else:
                                filehandle.seek(PriorFrameLocation)
                                if  DataFlowMode:
                                    RawData = filehandle.read(M_ByteSizeOf(wltr_dataflow_frame_header))
                                    CurFrameHeader = wltr_dataflow_frame_header( RawData)
                                else:
                                    RawData = filehandle.read(M_ByteSizeOf(wltr_frame_header))
                                    CurFrameHeader = wltr_frame_header( RawData )

                            if ( (CurFrameHeader.WltrFrameSignature & 0xFFFFFC00) != (ExpectedFrameHeaderSignature & 0xFFFFFC00) ):
                                if Verbose:
                                    print("3-Unexpected Frame Signature detected  {0:08x} at offset {1:08x}  Expected {2:08x}".format(CurFrameHeader.WltrFrameSignature, PriorFrameLocation,ExpectedFrameHeaderSignature))

                                # 3/8/18 need to search up from the
                                if NumOfFrames > 0:
                                    if Verbose:
                                        print("Need to find the last valid frame in this file Signature {0:08x} with modulo offset {1:04x}".format(CurFrameHeader.WltrFrameSignature, (PriorFrameLocation & 0x1200)))
                                    Done = 0
                                    Index = PriorFrameLocation
                                    # does this have the correct 200h offset point?  3/1/18 workaround for some weird stuff being seen.
                                    if not (Index % 0x200):
                                        Index-=0xE00
                                        if Verbose:
                                            print("2-Changing Previous offset to a module 0x200, new value is {0:08x}".format(Index))
                                    #if (Index % 0x1000):
                                    #    Index-=0xE00
                                    #    print("2-Changing Previous offset to a module 0x1000, new value is {0:08x}\n".format(Index))
                                    #print("wltr_frame_header structure is {0:08x}\n".format(M_ByteSizeOf(wltr_frame_header)))

                                    while Done == 0:
                                        if Index >0:
                                            if OutputFileMethodContent == 0:
                                                if  DataFlowMode:
                                                    CurFrameHeader = wltr_dataflow_frame_header( RawData[Index:Index+M_ByteSizeOf(wltr_dataflow_frame_header)] )
                                                else:
                                                    CurFrameHeader = wltr_frame_header( RawData[Index:Index+M_ByteSizeOf(wltr_frame_header)] )
                                            else:
                                                filehandle.seek(PriorFrameLocation)
                                                if  DataFlowMode:
                                                    RawData = filehandle.read(M_ByteSizeOf(wltr_dataflow_frame_header))
                                                    CurFrameHeader = wltr_dataflow_frame_header( RawData)
                                                else:
                                                    RawData = filehandle.read(M_ByteSizeOf(wltr_frame_header))
                                                    CurFrameHeader = wltr_frame_header( RawData )
                                            # print("        Frame Signature {0:08x} at offset {1:08x}".format(CurFrameHeader.WltrFrameSignature, Index))

                                            if ( (CurFrameHeader.WltrFrameSignature & 0xFFFFFC00) == (ExpectedFrameHeaderSignature & 0xFFFFFC00) ):
                                                Done = 1
                                                if Verbose:
                                                    print("Valid Frame Signature detected {0:08x} at offset {1:08x}".format(CurFrameHeader.WltrFrameSignature, Index))
                                                PriorFrameLocation = Index
                                                if SavedPreviousFrameOffset == Index and SavedPreviousFrameOffset > 0:           # this means the last search was equal to this searched
                                                    LastUsedWorkaroundPreviousFrameOffset-=StepOffset
                                                    PriorFrameLocation = LastUsedWorkaroundPreviousFrameOffset          #3/8/18
                                                    # print ("2-using last workaround")
                                        else:
                                            Done = 1
                                            if Verbose:
                                                print("Searching did not find a valid signature")
                                            #sys.exit(1)        #3/7/18 don't exit.
                                        if DefaultSectorSize == 0x200:       #3/14/18   MasterFrameHeader.TotalFrameSizeInBytes
                                            Index-=StepOffset       # normally CurFrameHeader.FrameSizeInBytes
                                            if Verbose:
                                                print ("Frame Header Size in Bytes %d"%CurFrameHeader.FrameSizeInBytes)
                                        else:
                                            Index-=0x10000       #


                                if ( FramesFound ):
                                    break
                                else:
                                    print("No valid frames found")
                                    # sys.exit(1)       #3/7/18 comment out

                            if PriorFrameNum < CurFrameHeader.FrameNum:
                                # expect frame number to be descending, if not it is a wrap condition
                                if Verbose:
                                    print ("2-Frame Number is not descending Current {0}  Prior {1} and PriorFrameLocation {2:x}".format(CurFrameHeader.FrameNum, PriorFrameNum, PriorFrameLocation))
                                break
                            if ( FramesFound ):     #3/7/18 add If here since sys.exit is commented out above.
                                FrameNumbers.append(CurFrameHeader.FrameNum)
                                FrameOffsets.append(PriorFrameLocation)
                                FramesFound += 1

                            PriorFrameNum = CurFrameHeader.FrameNum
                            SavedPreviousFrameOffset = PriorFrameLocation        #3/8/18
                    else:                         #3/12/18 this was the code that just searches in reverse order based on frame size.
                        if Verbose:
                            print ("Workaround Loop\n")
                        # loop backwards through the frames to get a list in reverse order
                        InitialEntry = 0
                        while (PriorFrameLocation > 0):
                            if Verbose:
                                print ("Setting Offset to {0:08x}\n".format(PriorFrameLocation))
                            if ( MasterFrameHeader.PrevFrameOffsetInBytes == PriorFrameLocation and InitialEntry > 0 ):
                                # wrap condition
                                if Verbose:
                                    print ("Wrap condition breaking out of search loop\n")
                                    print ("Prior Frame Location %x"%PriorFrameLocation + "  PrevFrameOffsteInBytes %x"%CurFrameHeader.PrevFrameOffsetInBytes + '  Frames Found %d\n'%FramesFound)
                                break
                            if OutputFileMethodContent == 0:
                                if  DataFlowMode:
                                    CurFrameHeader = wltr_dataflow_frame_header( RawData[PriorFrameLocation:PriorFrameLocation+M_ByteSizeOf(wltr_dataflow_frame_header)] )
                                else:
                                    CurFrameHeader = wltr_frame_header( RawData[PriorFrameLocation:PriorFrameLocation+M_ByteSizeOf(wltr_frame_header)] )
                            else:
                                filehandle.seek(PriorFrameLocation)
                                if  DataFlowMode:
                                    RawData = filehandle.read(M_ByteSizeOf(wltr_dataflow_frame_header))
                                    CurFrameHeader = wltr_dataflow_frame_header( RawData)
                                else:
                                    RawData = filehandle.read(M_ByteSizeOf(wltr_frame_header))
                                    CurFrameHeader = wltr_frame_header( RawData )
                            if ( (CurFrameHeader.WltrFrameSignature & 0xFFFFFC00) != (ExpectedFrameHeaderSignature & 0xFFFFFC00) ):
                                if Verbose:
                                    print("3-Unexpected Frame Signature detected  {0:08x} at offset {1:08x}  Expected {2:08x}".format(CurFrameHeader.WltrFrameSignature, PriorFrameLocation,ExpectedFrameHeaderSignature))

                                if ( FramesFound ):
                                    break
                                else:
                                    print("No valid frames found\n")
                                    # sys.exit(1)       #3/7/18 comment out

                            else:
                                if PriorFrameNum < CurFrameHeader.FrameNum:
                                    # expect frame number to be descending, if not it is a wrap condition
                                    if Verbose:
                                        print ("3-Frame Number is not descending Current {0}  Prior {1} and PriorFrameLocation {2:x}".format(CurFrameHeader.FrameNum, PriorFrameNum, PriorFrameLocation))
                                    # break
                                FrameNumbers.append(CurFrameHeader.FrameNum)
                                FrameOffsets.append(PriorFrameLocation)
                                FramesFound += 1

                            PriorFrameNum = CurFrameHeader.FrameNum
                            # PriorFrameLocation-=0x10000                  # 3/12/18 using 10000h since seeing corrupted files from System 4K drives, really should be 80000h or Frame size
                            if DefaultSectorSize == 0x200:       #3/14/18
                                PriorFrameLocation-=StepOffset       # MasterFrameHeader.TotalFrameSizeInBytes
                                if Verbose:
                                    # print ("Wrap condition breaking out of search loop")
                                    print ("Frame Header Size in Bytes %d"%CurFrameHeader.FrameSizeInBytes)

                            else:
                                PriorFrameLocation-=0x10000       # workaround using 10000h since seeing corrupted files from System 4K drives, really should be 80000h or Frame size
                            InitialEntry+=1
                            if Verbose:
                                print ("Prior Frame Location %x"%PriorFrameLocation + '  PrevFrameOffsetInBytes %x'%CurFrameHeader.PrevFrameOffsetInBytes + '  Frames Found %d'%FramesFound)


                    print ("...Found frames %d"%(FramesFound))      # 3/21/20 remove \n
                    
                if Verbose:
                    # print the list of frames found
                    print ("    Idx Frame# FileOffset")
                    print ("   ==== ====== ==========")
                    for FrameOffsetIndex in range(FramesFound):
                        print ("... {0:3} {1:04x}   {2:08x}".format(FrameOffsetIndex, FrameNumbers[FrameOffsetIndex], FrameOffsets[FrameOffsetIndex]))

                if (NumEntry > 0 and FramesFound > 0):     #12/12/18 restrict the number to process
                    FramesFound = NumEntry

                for FrameOffsetIndex in range(FramesFound,0,-1):
                    # OutputFileOption = 7
                    if OutputFilename != None:
                        #4/2/18 exclude normal text file output filename
                        if (OutputFileOption & 2) == 0:
                            # Open a new output file for each frame
                            OutputFile = open("{0}_{1}.txt".format(
                                OutputFilename, FrameNumbers[FrameOffsetIndex-1]) ,"w")
                        #12/18/17
                    if OutputFileNameCSV != None:       #3/23/20
                        #4/2/18 include csv text file output filename
                        if (OutputFileOption & 1) == 1:
                            OutputFilePtrCSV= open(OutputFileNameCSV + "_{0}.csv".format(
                                FrameNumbers[FrameOffsetIndex-1]) ,"w")
                    # output the Master Frame Header on the first output file
                    if FrameOffsetIndex == FramesFound:
                        NonModulo200Alignment = PrintMasterFrameHeader(MasterFrameHeader, OutputFile)
                        PrintMasterFrameHeaderSummary( MasterFrameHeader, MasterFrameFile)

                    if ( FrameOffsets[FrameOffsetIndex-1] > FileEndOffset ):
                        print("Next Frame offset(0x{0:08x}) exceeds input file size(0x{1:08x})\n".format(
                           FrameOffsets[FrameOffsetIndex-1], FileEndOffset))
                        break
                    
                    
                    IndexOffset = FrameOffsets[FrameOffsetIndex-1]
                    # OutputFileMethodContent = 0
                    # DataFlowMode = 0
                    if OutputFileMethodContent == 0:
                        if  DataFlowMode:
                            CurFrameHeader = wltr_dataflow_frame_header( RawData[IndexOffset:IndexOffset+M_ByteSizeOf(wltr_dataflow_frame_header)] )
                            IndexOffset += M_ByteSizeOf(wltr_dataflow_frame_header)
                        else:
                            CurFrameHeader = wltr_frame_header( RawData[IndexOffset:IndexOffset+M_ByteSizeOf(wltr_frame_header)] )
                            IndexOffset += M_ByteSizeOf(wltr_frame_header)
                    else:
                        filehandle.seek(IndexOffset)
                        if  DataFlowMode:
                            RawData= filehandle.read(M_ByteSizeOf(wltr_dataflow_frame_header))
                            CurFrameHeader = wltr_dataflow_frame_header( RawData)
                            IndexOffset += M_ByteSizeOf(wltr_dataflow_frame_header)
                        else:
                            RawData = filehandle.read(M_ByteSizeOf(wltr_frame_header))
                            CurFrameHeader = wltr_frame_header( RawData)
                            IndexOffset += M_ByteSizeOf(wltr_frame_header)
                        if CurFrameHeader.Mode == 0:         #Encoded Mode
                            RawData= filehandle.read(MasterFrameHeader.TotalFrameSizeInBytes)
                        else:
                            RawData= filehandle.read(MasterFrameHeader.TotalFrameSizeInBytes)
                    if Verbose:
                        print ("...Parsing Frame {0} at offset {1:08x}".format(CurFrameHeader.FrameNum, IndexOffset))     #3/21/20 remove \n
                    else:
                        print ("...Parsing Frame {0} at offset {1:08x}".format(CurFrameHeader.FrameNum, IndexOffset))     #3/21/20 remove \n
                    
                    # OutputFile = None
                    if ( ( OutputFile != None ) or Verbose ):
                        #4/2/18 exclude normal text file output filename
                        if (OutputFileOption & 2) == 0:
                            PrintFrameHeader(CurFrameHeader, OutputFile )
                        #3/21/18
                        PrintFrameHeaderSummary( CurFrameHeader, MasterFrameHeader, FrameFile)
                    # SearchLBAValid = 0
                    if ( (SearchLBAValid == 0) or (OutputFile != None) ):
                        # if in search mode, do not pollute output with header info for each frame
                        #4/2/18 exclude normal text file output filename
                        if (OutputFileOption & 2) == 0:
                            PrintFrameHeaderInfo( CurFrameHeader, OutputFile )
                    
                    # CurFrameHeader.Mode = 0
                   
                    if CurFrameHeader.Mode == 0:         #Encoded Mode
                        if OutputFileMethodContent == 0:
                        #  print("***WorkloadTrace Mode")
                            ReturnPFCStatus = ParseFrameContents( MasterFrameHeader, CurFrameHeader, OutputFile, OutputFilePtrCSV, RawData, IndexOffset,
                                    FrameOffsets[FrameOffsetIndex-1] + CurFrameHeader.FrameSizeInBytes, Verbose, 1, OutputFileOption )
                        else:
                            ReturnPFCStatus = ParseFrameContents( MasterFrameHeader, CurFrameHeader, OutputFile, OutputFilePtrCSV, RawData, 0,
                                        FrameOffsets[FrameOffsetIndex-1] + CurFrameHeader.FrameSizeInBytes, Verbose, 1, OutputFileOption )
                        if ( ReturnPFCStatus != 0 ):
                            print("***Error Parsing Frame Contents in Frame {0} Offset {1:08x} Status {2}".format(CurFrameHeader.FrameNum, IndexOffset, ReturnPFCStatus))
                            # break     #3/7/18 comment out.
                    elif CurFrameHeader.Mode == 1:       #CDB Mode  (IBT mode)
                        #  print("***In Bus Trace Mode")
                        # 3/5/18
                        if OutputFile == None:
                            print ("None")
                        if OutputFileMethodContent == 0:
                            IBTParseUpperLevelPointers(RawData, OutputFile, OutputFilename, OutputFileNameCSV + ".csv", 0, Verbose, OutputFileOption)
                        else:
                            IBTParseUpperLevelPointers(RawData, OutputFile, OutputFilename, OutputFileNameCSV + ".csv", 0, Verbose, OutputFileOption)
                if ( (SearchLBAValid == 0) or (OutputFile != None) ):
                    #4/2/18 exclude normal text file output filename
                    if (OutputFileOption & 2) == 0:
                        FilePrintf( OutputFile, "=== Frame {0}, EndTime: %d "%CurFrameHeader.FrameNum )
                        PrintTimeStamp( CurFrameHeader.EndTimestamp, OutputFile )
                if (OutputFile != None):
                    OutputFile.close()
            else:
                if Verbose:     # 4/2/18 debug only
                    print ("    else to not finding signature")

    if Verbose:
        PrintGlobalCounters(DataFlowMode)

    if DiscFile == 1:       #4/2/18
        MasterFrameFile.close()     #3/21/18
    FrameFile.close()
    return 0

def FindMaxFileSizeToSupport(InFileHander, MaxFileToRead):
    # a quick and dirty routine to see how much the file can use in data length   #3/23/20
    SizeToTry = MaxFileToRead
    StepSizeDown = 0x80000
    MinSize = 9000000000
    Done = 0
    RawData = ''
    while Done == 0:
        InFileHander.seek(0)
        try:
            RawData = InFileHander.read(SizeToTry)
            Done = 1
        except:
            print("File Size failed '%d'" % SizeToTry)
            SizeToTry-=StepSizeDown
        if MinSize > SizeToTry:
            break
    return SizeToTry, RawData


"""
def main():
    Verbose         = 0
    DiscFile        = 1
    StartOffset     = 0
    DataFlowMode    = 0
    SearchLBAValid  = 0
    HostBlocksPerDiscSector = 1
    OutputFilename  = None
    OutputFile      = None
    OutputFileNameCSV = None
    ReturnStatus    = 0
    OutputFileOption= 0       # By default get text output, csv would be option1
    FileDoneNotation= 0
    NumEntries = 0

    InputFilename, Verbose, DiscFile, StartOffset, DataFlowMode, SearchLBAValid, HostBlocksPerDiscSector, OutputFilename, OutputFile, OutputFileNameCSV, OutputFileOption, FileDoneNotation = WorkLoadTraceCommandLineHandler( )
    ReturnStatus = ParseWorkloadTrace(InputFilename, Verbose, DiscFile, StartOffset, DataFlowMode, SearchLBAValid, HostBlocksPerDiscSector, OutputFilename, OutputFile, OutputFileNameCSV, OutputFileOption, NumEntries )
    # 3/13/18 add this for higher level calling function
    if (not FileDoneNotation == 0):
        DoneOutputFile = file("ParseDone2004.txt","w")
        DoneOutputFile.write(time.asctime() + '\n')
        DoneOutputFile.close()
"""