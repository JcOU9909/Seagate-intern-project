#!/usr/bin/python
#
#  VCS Information: $File: //depot/Tools/CommandLineTools/WinCmd/WorkloadTraceParse.py $
#                   $Change: 850354 $
#                   $Revision: #5 $
#                   $Author: tyler.gordon $
#                   $Date: 2015/04/03 $
#
#  Parse the Workload Trace disc or buffer file
#
import sys, os
from .PlatformCStructs import *
from .WorkloadTraceUtils import *

Version = "v1.05 12/20/2018"

##############################################################################################
#
# Print help
#
##############################################################################################
def Usage(Msg=None):
    """Print the usage of WorkloadTraceParse."""
    # sys.stderr.write("WorkloadTraceParse Version %s\n" % Version)
    if Msg != None:
        sys.stderr.write( "***** %s\n\n" % Msg )

    sys.stderr.write("Usage: WorkloadTraceParsePy Inputfile (options) | " + Version + "   Platform OS:" + sys.platform + "\n")
    sys.stderr.write("  Where:\n")
    sys.stderr.write("   inputfile          - binary WorkloadTrace disc or buffer frame file\n")
    sys.stderr.write("   options:\n")
    sys.stderr.write("   -f <outputfile>    - Txt output file base name.\n")
    sys.stderr.write("                        Because the parsed files may be large, there may be\n")
    sys.stderr.write("                        multiple files created. These files will have the format\n")
    sys.stderr.write("                        'outputfile'_n.txt, where 'n' is the frame number\n")
    sys.stderr.write("   -csv               - CSV Text Output. Outputs CSV Format file\n")
    sys.stderr.write("                        entry encoding, output filename is 'outputfile'_n_csv.txt,\n")
    sys.stderr.write("   -notext            - Do not output standard Text Output.\n")
    sys.stderr.write("                        entry encoding, output filename is 'outputfile'_n_csv.txt,\n")
    sys.stderr.write("   -v                 - Verbose mode. Outputs additional information on trace\n")
    sys.stderr.write("                        entry encoding\n")
    sys.stderr.write("   -bf                - Buffer File. Indicates the input file is a frame buffer,\n")
    sys.stderr.write("                        not from disc\n")
    sys.stderr.write("   -s <hex offset>    - specify a starting frame offset in hex \n")
    sys.stderr.write("                           (Doesn't apply to Buffer File)\n")
    sys.stderr.write("   -l <hex LBA> (XL)  - Output entries overlapping a specific LBA, or LBA range\n")
    sys.stderr.write("                        if a 2nd XL parameter follows\n")
    sys.stderr.write("   -e                 - specifies 5xxe, translates disc opcode LBA entries to\n")
    sys.stderr.write("                        host blocks\n")
    sys.exit(1)

def main( ):
    if len( sys.argv ) < 2:
        Usage()

    print("WorkloadTraceParse Version %s\n" % Version)

    # Extract the command line parameters
    InputFilename   = sys.argv[1]

    Verbose         = 0
    DiscFile        = 1
    StartOffset     = 0
    DataFlowMode    = 0
    SearchLBAValid  = 0
    HostBlocksPerDiscSector = 1
    OutputFilename  = None
    OutputFile      = None
    OutputFileNameCSV = None      # 12/18/17
    OutputFileOption= 1         # 3/8/18 default, need cmd line option to do this
    FileDoneNotation= 0
    NumEntry        = 0         #12/12/18 limit the number of entries / records to process

    # parse options
    ArgSkip = 0
    for i in range(2,len(sys.argv)):
        if ArgSkip:
            ArgSkip -= 1
            continue
        if sys.argv[i] == "-f":
            if len(sys.argv) >= i+2:
                OutputFilename = sys.argv[i+1]
                ArgSkip += 1
                # print "...Output file base name = '{0}'".format(OutputFilename)
        elif sys.argv[i] == "-csv":
            OutputFileOption |= 1
            # print "...CSV enabled"
        elif sys.argv[i] == "-notext":
            OutputFileOption |= 2
            # print "...No Text enabled"
        elif sys.argv[i] == "-v":
            Verbose = 1
            # print "...Verbose enabled"
        elif sys.argv[i] == "-bf":
            DiscFile = 0
            # print "...Buffer File enabled"
        elif sys.argv[i] == "-d":
            FileDoneNotation = 1
            # print "...File Done Notation enabled"
        elif sys.argv[i] == "-s":
            if len(sys.argv) >= i+2:
                try:
                    StartOffset = int(sys.argv[i+1], 16)
                except:
                    print "*** Invalid parameter '{0}'".format(sys.argv[i+1])
                else:
                    ArgSkip += 1
                    print "...Starting Offset = 0x{0:1x}".format(StartOffset)
            else:
               print "...'{0}' detected, but no parameter found".format(sys.argv[i])
        elif sys.argv[i] == "-entry":
            if len(sys.argv) >= i+2:
                try:
                    NumEntry = int(sys.argv[i+1], 16)
                except:
                    print "*** Invalid parameter '{0}'".format(sys.argv[i+1])
                else:
                    ArgSkip += 1
                    print "...Starting Offset = 0x{0:1x}".format(StartOffset)
            else:
               print "...'{0}' detected, but no parameter found".format(sys.argv[i])
        elif sys.argv[i] == "-l":
            if len(sys.argv) >= i+2:
                SearchLBAStart = int(sys.argv[i+1], 16)
                SearchLBAValid = 1
                ArgSkip += 1
                # check for another param which could be a length parameter
                try:
                    SearchTransferLen = int(sys.argv[i+2], 16)
                except:
                    SearchTransferLen = 1
                else:
                    # don't allow a zero or negative transfer length
                    if SearchTransferLen <= 0:
                        SearchTransferLen = 1
                    else:
                        ArgSkip += 1
                SetSearchLBARange(SearchLBAStart, SearchTransferLen)
                if SearchTransferLen != 1:
                    print "...Search LBA range = 0x{0:010x} - 0x{1:010x}".format(SearchLBAStart, SearchLBAStart + SearchTransferLen - 1)
                else:
                    print "...Search LBA = 0x{0:010x}".format(SearchLBAStart)
            else:
                print "...'{0}' detected, but no parameter found".format(sys.argv[i])
        elif sys.argv[i] == "-e":
            HostBlocksPerDiscSector = 8
            SetHostBlocksPerDiscSector( HostBlocksPerDiscSector )
            print "...5xxe enabled, {0} host blocks per disc sector".format(HostBlocksPerDiscSector)
        else:
            print "*** Unknown option '{0}'".format(sys.argv[i])
    if (OutputFileOption & 1) == 1:        
        OutputFileNameCSV = OutputFilename  #4/9/18  don't add extension at this point, just define the base name for the CSV file.

    NonModulo200Alignment = 0
    SavedPreviousFrameOffset = 0        #3/8/18
    LastUsedWorkaroundPreviousFrameOffset = 0        #3/8/18
    StepOffset = 0x80000                            # 4/2/18
    OutputFilePtrCSV = None                         #4/6/18
    RawData = ''
    # Read the input file
    try:
        RawData = file(InputFilename, 'rb').read()
    except:
        sys.stderr.write("Couldn't open input file '%s'\n" % InputFilename)
        Usage()

    InputFileSize = len(RawData)

    print "...Input file '{0}' is {1} bytes".format(InputFilename, hex(InputFileSize))

    MasterFrameHeader = wltr_common_master_frame_header(RawData[0:M_ByteSizeOf(wltr_common_master_frame_header)])
    BufferFrameHeader = wltr_frame_header(RawData[0:M_ByteSizeOf(wltr_frame_header)])     #4/2/18

    ExpectedFrameHeaderSignature = WLTR_FRAME_HEADER_SIGNATURE

    if (MasterFrameHeader.WltrMasterFrameSignature & 0xFFFFFC00) == (WLTR_MASTER_FRAME_SIGNATURE & 0xFFFFFC00):
        MasterFrameHeader = wltr_master_frame_header(RawData[0:M_ByteSizeOf(wltr_master_frame_header)])
        if Verbose:
            print "...Detected WLTR signature"
    elif (MasterFrameHeader.WltrMasterFrameSignature & 0xFFFFFC00) == (WLTR_MASTER_FRAME_SIGNATURE_LEGACY & 0xFFFFFC00):
        MasterFrameHeader = wltr_master_frame_header_legacy(RawData[0:M_ByteSizeOf(wltr_master_frame_header_legacy)])
        if Verbose:
            print "...Detected WLTR Legacy signature"
    elif (MasterFrameHeader.WltrMasterFrameSignature & 0xFFFFFC00) == (WLTR_MASTER_FRAME_SIGNATURE_STICKY & 0xFFFFFC00):
        MasterFrameHeader = wltr_master_frame_header_with_sticky_frames(RawData[0:M_ByteSizeOf(wltr_master_frame_header_with_sticky_frames)])
        if Verbose:
            print "...Detected WLTR Sticky signature"
    elif (MasterFrameHeader.WltrMasterFrameSignature & 0xFFFFFC00) == (WLTR_DF_MASTER_FRAME_SIGNATURE & 0xFFFFFC00):
        MasterFrameHeader = wltr_dataflow_master_frame_header(RawData[0:M_ByteSizeOf(wltr_dataflow_master_frame_header)])
        FindLongestOpcodeString( )
        DataFlowMode = 1
        ExpectedFrameHeaderSignature = WLTR_DF_FRAME_HEADER_SIGNATURE
        if Verbose:
            print "...Detected WLTR DataFlow signature"
    elif (BufferFrameHeader.WltrFrameSignature & 0xFFFFFC00) == (WLTR_FRAME_HEADER_SIGNATURE & 0xFFFFFC00):          #3/7/18
        BufferFrameHeader = wltr_frame_header(RawData[0:M_ByteSizeOf(wltr_frame_header)])   
        # should this set the DiscFile = 0 to be a buffer data ??
        DiscFile = 0   #4/2/18
        if Verbose:
            print "...Detected WLTR Data Frame signature"
    elif (BufferFrameHeader.WltrFrameSignature & 0xFFFFFC00) == (IDBT_FRAME_SIGNATURE_SATA & 0xFFFFFC00):          #4/2/18
        BufferFrameHeader = wltr_frame_header(RawData[0:M_ByteSizeOf(wltr_frame_header)])
        # should this set the DiscFile = 0 to be a buffer data ??
        DiscFile = 0   #4/2/18
        if Verbose:
            print "...Detected WLTR-IBT SATA Data Frame signature"
    elif (BufferFrameHeader.WltrFrameSignature & 0xFFFFFC00) == (IDBT_FRAME_SIGNATURE_SAS & 0xFFFFFC00):          #4/2/18
        BufferFrameHeader = wltr_frame_header(RawData[0:M_ByteSizeOf(wltr_frame_header)])     
        # should this set the DiscFile = 0 to be a buffer data ??
        DiscFile = 0   #4/2/18
        if Verbose:
            print "...Detected WLTR-IBT SAS Data Frame signature"
        ExpectedFrameHeaderSignature = IDBT_FRAME_SIGNATURE_SAS     #4/2/18
    elif (BufferFrameHeader.WltrFrameSignature & 0xFFFFFC00) == (WLTR_DF_FRAME_HEADER_SIGNATURE & 0xFFFFFC00):          #4/2/18
        BufferFrameHeader = wltr_frame_header(RawData[0:M_ByteSizeOf(wltr_frame_header)])     
        # should this set the DiscFile = 0 to be a buffer data ??
        DiscFile = 0   #4/2/18
        FindLongestOpcodeString( )
        DataFlowMode = 1
        if Verbose:
            print "...Detected WLTR Data Flow Data Frame signature"
        ExpectedFrameHeaderSignature = WLTR_DF_FRAME_HEADER_SIGNATURE     #4/2/18
    else:
        sys.stderr.write("***Unexpected Master Frame Signature detected {0:8x}\n".format(MasterFrameHeader.WltrMasterFrameSignature))
        sys.stderr.write("***Unexpected        Frame Signature detected {0:8x}\n".format(BufferFrameHeader.WltrFrameSignature))
        sys.stderr.write("*** Master Frame Signature Normal     {0:8x}\n".format(WLTR_MASTER_FRAME_SIGNATURE))
        sys.stderr.write("*** Master Frame Signature Sticky     {0:8x}\n".format(WLTR_MASTER_FRAME_SIGNATURE_STICKY))
        sys.stderr.write("*** Master Frame Signature Legacy     {0:8x}\n".format(WLTR_MASTER_FRAME_SIGNATURE_LEGACY))
        sys.stderr.write("*** Master Frame Signature Data Flow  {0:8x}\n".format(WLTR_DF_MASTER_FRAME_SIGNATURE))
        sys.stderr.write("*** Frame Signature                   {0:8x}\n".format(WLTR_FRAME_HEADER_SIGNATURE))
        sys.stderr.write("*** Frame Signature Data Flow         {0:8x}\n".format(WLTR_DF_FRAME_HEADER_SIGNATURE))
        sys.stderr.write("*** Frame Signature Bus Trace SATA    {0:8x}\n".format(IDBT_FRAME_SIGNATURE_SATA))
        sys.stderr.write("*** Frame Signature Bus Trace SAS     {0:8x}\n".format(IDBT_FRAME_SIGNATURE_SAS))
        sys.exit(1)

    if DiscFile == 1:       #4/2/18
        sys.stderr.write("***Master Frame Signature detected {0:8x}\n".format(MasterFrameHeader.WltrMasterFrameSignature))
        DefaultSectorSize = MasterFrameHeader.DefaultSectorSizeInBytes
        # 3/21/18 now that a master signature or a frame signature has been found output information.
        AddHeaderCheck = os.path.isfile("WLTMasterFrameHeader.txt")
        # print AddHeaderCheck, os.path.isfile("WLTMasterFrameHeader.txt")
        MasterFrameFile = file("WLTMasterFrameHeader.txt","a")
        if not AddHeaderCheck:
            # print the headers
            PrintMasterFrameHeaderSummaryTitle( MasterFrameHeader, MasterFrameFile)
        NonModulo200Alignment = PrintMasterFrameHeader(MasterFrameHeader)
        PrintMasterFrameHeaderSummary( MasterFrameHeader, MasterFrameFile)
    else:
        sys.stderr.write("***Frame Signature detected {0:8x}\n".format(BufferFrameHeader.WltrFrameSignature))
        DefaultSectorSize = 0

    AddHeaderCheck = os.path.isfile("WLTFrameHeader.txt")
    # print AddHeaderCheck, os.path.isfile("WLTFrameHeader.txt")
    FrameFile = file("WLTFrameHeader.txt","a")
    if not AddHeaderCheck:
        # print the headers
        PrintFrameHeaderSummaryTitles(FrameFile)
    if OutputFilename == None and (OutputFileOption & 2) == 0:   #4/9/18
        OutputFilename = InputFilename[:-4] 
    if OutputFileNameCSV == None and (OutputFileOption & 1) == 1:   #4/9/18
        OutputFileNameCSV = InputFilename[:-4]
    if DiscFile == 0:
        # Frame Buffer mode

        if OutputFilename != None:
            #4/2/18 exclude normal text file output filename
            if (OutputFileOption & 2) == 0:
                    OutputFile = file("{0}.txt".format(OutputFilename),"w")

            #12/18/17 have a tab delimited output filename
            if (OutputFileOption & 1) == 1:
                OutputFilePtrCSV = file("{0}.csv".format(OutputFileNameCSV),"w")

        FileEndOffset = len(RawData)

        IndexOffset = DefaultSectorSize
        if  DataFlowMode:
            CurFrameHeader = wltr_dataflow_frame_header( RawData[DefaultSectorSize:DefaultSectorSize+M_ByteSizeOf(wltr_dataflow_frame_header)] )
            IndexOffset += M_ByteSizeOf(wltr_dataflow_frame_header)
        else:
            CurFrameHeader = wltr_frame_header( RawData[DefaultSectorSize:DefaultSectorSize+M_ByteSizeOf(wltr_frame_header)] )
            IndexOffset += M_ByteSizeOf(wltr_frame_header)

        if ( (CurFrameHeader.WltrFrameSignature & 0xFFFFFC00) != (ExpectedFrameHeaderSignature & 0xFFFFFC00) ):
            if Verbose:
                sys.stderr.write("Unexpected Frame Signature detected  {0:08x} at offset {1:08x}\n".format(CurFrameHeader.WltrFrameSignature, DefaultSectorSize))
                sys.stderr.write("1-Expected Frame Signature to detect {0:8x}\n".format(ExpectedFrameHeaderSignature))
            # 3/7/18 why exit, continue on.
            #sys.exit(1)
            return
        # 3/7/18 still calculate the next location and set the next location to check
        if ( CurFrameHeader.FrameSizeInBytes ):
            ExpectedFrameEnd = DefaultSectorSize + CurFrameHeader.FrameSizeInBytes
        else:
            ExpectedFrameEnd = FileEndOffset

        if ( (CurFrameHeader.WltrFrameSignature & 0xFFFFFC00) == (ExpectedFrameHeaderSignature & 0xFFFFFC00) ):    
            #4/2/18 exclude normal text file output filename
            if (OutputFileOption & 2) == 0:
                PrintFrameHeader( CurFrameHeader, OutputFile  )
            #3/21/18
            PrintFrameHeaderSummary( CurFrameHeader, MasterFrameHeader, FrameFile)
            if Verbose:
                print "...Parsing Frame buffer data"
            ParseFrameContents( MasterFrameHeader, CurFrameHeader, OutputFile, OutputFileComma, RawData, IndexOffset, ExpectedFrameEnd, Verbose, 0, OutputFileOption)
    else:
        # Disc file mode
        FramesFound = 0
        if StartOffset:
            PriorFrameLocation = StartOffset
        else:
            PriorFrameLocation = MasterFrameHeader.PrevFrameOffsetInBytes
        NumOfFrames = MasterFrameHeader.NumOfFrames
        if Verbose:
            print "...{0} Frame Count reported in Master Frame header".format(NumOfFrames)
        FrameOffsets = []
        FrameNumbers = []

        if ( PriorFrameLocation >= InputFileSize ):
            sys.stderr.write("Prior Frame offset({0:08x}) exceeds input file size({1:08x})\n".format(
                PriorFrameLocation, InputFileSize))

        else:
            # build a list of Frames by traversing from most recent to least recent
            if  DataFlowMode:
                CurFrameHeader = wltr_dataflow_frame_header( RawData[PriorFrameLocation:PriorFrameLocation+M_ByteSizeOf(wltr_dataflow_frame_header)] )
            else:
                if NonModulo200Alignment == 0:
                    CurFrameHeader = wltr_frame_header( RawData[PriorFrameLocation:PriorFrameLocation+M_ByteSizeOf(wltr_frame_header)] )
                else:
                    if Verbose:
                        sys.stderr.write ("using NonModulo200Alignment\n")
                    CurFrameHeader = wltr_frame_header( RawData[(PriorFrameLocation-0xE00):(PriorFrameLocation-0xE00)+M_ByteSizeOf(wltr_frame_header)] )
                    
            # Check for valid signature  (At PrevFrameOffsetInBytes location)
            #if ( CurFrameHeader.WltrFrameSignature != ExpectedFrameHeaderSignature ):
            if ( (CurFrameHeader.WltrFrameSignature & 0xFFFFFC00) != (ExpectedFrameHeaderSignature & 0xFFFFFC00) ):
                sys.stderr.write("2-Unexpected Frame Signature detected  {0:08x} at offset {1:08x}  Expecting {2:08x}\n".format(CurFrameHeader.WltrFrameSignature, PriorFrameLocation, ExpectedFrameHeaderSignature))

                # 1/22/18 need to search up from the current index.
                if NumOfFrames > 0:
                    if Verbose:
                        sys.stderr.write("Need to find the last valid frame in this file Signature {0:08x} with modulo offset {1:04x}\n".format(CurFrameHeader.WltrFrameSignature, (PriorFrameLocation & 0x1200)))
                    
                    Done = 0
                    Index = PriorFrameLocation
                    # does this have the correct 200h offset point, have seen a 0x1000 issue?  3/1/18 workaround for some weird stuff being seen.
                    if not (Index % 0x200):
                        Index-=0xE00
                        if Verbose:
                            sys.stderr.write("2-Changing Previous offset to a module 0x200, new value is {0:08x}\n".format(Index))
                    #if (Index % 0x1000):
                    #    Index-=0xE00
                    #    sys.stderr.write("1-Changing Previous offset to a module 0x1000, new value is {0:08x}\n".format(Index))
                    if Verbose:
                        sys.stderr.write("wltr_frame_header structure is {0:08x}\n".format(M_ByteSizeOf(wltr_frame_header)))
                        
                    while Done == 0:
                        if Index >0:
                            if  DataFlowMode:
                                CurFrameHeader = wltr_dataflow_frame_header( RawData[Index:Index+M_ByteSizeOf(wltr_dataflow_frame_header)] )
                            else:
                                CurFrameHeader = wltr_frame_header( RawData[Index:Index+M_ByteSizeOf(wltr_frame_header)] )
                            # print("        Frame Signature {0:08x} at offset {1:08x}".format(CurFrameHeader.WltrFrameSignature, Index))
                            
                            if ( (CurFrameHeader.WltrFrameSignature & 0xFFFFFC00) == (ExpectedFrameHeaderSignature & 0xFFFFFC00) ):
                                Done = 1
                                sys.stderr.write("Valid Frame Signature detected {0:08x} at offset {1:08x}\n".format(CurFrameHeader.WltrFrameSignature, Index))
                                if NonModulo200Alignment == 0:      # obviously the non-modulo worked, force this if it hasn't been set.
                                    NonModulo200Alignment |= 16
                                PriorFrameLocation = Index
                                if SavedPreviousFrameOffset == Index and SavedPreviousFrameOffset > 0:           # this means the last search was equal to this searched
                                    if NonModulo200Alignment == 0:         #4/2/18
                                        LastUsedWorkaroundPreviousFrameOffset-=StepOffset
                                    else:
                                        LastUsedWorkaroundPreviousFrameOffset-=0x10000
                                    PriorFrameLocation = LastUsedWorkaroundPreviousFrameOffset          #3/8/18
                                    if Verbose:
                                        print "using last workaround"
                        else:
                            Done = 1
                            if Verbose:
                                sys.stderr.write("Searching did not find a valid signature\n")
                            #sys.exit(1)        #3/7/18 don't exit.

                        # if DefaultSectorSize == 0x200:       #3/14/18
                        if NonModulo200Alignment == 0:         #4/2/18
                            Index-=StepOffset       # MasterFrameHeader.TotalFrameSizeInBytes
                        else:
                            Index-=0x10000       # MasterFrameHeader.TotalFrameSizeInBytes
                    Done = 0       #4/2/18                           
                #sys.exit(1)            # was originally, just exiting, added the search routine above.

            # 3/8/18 change from "else:" to comparing frame
            if ( (CurFrameHeader.WltrFrameSignature & 0xFFFFFC00) == (ExpectedFrameHeaderSignature & 0xFFFFFC00) ):                        
            
                FrameNumbers.append(CurFrameHeader.FrameNum)
                FrameOffsets.append(PriorFrameLocation)
                FramesFound += 1
                PriorFrameNum = CurFrameHeader.FrameNum
                if Verbose:
                    sys.stderr.write("Starting Offset {0:08x} and PriorFrame Location {1:08x}\n".format(StartOffset, PriorFrameLocation))
                if StartOffset == 0:
                    if NonModulo200Alignment == 0:          #3/12/18 this was the original code that used the frame header information verbatim    3/20/18 change it if no issues have been found
                        if Verbose:                                
                            sys.stderr.write ("Standard Loop\n")
                        # loop backwards through the frames to get a list in reverse order
                        while ( ( CurFrameHeader.PrevFrameOffsetInBytes != PriorFrameLocation ) and
                                ( (CurFrameHeader.WltrFrameSignature & 0xFFFFFC00) == (ExpectedFrameHeaderSignature & 0xFFFFFC00) ) ):
                            if NonModulo200Alignment > 0 and PriorFrameLocation == 0:       #3/8/18 workaround for non-modulo 200h offset values (seeing 1000h)
                                PriorFrameLocation-=0xE00
                                if Verbose:
                                    sys.stderr.write ("Non-Modulo 200h Setting Offset to {0:08x}\n".format(PriorFrameLocation))
                            elif not (NonModulo200Alignment > 0 and PriorFrameLocation > 0):
                                PriorFrameLocation = CurFrameHeader.PrevFrameOffsetInBytes
                            if Verbose:                                
                                sys.stderr.write ("Setting Offset to {0:08x}\n".format(PriorFrameLocation))
                            if ( MasterFrameHeader.PrevFrameOffsetInBytes == PriorFrameLocation ):
                                if Verbose:                                
                                    sys.stderr.write ("Wrap condition breaking out of search loop\n")
                                # wrap condition
                                break
                            if  DataFlowMode:
                                CurFrameHeader = wltr_dataflow_frame_header( RawData[PriorFrameLocation:PriorFrameLocation+M_ByteSizeOf(wltr_dataflow_frame_header)] )
                            else:
                                CurFrameHeader = wltr_frame_header( RawData[PriorFrameLocation:PriorFrameLocation+M_ByteSizeOf(wltr_frame_header)] )



                            if ( (CurFrameHeader.WltrFrameSignature & 0xFFFFFC00) != (ExpectedFrameHeaderSignature & 0xFFFFFC00) ):
                                if Verbose:
                                    sys.stderr.write("3-Unexpected Frame Signature detected  {0:08x} at offset {1:08x}  Expected {2:08x}\n".format(CurFrameHeader.WltrFrameSignature, PriorFrameLocation,ExpectedFrameHeaderSignature))

                                # 3/8/18 need to search up from the
                                if NumOfFrames > 0:
                                    if Verbose:
                                        sys.stderr.write("Need to find the last valid frame in this file Signature {0:08x} with modulo offset {1:04x}\n".format(CurFrameHeader.WltrFrameSignature, (PriorFrameLocation & 0x1200)))
                                    
                                    Done = 0
                                    Index = PriorFrameLocation
                                    # does this have the correct 200h offset point?  3/1/18 workaround for some weird stuff being seen.
                                    if not (Index % 0x200):
                                        Index-=0xE00
                                        if Verbose:
                                            sys.stderr.write("2-Changing Previous offset to a module 0x200, new value is {0:08x}\n".format(Index))
                                    #if (Index % 0x1000):
                                    #    Index-=0xE00
                                    #    sys.stderr.write("2-Changing Previous offset to a module 0x1000, new value is {0:08x}\n".format(Index))
                                    #sys.stderr.write("wltr_frame_header structure is {0:08x}\n".format(M_ByteSizeOf(wltr_frame_header)))
                                        
                                    while Done == 0:
                                        if Index >0:
                                            if  DataFlowMode:
                                                CurFrameHeader = wltr_dataflow_frame_header( RawData[Index:Index+M_ByteSizeOf(wltr_dataflow_frame_header)] )
                                            else:
                                                CurFrameHeader = wltr_frame_header( RawData[Index:Index+M_ByteSizeOf(wltr_frame_header)] )
                                            # print("        Frame Signature {0:08x} at offset {1:08x}".format(CurFrameHeader.WltrFrameSignature, Index))
                                            
                                            if ( (CurFrameHeader.WltrFrameSignature & 0xFFFFFC00) == (ExpectedFrameHeaderSignature & 0xFFFFFC00) ):
                                                Done = 1
                                                if Verbose:
                                                    sys.stderr.write("Valid Frame Signature detected {0:08x} at offset {1:08x}\n".format(CurFrameHeader.WltrFrameSignature, Index))
                                                PriorFrameLocation = Index
                                                if SavedPreviousFrameOffset == Index and SavedPreviousFrameOffset > 0:           # this means the last search was equal to this searched
                                                    LastUsedWorkaroundPreviousFrameOffset-=StepOffset
                                                    PriorFrameLocation = LastUsedWorkaroundPreviousFrameOffset          #3/8/18
                                                    # print "2-using last workaround"
                                        else:
                                            Done = 1
                                            if Verbose:
                                                sys.stderr.write("Searching did not find a valid signature\n")
                                            #sys.exit(1)        #3/7/18 don't exit.
                                        if DefaultSectorSize == 0x200:       #3/14/18   MasterFrameHeader.TotalFrameSizeInBytes
                                            Index-=StepOffset       # normally CurFrameHeader.FrameSizeInBytes
                                            if Verbose:                                
                                                sys.stderr.write ("Frame Header Size in Bytes %d\n"%CurFrameHeader.FrameSizeInBytes)
                                        else:
                                            Index-=0x10000       # 

                                
                                if ( FramesFound ):
                                    break
                                else:
                                    sys.stderr.write("No valid frames found\n")
                                    # sys.exit(1)       #3/7/18 comment out

                            if PriorFrameNum < CurFrameHeader.FrameNum:
                                # expect frame number to be descending, if not it is a wrap condition
                                if Verbose:
                                    sys.stderr.write ("2-Frame Number is not descending Current {0}  Prior {1} and PriorFrameLocation {2:x}\n".format(CurFrameHeader.FrameNum, PriorFrameNum, PriorFrameLocation))
                                break
                            if ( FramesFound ):     #3/7/18 add If here since sys.exit is commented out above.
                                FrameNumbers.append(CurFrameHeader.FrameNum)
                                FrameOffsets.append(PriorFrameLocation)
                                FramesFound += 1
                                
                            PriorFrameNum = CurFrameHeader.FrameNum
                            SavedPreviousFrameOffset = PriorFrameLocation        #3/8/18
                    else:                         #3/12/18 this was the code that just searches in reverse order based on frame size.
                        if Verbose:                                
                            sys.stderr.write ("Workaround Loop\n")
                        # loop backwards through the frames to get a list in reverse order
                        InitialEntry = 0
                        while (PriorFrameLocation > 0):
                            if Verbose:
                                sys.stderr.write ("Setting Offset to {0:08x}\n".format(PriorFrameLocation))
                            if ( MasterFrameHeader.PrevFrameOffsetInBytes == PriorFrameLocation and InitialEntry > 0 ):
                                # wrap condition
                                if Verbose:                                
                                    sys.stderr.write ("Wrap condition breaking out of search loop\n")
                                    sys.stderr.write ("Prior Frame Location %x"%PriorFrameLocation + "  PrevFrameOffsteInBytes %x"%CurFrameHeader.PrevFrameOffsetInBytes + '  Frames Found %d\n'%FramesFound)
                                break
                            if  DataFlowMode:
                                CurFrameHeader = wltr_dataflow_frame_header( RawData[PriorFrameLocation:PriorFrameLocation+M_ByteSizeOf(wltr_dataflow_frame_header)] )
                            else:
                                CurFrameHeader = wltr_frame_header( RawData[PriorFrameLocation:PriorFrameLocation+M_ByteSizeOf(wltr_frame_header)] )

                            if ( (CurFrameHeader.WltrFrameSignature & 0xFFFFFC00) != (ExpectedFrameHeaderSignature & 0xFFFFFC00) ):
                                if Verbose:
                                    sys.stderr.write("3-Unexpected Frame Signature detected  {0:08x} at offset {1:08x}  Expected {2:08x}\n".format(CurFrameHeader.WltrFrameSignature, PriorFrameLocation,ExpectedFrameHeaderSignature))

                                if ( FramesFound ):
                                    break
                                else:
                                    sys.stderr.write("No valid frames found\n")
                                    # sys.exit(1)       #3/7/18 comment out

                            else:           
                                if PriorFrameNum < CurFrameHeader.FrameNum:
                                    # expect frame number to be descending, if not it is a wrap condition
                                    if Verbose:
                                        print ("3-Frame Number is not descending Current {0}  Prior {1} and PriorFrameLocation {2:x}\n".format(CurFrameHeader.FrameNum, PriorFrameNum, PriorFrameLocation))
                                    # break
                                FrameNumbers.append(CurFrameHeader.FrameNum)
                                FrameOffsets.append(PriorFrameLocation)
                                FramesFound += 1

                            PriorFrameNum = CurFrameHeader.FrameNum
                            # PriorFrameLocation-=0x10000                  # 3/12/18 using 10000h since seeing corrupted files from System 4K drives, really should be 80000h or Frame size              
                            if DefaultSectorSize == 0x200:       #3/14/18
                                PriorFrameLocation-=StepOffset       # MasterFrameHeader.TotalFrameSizeInBytes
                                if Verbose:                                
                                    # print ("Wrap condition breaking out of search loop\n")
                                    sys.stderr.write ("Frame Header Size in Bytes %d\n"%CurFrameHeader.FrameSizeInBytes)
                                
                            else:
                                PriorFrameLocation-=0x10000       # workaround using 10000h since seeing corrupted files from System 4K drives, really should be 80000h or Frame size              
                            InitialEntry+=1
                            if Verbose:                                
                                sys.stderr.write ("Prior Frame Location %x"%PriorFrameLocation + '  PrevFrameOffsteInBytes %x'%CurFrameHeader.PrevFrameOffsetInBytes + '  Frames Found %d\n'%FramesFound)
                        

                    sys.stderr.write ("...Found frames %d\n"%(FramesFound))
                if Verbose:
                    # print the list of frames found
                    sys.stderr.write ("    Idx Frame# FileOffset\n")
                    sys.stderr.write ("   ==== ====== ==========\n")
                    for FrameOffsetIndex in range(FramesFound):
                        sys.stderr.write ("... {0:3} {1:04x}   {2:08x}\n".format(FrameOffsetIndex, FrameNumbers[FrameOffsetIndex], FrameOffsets[FrameOffsetIndex]))

                if (NumEntry > 0 and FramesFound > 0):     #12/12/18 restrict the number to process
                    FramesFound = NumEntry

                for FrameOffsetIndex in range(FramesFound,0,-1):
                    if OutputFilename != None:
                        # Open a new output file for each frame
                        if (OutputFileOption & 2) == 0:
                            # Open a new output file for each frame
                            OutputFile = file("{0}_{1}.txt".format(
                                OutputFilename, FrameNumbers[FrameOffsetIndex-1]) ,"w")
                        #12/18/17
                        #4/2/18 include csv text file output filename
                        if (OutputFileOption & 1) == 1:
                            OutputFilePtrCSV= file(OutputFileNameCSV + "_{0}.csv".format(
                                FrameNumbers[FrameOffsetIndex-1]) ,"w")
                    # output the Master Frame Header on the first output file
                    if FrameOffsetIndex == FramesFound:
                        NonModulo200Alignment = PrintMasterFrameHeader(MasterFrameHeader, OutputFile)
                        PrintMasterFrameHeaderSummary( MasterFrameHeader, MasterFrameFile)

                    if ( FrameOffsets[FrameOffsetIndex-1] > InputFileSize ):
                        sys.stderr.write("Next Frame offset(0x{0:08x}) exceeds input file size(0x{1:08x})\n".format(
                           FrameOffsets[FrameOffsetIndex-1], InputFileSize))
                        break     
                    
                    IndexOffset = FrameOffsets[FrameOffsetIndex-1]
                
                    if  DataFlowMode:
                        CurFrameHeader = wltr_dataflow_frame_header( RawData[IndexOffset:IndexOffset+M_ByteSizeOf(wltr_dataflow_frame_header)] )
                        IndexOffset += M_ByteSizeOf(wltr_dataflow_frame_header)
                    else:
                        CurFrameHeader = wltr_frame_header( RawData[IndexOffset:IndexOffset+M_ByteSizeOf(wltr_frame_header)] )
                        IndexOffset += M_ByteSizeOf(wltr_frame_header)
                    if Verbose:
                        print "...Parsing Frame {0}".format(CurFrameHeader.FrameNum)

                    if ( ( OutputFile != None ) or Verbose ):
                        #4/2/18 exclude normal text file output filename
                        if (OutputFileOption & 2) == 0:
                            PrintFrameHeader(CurFrameHeader, OutputFile )
                        #3/21/18
                        PrintFrameHeaderSummary( CurFrameHeader, MasterFrameHeader, FrameFile)
                    if ( (SearchLBAValid == 0) or (OutputFile != None) ):
                        # if in search mode, do not pollute output with header info for each frame
                        #4/2/18 exclude normal text file output filename
                        if (OutputFileOption & 2) == 0:
                            PrintFrameHeaderInfo( CurFrameHeader, OutputFile )
                    if CurFrameHeader.Mode == 0:         #Encoded Mode
                        ReturnPFCStatus = ParseFrameContents( MasterFrameHeader, CurFrameHeader, OutputFile, OutputFileComma, RawData, IndexOffset,
                                FrameOffsets[FrameOffsetIndex-1] + CurFrameHeader.FrameSizeInBytes, Verbose, 1, OutputFileOption ) 
                        if ( ReturnPFCStatus != 0 ):
                            sys.stderr.write("***Error Parsing Frame Contents in Frame {0} Offset {1:08x} Status {2}\n".format(CurFrameHeader.FrameNum, IndexOffset, ReturnPFCStatus))
                            # break     #3/7/18 comment out.
                    elif CurFrameHeader.Mode == 1:       #CDB Mode  (IBT mode)
                        sys.stderr.write("***In Bus Trace Mode\n")
                        # 3/5/18
                        if OutputFile == None:
                            print "None"
                        IBTParseUpperLevelPointers(RawData, OutputFile, OutputFilename, OutputFileNameCSV + ".csv", 0, Verbose, OutputFileOption)
                if ( (SearchLBAValid == 0) or (OutputFile != None) ):
                    #4/2/18 exclude normal text file output filename
                    if (OutputFileOption & 2) == 0:
                        FilePrintf( OutputFile, "=== Frame {0}, EndTime: %d "%CurFrameHeader.FrameNum )
                        PrintTimeStamp( CurFrameHeader.EndTimestamp, OutputFile )
                if (OutputFile != None):
                    OutputFile.close()
    if Verbose:
        PrintGlobalCounters(DataFlowMode)

    if DiscFile == 1:       #4/2/18
        MasterFrameFile.close()     #3/21/18
    FrameFile.close()
    return 0
main()
