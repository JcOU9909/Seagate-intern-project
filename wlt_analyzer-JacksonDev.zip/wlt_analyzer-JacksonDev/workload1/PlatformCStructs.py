#!/usr/bin/python
#  VCS Information: $File: //depot/Tools/CommandLineTools/WinCmd/PlatformCStructs.py $
#                   $Change: 591338 $
#                   $Revision: #11 $
#                   $Author: brian.t.edgar $
#                   $Date: 2013/07/22 $

import copy
import re

"""
    Scaffolding to allow reading of binary data into objects that
    behave just like C structs with uint16, uint32, bitfield, and
    enumerated members.
"""

# Endianness control (the endianness of the machine on which Python runs
# should not matter).  Just by changing this, one can overlay "structs" onto
# big endian or little endian binary data.  USAGE BY IMPORTERS:
#    import PlatformCStructs    # or from PlatformCStructs import *
#    PlatformCStructs.DEFAULT_LITTLE_ENDIAN[0] = False / True
DEFAULT_LITTLE_ENDIAN = [ True ]

# String to print when a field expected to contain a value matching an enum
# tag fails to do so (see the control FLAG_UNKNOWN_ENUM_TAGS below).
UNKNOWN_ENUM = "***Unrecognized enum tag***"

# Have this as a key in the enum dict if values without tags indicate an error
FLAG_UNKNOWN_ENUM_TAGS = "FlagUnknown"

# To make an enum that is a derived class of a struct member,
# do:
#   class myenum(uint8):   or
#   class bitenum(bitfield_struct_member): # width taken care of later
#       EnumDict = MakeEnumDict( """ TAG1, TAG2, TAG3 = 0xEE, TAG4 = 999,
#                                    FLAG_UNKNOWN_ENUM_TAGS """ )
# Note the FLAG_UNKNOWN_ENUM_TAGS is optional.  Then, to make class instances
# magically appear in your classes (myenum.TAG1), call:
#   SetupEnumTags(myenum or bitenum)
#
# Search forward for c_struct to see how to use that magic!
def MakeEnumDict( DefinitionText ):
    EnumDict = {}

    # Obtain the DefinitionText stripped of comments
    while True:  # Get rid of comments
        CommentMatch = re.search( "(//[^\r\n]*([\r\n]|$)|/\\*([^\\*]|\\*[^/])*\\*/)",
                                  DefinitionText )
        if not CommentMatch:
            break
        DefinitionText = ( DefinitionText[0:CommentMatch.span(0)[0]] +
                           DefinitionText[CommentMatch.span(0)[1]:] )

    Definitions = [ Def.strip() for Def in DefinitionText.split(",")
                    if Def.strip() ]

    CurrentEnumTagValue = 0  # default
    FlagUnknown = False
    for Def in Definitions:
        if Def == "FLAG_UNKNOWN_ENUM_TAGS":
            FlagUnknown = True
        elif "=" in Def:
            ValueString = Def.split("=")[1].strip()
            if ValueString[0:len("0x")] == "0x":
                CurrentEnumTagValue = int( ValueString, 16 )
            else:
                CurrentEnumTagValue = int( ValueString )
            EnumDict[ CurrentEnumTagValue ] = Def.split("=")[0].strip()
        else:
            EnumDict[ CurrentEnumTagValue ] = Def
        CurrentEnumTagValue += 1
    if FlagUnknown:
        EnumDict[ FLAG_UNKNOWN_ENUM_TAGS ] = True
    return EnumDict

# A "private" helper function
def ClassToString( Class ):
    return str(Class).split(".")[-1].split("'")[0].split(">")[0]

def SetupEnumTags( Class ):
    ClassName = ClassToString( Class )
    if not ClassName in Class.zzDerivedClasses:
        Class.zzDerivedClasses[ ClassName ] = Class
    for Key in [ K for K in Class.EnumDict.keys()
                 if str(K) != FLAG_UNKNOWN_ENUM_TAGS ]:
        exec( "Class.zzDerivedClasses[\"" + ClassName + "\"]." + Class.EnumDict[Key] + " = " + "%d" % Key )

# Some arithmetic (the names are specific to the organization out of which this c_struct script came)
def M_DivRound( x, y ):
    return int( ((x) + ((y) - 1))/(y) )
def M_RoundUpToMultiple(x,y):
    return ( M_DivRound( x,y ) * (y) )
def M_RoundDownToMultiple(x,y):
    return ( int( (x)/(y) ) * (y) )

# Control of raw printing of the C structs
STRUCT_LEVEL_INDENT = 3
ONE_TAB_STOP = 1

def IndentLines( Lines, NumTabStops = ONE_TAB_STOP ):
    return [ ( " " * STRUCT_LEVEL_INDENT * NumTabStops ) + Line for Line in Lines ]

# Basic widths
BITS_PER_BYTE = 8
BITS_PER_BYTE_SHIFT = 3
BITS_PER_NIBBLE = 4
NIBBLES_PER_BYTE = 2
BYTES_PER_WORD = 2
BITS_PER_WORD = (BITS_PER_BYTE * BYTES_PER_WORD)
BYTES_PER_LONGWORD = 4
BWORDSZ = 8
WORDS_PER_LONGWORD = 2
BITS_PER_LONGWORD = (BITS_PER_BYTE * BYTES_PER_LONGWORD)
SINT32_MIN = -2147483648
SINT32_MAX = 2147483647
UINT32_MAX = 4294967295
UINT16_MAX = 65535

HEX_DIGITS_PER_BYTE = 2
BYTE_WIDTH_MASK = 0xFF

# Bit definitions
BIT31 = 0x80000000
BIT30 = 0x40000000
BIT29 = 0x20000000
BIT28 = 0x10000000
BIT27 = 0x08000000
BIT26 = 0x04000000
BIT25 = 0x02000000
BIT24 = 0x01000000
BIT23 = 0x00800000
BIT22 = 0x00400000
BIT21 = 0x00200000
BIT20 = 0x00100000
BIT19 = 0x00080000
BIT18 = 0x00040000
BIT17 = 0x00020000
BIT16 = 0x00010000
BIT15 = 0x8000
BIT14 = 0x4000
BIT13 = 0x2000
BIT12 = 0x1000
BIT11 = 0x0800
BIT10 = 0x0400
BIT9  = 0x0200
BIT8  = 0x0100
BIT7  = 0x0080
BIT6  = 0x0040
BIT5  = 0x0020
BIT4  = 0x0010
BIT3  = 0x0008
BIT2  = 0x0004
BIT1  = 0x0002
BIT0  = 0x0001

# "private" helper function for uintNN_ and bitfield_struct_member
def GetEnumTag( Object ):
    EnumTag = ""
    if hasattr( Object.__class__, "EnumDict" ):
        if Object.Value in Object.__class__.EnumDict:
            EnumTag = Object.__class__.EnumDict[ Object.Value ]
        elif FLAG_UNKNOWN_ENUM_TAGS in Object.__class__.EnumDict:
            EnumTag = UNKNOWN_ENUM
    return EnumTag

class uintNN_struct_member:
    # Derived class must have a class instance called zzWidthInBytes

    # When an item's name begins with zz, it is to help the user using
    # an interactive Python shell that shows drop-downs when the user
    # presses ".".  The zz items are together at the end of the drop down.

    zzDerivedClasses = {} # Dictionary by name in an attempt to avoid namespace purgatory

    def zzSetBinaryData( self, BinaryDataForInt ):  # conversion to integer
        if len(BinaryDataForInt) != self.__class__.zzWidthInBytes:
            raise TypeError( "Initializing a uintNN with a string of bytes of inappropriate length" )
        self.Value = 0
        for I in range(self.__class__.zzWidthInBytes):
            if self.zzIsLittleEndian:
                self.Value = ( self.Value << BITS_PER_BYTE ) + \
                             ord(BinaryDataForInt[-1])
                BinaryDataForInt = BinaryDataForInt[0:-1]
            else:
                self.Value = ( self.Value << BITS_PER_BYTE ) + \
                             ord(BinaryDataForInt[0])
                BinaryDataForInt = BinaryDataForInt[1:]

    def zzGetBinaryData( self ): # conversion from integer to binary data blob
        BinaryData = ""
        IntData = self.Value
        for I in range(self.__class__.zzWidthInBytes):
            if self.zzIsLittleEndian:
                BinaryData += chr( IntData & BYTE_WIDTH_MASK )
            else:
                BinaryData = chr( IntData & BYTE_WIDTH_MASK ) + BinaryData
            IntData >>= BITS_PER_BYTE
        return BinaryData

    def zzSetValue( self, IntValue ):
        self.Value = IntValue & \
                     ( ( 1 << ( self.__class__.zzWidthInBytes * BITS_PER_BYTE ) ) - 1 )
        if self.Value != IntValue:
            raise TypeError( "Attempting to set unsigned struct member to signed integer or integer that is too wide" )

    def __init__( self, BinaryOrIntDataForInt = 0, IsLittleEndian = DEFAULT_LITTLE_ENDIAN ):

        # Default argments, like other Python variables, refer to objects, not names.
        # DEFAULT_LITTLE_ENDIAN is a list so that after import, the value of that
        # object can be changed by the importer in order to enforce a new default.
        # if DEFAULT_LITTLE_ENDIAN referred simply to False or True, later assignments
        # to DEFAULT_LITTLE_ENDIAN would not impact the already established default
        # argument (False remains False and True remains True -- refreshing).
        if ( isinstance( IsLittleEndian, list ) ):
            IsLittleEndian = IsLittleEndian[0]
        if not isinstance( IsLittleEndian, bool ):
            raise TypeError( "IsLittleEndian argument to uintNN.__init__() must be one of True, False, [True], or [False]" )
        self.zzIsLittleEndian = IsLittleEndian  # Derived classes can init differently

        if BinaryOrIntDataForInt.__class__ == str:
            self.zzSetBinaryData( BinaryOrIntDataForInt )
        elif BinaryOrIntDataForInt.__class__ == bytes:
            self.zzSetBinaryData( BinaryOrIntDataForInt.decode("latin-1"))
        elif BinaryOrIntDataForInt.__class__ == int:
            self.zzSetValue( BinaryOrIntDataForInt )
        elif BinaryOrIntDataForInt == None:
            self.zzSetValue( 0 )
        else:
            raise TypeError( "uintNN struct members must be initialized with a string of bytes or an integer or None" )

        ClassName = ClassToString( self.__class__ )
        if ClassName in uintNN_struct_member.zzDerivedClasses:
            if self.__class__ != uintNN_struct_member.zzDerivedClasses[ClassName]:
                raise NameError( "Had trouble recording the name of the derived class you're creating" )
        else:
            uintNN_struct_member.zzDerivedClasses[ClassName] = self.__class__

        
    def __len__( self ):
        return self.__class__.zzWidthInBytes

    def zzGetValue( self ):
        return self.Value

    def zzTextLines( self, Name = None, StartByteOffset = 0 ):
        HexPrint = ( ( "%%0%dX" %
                       ( self.__class__.zzWidthInBytes * HEX_DIGITS_PER_BYTE ) ) %
                     self.Value )

        EnumTag = GetEnumTag( self )

        print(StartByteOffset, StartByteOffset.__class__)

        if EnumTag:
            return [ ( "[%04X]%s %s.%s (%s)\n" % ( StartByteOffset, Name,
                                                   ClassToString( self.__class__ ),
                                                   EnumTag, HexPrint ) ) ]
        else:
            return [ ( "[%04X]%s %s\n" % ( StartByteOffset, Name, HexPrint ) ) ]

    def __repr__( self ):
        return self.zzTextLines()[0][ len( "[0ABC]None " ) : ]


class uint8 (uintNN_struct_member):
    zzWidthInBytes = 1
    def __init__( self, BinaryDataForInt = None, IsLittleEndian = DEFAULT_LITTLE_ENDIAN ):
        uintNN_struct_member.__init__( self, BinaryDataForInt, IsLittleEndian )
class uint16 (uintNN_struct_member):
    zzWidthInBytes = 2
    def __init__( self, BinaryDataForInt = None, IsLittleEndian = DEFAULT_LITTLE_ENDIAN ):
        uintNN_struct_member.__init__( self, BinaryDataForInt, IsLittleEndian )
class uint32 (uintNN_struct_member):
    zzWidthInBytes = 4
    def __init__( self, BinaryDataForInt = None, IsLittleEndian = DEFAULT_LITTLE_ENDIAN ):
        uintNN_struct_member.__init__( self, BinaryDataForInt, IsLittleEndian )
class uint48 (uintNN_struct_member): # will be packed, of course
    zzWidthInBytes = 6
    def __init__( self, BinaryDataForInt = None, IsLittleEndian = DEFAULT_LITTLE_ENDIAN ):
        uintNN_struct_member.__init__( self, BinaryDataForInt, IsLittleEndian )
class uint64 (uintNN_struct_member):
    zzWidthInBytes = 8
    def __init__( self, BinaryDataForInt = None, IsLittleEndian = DEFAULT_LITTLE_ENDIAN ):
        uintNN_struct_member.__init__( self, BinaryDataForInt, IsLittleEndian )
class uint128 (uintNN_struct_member):
    zzWidthInBytes = 16
    def __init__( self, BinaryDataForInt = None, IsLittleEndian = DEFAULT_LITTLE_ENDIAN ):
        uintNN_struct_member.__init__( self, BinaryDataForInt, IsLittleEndian )

class bitfield_struct_member:
    zzDerivedClasses = {} # Dictionary by name in an attempt to avoid namespace purgatory

    def zzSetValue( self, IntValue ):
        self.Value = IntValue & ( ( 1 << ( self.WidthInBits ) ) - 1 )
        if self.Value != IntValue:
            raise TypeError( "Integer value is signed or too wide for bit field" )

    def zzGetValue( self ):
        return self.Value

    def __len__( self ):
        raise TypeError( "Cannot take the length of a bitfield" )

    def __init__( self, BitListLoToHigh ):
        self.WidthInBits = len(BitListLoToHigh)
        self.Value = 0
        while BitListLoToHigh:
            self.Value <<= 1
            self.Value |= BitListLoToHigh[-1]
            BitListLoToHigh = BitListLoToHigh[0:-1]

        ClassName = ClassToString( self.__class__ )
        if ClassName in bitfield_struct_member.zzDerivedClasses:
            if self.__class__ != bitfield_struct_member.zzDerivedClasses[ClassName]:
                raise NameError( "Had trouble recording the name of the derived class you're creating" )
        else:
            bitfield_struct_member.zzDerivedClasses[ClassName] = self.__class__

    def zzTextLines( self, Name = None, StartByteOffset = 0, BitsAlreadyConsumed = 0,
                     IsLittleEndian = DEFAULT_LITTLE_ENDIAN ):
        # Default argments, like other Python variables, refer to objects, not names.
        # DEFAULT_LITTLE_ENDIAN is a list so that after import, the value of that
        # object can be changed by the importer in order to enforce a new default.
        # if DEFAULT_LITTLE_ENDIAN referred simply to False or True, later assignments
        # to DEFAULT_LITTLE_ENDIAN would not impact the already established default
        # argument (False remains False and True remains True -- refreshing).
        if ( isinstance( IsLittleEndian, list ) ):
            IsLittleEndian = IsLittleEndian[0]
        if not isinstance( IsLittleEndian, bool ):
            raise TypeError( "IsLittleEndian argument to zzTextLines() must be one of True, False, [True], or [False]" )

        HexPrint = ( ( "%%0%dX" %
                       ( M_DivRound( self.WidthInBits, BITS_PER_NIBBLE ) ) ) %
                     self.Value )
        EndByteOffset = StartByteOffset + ( BitsAlreadyConsumed + self.WidthInBits - 1 ) / BITS_PER_BYTE
        EndBitsConsumed = ( BitsAlreadyConsumed + self.WidthInBits - 1 ) % BITS_PER_BYTE
        if IsLittleEndian:
            Range = ( "[%04X]%d-[%04X]%d" %
                      ( StartByteOffset, BitsAlreadyConsumed, EndByteOffset, EndBitsConsumed ) )
        else:
            Range = ( "[%04X]%d-[%04X]%d" %
                      ( StartByteOffset, ( BITS_PER_BYTE - 1 ) - BitsAlreadyConsumed,
                        EndByteOffset, ( BITS_PER_BYTE - 1 ) - EndBitsConsumed ) )

        EnumTag = GetEnumTag( self )

        if EnumTag:
            return [ ( "%s %s %s.%s (%s)\n" % ( Range, Name,
                                                ClassToString( self.__class__ ),
                                                EnumTag, HexPrint ) ) ]
        else:
            return [ ( "%s %s %s\n" % ( Range, Name, HexPrint ) ) ]

class c_struct(object):
    """
    The c_struct allows one to derive classes that act like C structs for the
    purpose of generating, interpreting, and manipulating blobs of binary
    data.  Derived classes must have a class instance like this:
      DefinitionText = \"\"\"
         // align 32
         // The align comment causes an exception to be thrown if a member
         // of bit width 32 or less starts on a non-aligned boundary.  Use
         // align 8 to achieve "packed" (this is the default).  Actually, this
         // is currently unsupported -- all c_structs are packed.
         uint32 ExampleUint32;   /* Multiline comments of this type are allowed */
         uint16 ExampleUint16;   // Comments can use /* or //.
         uint16 AnotherUint16;
         myenum SampleEnum;
         bitenum7:0 AnotherEnum; // An enum is a derived class of uintNN or
                                 // bitfield_struct_member with class
                                 // instance EnumDict.
         bit0:0 ExampleBit;      // Must follow endianness of structure
                                 // (little in this example, bit 0 first).
         bit30:0 ExampleBits;    // Within a field, always start with high bit
                                 // first even if little endian.
         uint8 Bad, Example;     // One member per ; please
      \"\"\"
    Class instances zzWidthInBytes and zzMemberList (which you are unlikely to
    use directly) will appear when the first object of the derived class is
    created, which happens when you create an instance or when you ask for the
    M_ByteSizeOf() your derived class (sorry, python doesn't seem to let you take
    the len() of a class, so len() can be used on instances of c_struct where
    M_ByteSizeOf() can be used on derived classes and instances).  You must create an
    instance of the class or ask for the M_ByteSizeOf() the class before creating
    instances of other c_structs which contain the former c_struct.  Objects of your
    class derived from c_struct will magically have properties with names like
    ExampleUint32, etc. (see member list above in DefinitionText)
    """

    zzDerivedClasses = {} # Dictionary by name in an attempt to avoid namespace purgatory

    def zzSetupDerivedClassInstances(self):
        # A slight thread safety risk can be alleviated by creating a dummy object
        # of derived class before spawning threads
        if not hasattr( self.__class__, "zzWidthInBytes" ):
            # Need to finish setting up this class
           
            # See if there is an alignment directive (AlignBoundary not used yet)
            AlignMatch = re.search( "align\\s+([0-9]+)([^0-9]|$)",
                                    self.__class__.DefinitionText.lower() )
           
            if AlignMatch:
                AlignBoundary = int(AlignMatch.groups()[0])
            else:
                AlignBoundary = BITS_PER_BYTE

            # Obtain the DefinitionText stripped of comments
            DefinitionText = self.__class__.DefinitionText
            while True:  # Get rid of comments
                CommentMatch = re.search( "(//[^\r\n]*([\r\n]|$)|/\\*([^\\*]|\\*[^/])*\\*/)",
                                          DefinitionText )
                
                if not CommentMatch:
                    break
                DefinitionText = ( DefinitionText[0:CommentMatch.span(0)[0]] +
                                   DefinitionText[CommentMatch.span(0)[1]:] )

            # Obtain the text of the member definitions: [ ( "uint32", "Memb" ), ...
            MemberDefs = [ tuple( Def.split() ) for Def in DefinitionText.split(";")
                           if Def.strip() ]
            
            # Fill in the class instance zzMemberList with tuples of:
            #    ( type, "MembName", width-in-bits )
            CountedBits = 0
            CurrentBitPos = -1
            MemberList = []
            WidthInBytes = 0
            for MemberDef in MemberDefs:
                
                if ":" in MemberDef[0]:  # bit7:7 or bitenum7:5
                    BitRangeMatch = re.match( "^([a-zA-Z0-9_]*[a-zA-Z_]+)\\s*([0-9]+):([0-9]+)$", MemberDef[0] )
                    if not BitRangeMatch:
                        raise TypeError( "Illegal format for declaring a bitfield member" )
                    BitGroups = BitRangeMatch.groups()
                    ( UpperBit, LowerBit ) = [ int( Bit ) for Bit in BitGroups[1:] ]
                    ClassName = ( BitGroups[0] == "bit" ) and "bitfield_struct_member" or BitGroups[0]
                    if ClassName in bitfield_struct_member.zzDerivedClasses:
                        TheClass = bitfield_struct_member.zzDerivedClasses[ ClassName ]
                    else:
                        TheClass = eval( ClassName )
                    MemberList.append( ( TheClass, MemberDef[1],
                                         ( UpperBit - LowerBit ) + 1 ) )
                    CountedBits += ( UpperBit - LowerBit ) + 1
                    while CountedBits >= BITS_PER_BYTE:
                        WidthInBytes += 1
                        CountedBits -= BITS_PER_BYTE
                    if LowerBit > UpperBit:
                        raise TypeError( "Overlapping or out-of-order bitfields in struct" )
                    if self.zzIsLittleEndian:
                        if ( ( CurrentBitPos + 1 ) != LowerBit ) and not ( ( LowerBit == 0 )  and ( ( ( CurrentBitPos + 1 ) % BITS_PER_BYTE ) == 0 ) ):
                            raise TypeError( "Out-of-order or overlapping bitfields in little endian struct" )
                        CurrentBitPos = UpperBit
                    else:
                        if CurrentBitPos == -1:
                            if ( ( UpperBit + 1 ) % BITS_PER_BYTE ):
                                raise TypeError( "Out-of-order or overlapping bitfields in big endian struct" )
                        else:
                            if UpperBit != CurrentBitPos:
                                raise TypeError( "Out-of-order (2) or overlapping bitfields in big endian struct" )
                        CurrentBitPos = LowerBit - 1
                else: # Not a bit member
                    if ( ( ( CurrentBitPos != -1 ) and not self.zzIsLittleEndian ) or
                         ( ( CurrentBitPos not in ( [-1] + list(range( BITS_PER_BYTE - 1, 71, BITS_PER_BYTE ) ) ) )
                           and self.zzIsLittleEndian ) ):
                        raise TypeError( "Expected additional bitfield member(s)" )
                    if MemberDef[0] in c_struct.zzDerivedClasses:
                        TheClass = c_struct.zzDerivedClasses[ MemberDef[0] ]
                    elif MemberDef[0] in uintNN_struct_member.zzDerivedClasses:
                        TheClass = uintNN_struct_member.zzDerivedClasses[MemberDef[0]]
                    else:
                        TheClass = eval( MemberDef[0] )
                    MemberList.append( ( TheClass, MemberDef[1],
                                         TheClass.zzWidthInBytes * BITS_PER_BYTE ) )
                    WidthInBytes += TheClass.zzWidthInBytes
                    
                exec( "self.__class__." + MemberDef[1] + " = property( lambda self: self.zzReadMember( " +
                      "%d" % ( len( MemberList ) - 1 ) + " ), lambda self, value: self.zzWriteMember( " +
                      "%d" % ( len( MemberList ) - 1 ) + ", value ) )" )
            
            self.__class__.zzMemberList = MemberList
            self.__class__.zzWidthInBytes = WidthInBytes

    def zzSetBinaryData( self, BinaryData ):
        Types = [ Type for ( Type, Name, WidthInBits ) in self.__class__.zzMemberList ]
        WidthsInBits = [ WidthInBits for ( Type, Name, WidthInBits )
                         in self.__class__.zzMemberList ]
        self.zzMembers = []
        BitsLoToHiToUse = []
        for I in range( len(self.__class__.zzMemberList) ):
            if not issubclass( Types[I], bitfield_struct_member ):
                if BitsLoToHiToUse:
                    raise TypeError( "Confusion on struct member '%s'.  An improper struct definition may have slipped by." % self.__class__.zzMemberList[I][1] )
                try:
                    Member = Types[I]( BinaryData[0:Types[I].zzWidthInBytes],
                                       self.zzIsLittleEndian )
                except TypeError: # Derived class used default endian control
                    Member = Types[I]( BinaryData[0:Types[I].zzWidthInBytes] )
                self.zzMembers.append( Member )
                BinaryData = BinaryData[Types[I].zzWidthInBytes:]
            else:
                InitBitsLoToHi = []
                while len(InitBitsLoToHi) < WidthsInBits[I]:
                    if len(BitsLoToHiToUse):
                        NumBits = min( WidthsInBits[I] - len(InitBitsLoToHi),
                                       len(BitsLoToHiToUse) )
                        if self.zzIsLittleEndian:
                            InitBitsLoToHi += BitsLoToHiToUse[0:NumBits]
                            BitsLoToHiToUse = BitsLoToHiToUse[NumBits:]
                        else:
                            InitBitsLoToHi = BitsLoToHiToUse[-NumBits:] + InitBitsLoToHi
                            BitsLoToHiToUse = BitsLoToHiToUse[0:-NumBits]
                    else:
                        BitsLoToHiToUse = [ ( ( ord(BinaryData[0]) & (1 << Shift) ) and 1 or 0 )
                                            for Shift in range(BITS_PER_BYTE) ]
                        BinaryData = BinaryData[1:]
                self.zzMembers.append( Types[I]( InitBitsLoToHi ) )

        if BinaryData or BitsLoToHiToUse:
            raise TypeError( "Incorrect amount of binary data used to initialize a c_struct" )

    def zzGetBinaryData( self ):
        BinaryData = ""
        IntToPack = 0
        NumBitsToPack = 0
        for Member in self.zzMembers:
            if not isinstance( Member, bitfield_struct_member ):
                if NumBitsToPack:
                    raise TypeError( "Error packing struct fields into binary data.  An improper struct definition may have slipped by." )
                BinaryData += Member.zzGetBinaryData()
            else:
                if self.zzIsLittleEndian:
                    IntToPack |= Member.zzGetValue() << NumBitsToPack
                else:
                    IntToPack = (IntToPack << Member.WidthInBits) | Member.zzGetValue()
                NumBitsToPack += Member.WidthInBits
                if not ( NumBitsToPack % BITS_PER_BYTE ):
                    while NumBitsToPack:
                        if self.zzIsLittleEndian:
                            BinaryData += chr( IntToPack & ( ( 1 << BITS_PER_BYTE ) - 1 ) )
                            IntToPack >>= BITS_PER_BYTE
                        else:
                            BinaryData += chr( IntToPack >> ( NumBitsToPack - BITS_PER_BYTE ) )
                            IntToPack &= ( 1 << ( NumBitsToPack - BITS_PER_BYTE ) ) - 1
                        NumBitsToPack -= BITS_PER_BYTE
        if NumBitsToPack:
            raise TypeError( "Error (2) packing struct fields into binary data.  An improper struct definition may have slipped by." )

        return BinaryData

    def __init__( self, BinaryData = None, IsLittleEndian = DEFAULT_LITTLE_ENDIAN, Name = None ):

        # Default argments, like other Python variables, refer to objects, not names.
        # DEFAULT_LITTLE_ENDIAN is a list so that after import, the value of that
        # object can be changed by the importer in order to enforce a new default.
        # if DEFAULT_LITTLE_ENDIAN referred simply to False or True, later assignments
        # to DEFAULT_LITTLE_ENDIAN would not impact the already established default
        # argument (False remains False and True remains True -- refreshing).
        if ( isinstance( IsLittleEndian, list ) ):
            IsLittleEndian = IsLittleEndian[0]
        if not isinstance( IsLittleEndian, bool ):
            raise TypeError( "IsLittleEndian argument to c_struct.__init__() must be one of True, False, [True], or [False]" )
        self.zzIsLittleEndian = IsLittleEndian

        self.zzSetupDerivedClassInstances( )

        if BinaryData == None:
            BinaryData = chr(0) * self.__class__.zzWidthInBytes

        # print(type(BinaryData))
        self.zzSetBinaryData( BinaryData )
        self.zzName = Name

        # print(self.zzMembers)
        # print("##################")

        ClassName = ClassToString( self.__class__ )
        if ClassName in c_struct.zzDerivedClasses:
            if self.__class__ != c_struct.zzDerivedClasses[ClassName]:
                raise NameError( "Couldn't determine class name for a derived class of c_struct" )
        else:
            c_struct.zzDerivedClasses[ClassName] = self.__class__

    def SetName( self, Name ):
        self.zzName = Name

    def __len__( self ):
        # Since the length of this object is being taken, we know __init__ has
        # been called to set up zzWidthInBytes
        return self.__class__.zzWidthInBytes

    def zzByteSizeOfMember( self, AttrNameChain ): # Could be "SubStructA.SubB.Field"
        Names = [ Name for ( Type, Name, Width ) in self.__class__.zzMemberList ]
        SubAttrNames = AttrNameChain[1:]
        AttrName = AttrNameChain[0]
        if AttrName in Names:
            Index = Names.index(AttrName)
            if len(SubAttrNames):
                return self.zzMembers[Index].zzByteSizeOfMember( SubAttrNames )
            else:
                return len( self.zzMembers[Index] )
        else:
            raise AttributeError( "No struct member with name '%s' found" % AttrName )

    def zzByteOffsetOfMember( self, AttrNameChain ):
        Names = [ Name for ( Type, Name, Width ) in self.__class__.zzMemberList ]
        WidthsInBits = [ Width for ( Type, Name, Width ) in self.__class__.zzMemberList ]
        SubAttrNames = AttrNameChain[1:]
        AttrName = AttrNameChain[0]
        if AttrName in Names:
            Index = Names.index(AttrName)
            StartByteOffset = sum( WidthsInBits[0:Index] ) / BITS_PER_BYTE
            if sum( WidthsInBits[0:Index] ) % BITS_PER_BYTE:
                raise AttributeError( "Tried to take byte offset of member '%s', but that is non-byte-aligned bitfield." % AttrName )
            if len(SubAttrNames):
                return ( StartByteOffset + self.zzMembers[Index].zzByteOffsetOfMember( SubAttrNames ) )
            else:
                return ( StartByteOffset )
        else:
            raise AttributeError( "No struct member with name '%s' found (2)" % AttrName )

    def zzGetValue( self ):
        return self

    def zzWriteMember( self, Index, Value ):
        if isinstance( self.zzMembers[Index], c_struct ):
            OldType = self.zzMembers[Index].__class__
            self.zzMembers[Index] = copy.deepcopy( Value )
            if self.zzMembers[Index].__class__ != OldType:
                raise AttributeError( "Struct being copied into member of another struct is of incompatible type" )
        else: # uintNN_struct_member perhaps
            self.zzMembers[Index].zzSetValue( Value )

    def zzReadMember( self, Index ):
        return self.zzMembers[Index].zzGetValue()

    def zzTextLines(self, Name = None, StartByteOffset = 0 ):
        
        if Name == None:
            Name = self.zzName
        Lines = []
        if Name == None:
            Lines.append( "struct " + ClassToString( self.__class__ ) + "\n" )
        else:
            Lines.append( Name + " of type " + 
                          ClassToString( self.__class__ ) + "\n" )
            
       
        Names = [ Name for ( Type, Name, Width ) in self.__class__.zzMemberList ]
        WidthsInBits = [ Width for ( Type, Name, Width ) in self.__class__.zzMemberList ]
        StartBitOffset = StartByteOffset * BITS_PER_BYTE
        
        # print([ Type for ( Type, Name, Width ) in self.__class__.zzMemberList ])
        for Index in range( len( self.zzMembers ) ):
            if isinstance( self.zzMembers[Index], bitfield_struct_member ):
                Lines += IndentLines( self.zzMembers[Index].zzTextLines(Names[Index], int(StartBitOffset / BITS_PER_BYTE),
                                                                        StartBitOffset % BITS_PER_BYTE, self.zzIsLittleEndian ) )
            else:
                Lines += IndentLines( self.zzMembers[Index].zzTextLines( Names[Index], int(StartBitOffset / BITS_PER_BYTE )) )
            StartBitOffset += WidthsInBits[Index]
        return Lines

    def __repr__( self ):
        Name = "<<Instance>>"
        if self.zzName != None:
            Name = self.zzName
        return "".join( self.zzTextLines( Name ) )

    # Sanity check function to see if any c-struct "enumerated" members have unknown values
    def zzUnknownStructMemberValue( self ):
        TextLines = self.zzTextLines( "Dummy" )
        for Line in TextLines:
            if UNKNOWN_ENUM in Line:
                return Line.strip()
        return ""

# Structure and other Arithmetic
def sizeof( Item ):  # Behave as sizeof() would behave on a byte-granular machine
                     # You can take the sizeof a type or an instance
    IsSub = False
    try:
        IsSub = issubclass( Item, c_struct )
    except TypeError:
        IsSub = False
    IsSubUint = False
    try:
        IsSubUint = issubclass( Item, uintNN_struct_member )
    except TypeError:
        IsSubUint = False

    if IsSub and not hasattr( Item, "zzWidthInBytes" ):
        Dummy = Item( None )  # This should initialize zzWidthInBytes
        ByteSize = len( Dummy )
    elif IsSub or IsSubUint:
        ByteSize = Item.zzWidthInBytes
    elif hasattr( Item, "zzGetBinaryData" ):
        ByteSize = len(Item.zzGetBinaryData())
    else:
        ByteSize = len(Item)
    if not ByteSize:
        raise TypeError( "Cannot get byte size of your item." )
    return ByteSize

def M_ByteSizeOf( Item ):
    return sizeof( Item ) # Again, we "emulate" a byte-granular machine

def M_Uint16SizeOf( Item ):
    return M_ByteSizeOf(Item) / M_ByteSizeOf(uint16)
def M_Uint32SizeOf( Item ):
    return M_DivRound( ByteSizeOf(Item), M_ByteSizeOf(uint32) )

def M_ByteOffsetOf( _type, _memberstring ):
    Dummy = _type( None )
    return Dummy.zzByteOffsetOfMember( _memberstring.split(".") )
def M_ByteSizeOfMember( _type, _memberstring ):
    Dummy = _type( None )
    return Dummy.zzByteSizeOfMember( _memberstring.split(".") )
def M_ByteOffsetAfterMember( _type, _memberstring ):
    return M_ByteOffsetOf( _type, _memberstring ) + M_ByteSizeOfMember( _type, _memberstring )

if __name__ == "__main__":
    import sys

    # You can use zzGetBinaryData() at any time to spew out the current
    # binary representation of the structure.  Most things associated with
    # c_structs start with zz so that when you are using an IDE, the member
    # dropdown shows first those members that you defined (and probably care
    # more about).
    def HexPrint( Name, Struct ):
        Binary = Struct.zzGetBinaryData()
        print (Name + ": " + repr( [ "%02X" % ord(Char) for Char in Binary ] ))

    # Before you use an enum in a struct, you must call SetupEnumTags( your_enum )
    # Note how the printouts differ when FLAG_UNKNOWN_ENUM_TAGS is specified (or not)
    class regular_enum( uint8 ):
        EnumDict = MakeEnumDict(
          """ TAG_A = 1,
              TAG_B, TAG_C,
              TAG_99 = 99, FLAG_UNKNOWN_ENUM_TAGS """
                               )
        def __init__(self, Data):
            uint8.__init__(self, Data)

    SetupEnumTags( regular_enum )  # must call now to get around namespace issues

    # This enum doesn't specify FLAG_UNKNOWN_ENUM_TAGS
    class lba( bitfield_struct_member ):
        EnumDict = MakeEnumDict(
          """ TAG_ZERO, TAG_ONE, TAG_MAX = 0x7FFFFFFF """
                                )
        def __init__(self, Data):
            bitfield_struct_member.__init__(self, Data)

    SetupEnumTags( lba )

    class file_header( c_struct ):
        DefinitionText = """
           uint8 Revision;
           regular_enum MyEnum;
           uint32 LengthInBytes;  // badly aligned, no complaint
                                  // the align NN isn't active yet
           bit0:0 MyBit; // In little endian, lower bits first
           lba31:1 LBA;  // Within a bitfield, upper bit index first always
        """

    # Note:  Before you use a struct inside another struct, you must create an
    # object of that struct (the initializer is a blob of binary data)
    Header = file_header( chr(0xFE) * M_ByteSizeOf( file_header ) )

    sys.stdout.writelines( Header.zzTextLines( "Header" ) )

    print ("Now a printout using print")

    print (Header)

    # The members of a struct are in the list zzMembers, and
    # they have the types given in the definition text (uint8, regular_enum, etc).
    # print repr(Header.zzMembers)

    # The class (once an object of the class has been created) has a member
    # list of tuples ( member_class, member_name_string, WidthInBits )
    print (repr(file_header.zzMemberList))

    HexPrint( "Header bytes" , Header )

    # Note how enum tags can be referenced
    Header.Revision = 1
    Header.MyEnum = regular_enum.TAG_C
    Header.LBA = lba.TAG_MAX
    Header.LengthInBytes = 0x00010203
    Header.MyBit = Header.MyBit ^ 1

    sys.stdout.writelines( Header.zzTextLines( "Updated Header" ) )

    HexPrint( "Updated Header bytes" , Header )

    class bigger_struct( c_struct ):
        DefinitionText = """
           file_header Hdr;
           uint32      SomeContent;
        """
        def __init__(self, Data):
            c_struct.__init__(self, Data)

    Bigger = bigger_struct( " " * M_ByteSizeOf( bigger_struct ) )

    Bigger.Hdr = Header  # deep copied
    Bigger.Hdr.Revision = 3  # Header is untouched by this

    if M_ByteSizeOfMember( bigger_struct, "Hdr" ) != 10:
        print ("OOOPS 1")
        sys.exit(1)

    if M_ByteSizeOfMember( bigger_struct, "SomeContent" ) != 4:
        print ("OOPS 2")
        sys.exit(1)

    if M_ByteOffsetOf( bigger_struct, "Hdr" ) != 0:
        print ("OOPS 3")
        sys.exit(1)

    if M_ByteOffsetOf( bigger_struct, "Hdr.MyEnum" ) != 1:
        print ("OOPS 4")
        sys.exit(1)

    if M_ByteSizeOfMember( bigger_struct, "Hdr.LengthInBytes" ) != 4:
        print ("OOPS 5")
        sys.exit(1)

    print ("Test Successful")
