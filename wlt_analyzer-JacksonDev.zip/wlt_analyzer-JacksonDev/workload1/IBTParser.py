import sys
import time
from optparse import OptionParser
# import logging
# import logging.config
import struct
from collections import namedtuple
import os
import csv

IBTVersion = "v1.03 04/09/2018"

FAIL                     = 0
PASS                     = 1

# used for interface_mode
SATA                     = 0
SAS                      = 1

WLTR_WRITE_COMMAND       = 0x00000001
WLTR_READ_COMMAND        = 0x00000002
WLTR_STREAM_START        = 0x00000004
WLTR_STREAM_TERMINATION  = 0x00000008
WLTR_LPC_COMMAND         = 0x00000010
WLTR_RESET_EVENT         = 0x00000020
WLTR_HOST_NODE_FREED     = 0x00000040
WLTR_SEC_MARKER          = 0xF0
EVENT_TYPE_HEADER_VALUE  = 0xED
WRAP_SIGNATURE           = 0x5752574C
HEADER_SIGNATURE_SATA    = 0x5754483C
FOOTER_SIGNATURE_SATA    = 0x57544608
HEADER_SIGNATURE_SAS     = 0x5753483C
FOOTER_SIGNATURE_SAS     = 0x57534608

FRAME_HEADER_FIELDS   = ('Signature', 'FrameNum', 'Rev', 'StartTime', 'EndTime', 'PrevFrameOffsetBytes', 'Count', 'Session', 'Mode', 'FrameSizeInBytes', 'Duration', 'Reads', 'Writes', 'OneSecMarkers', 'WrapLocation', 'Resv2')
FRAME_HEADER_SIZES    = (32,          16,         16,    64,          64,        32,                     16,      8,         8,      32,                 32,         32,      32,       32,              32,             32)
FRAME_FOOTER_FIELDS   = ('Signature', 'Pad', 'FrameNum')
FRAME_FOOTER_SIZES    = (32,          16,     16)

EVENT_HEADER_NAMES    = ('Signature', 'Size', 'EventType', 'InfoBits', 'LUN', 'Port', 'QDepth', 'Tag', 'Timestamp')
EVENT_HEADER_SIZES    = (8,           8,      8,           8,          8,     8,      8,        8,     64)

CMD_EVENT_NAMES       = ('LBA', 'Feature', 'Count', 'DH', 'OpCode')
CMD_EVENT_SIZES       = (64,    16,        16,      8,    8)

HOST_NODE_EVENT_NAMES = ('OpCode', 'Status', 'Error')
HOST_NODE_EVENT_SIZES = (8,        8,        8)

STREAM_EVENT_NAMES    = ('LBA', 'Count')
STREAM_EVENT_SIZES    = (64,    16)

RESET_EVENT_NAMES     = ()
RESET_EVENT_SIZES     = ()

SAS_CMD_EVENT_NAMES       = ()
SAS_CMD_EVENT_SIZES       = ()

SAS_HOST_NODE_EVENT_NAMES = ('Key', 'Code', 'Qual', 'FRU', 'OpCode')
SAS_HOST_NODE_EVENT_SIZES = (8,     8,      8,      8,     8)

ADDITIONAL_EVENT_FIELDS = ('Resv', 'Delta', 'Offset', 'EventDesc', 'Status', 'Error', 'Key', 'Code', 'Qual', 'FRU', 'OpCode')

#     C type
# B	unsigned char	    integer	            1   uint8
# H	unsigned short	    integer	            2   uint16
# I	unsigned int	    integer	            4   uint32
# Q	unsigned long long	integer	            8   uint64
#

# logcfgFile = r"logging.conf"

# DEBUG_PRINTS = 1     #4/6/18 replace this with Verbose option

def GetByteSizeofStruct(SizeList):
    byteSize = 0
    for itemSize in SizeList:
        if itemSize == 8:
            byteSize += 1
        elif itemSize == 16:
            byteSize += 2
        elif itemSize == 32:
            byteSize += 4
        elif itemSize == 64:
            byteSize += 8
        else:
            print "GenerateUpackString: Unknown size mapping"
            # OutputLogFile.write("GenerateUpackString: Unknown size mapping (itemSize: %d)" % itemSize)
            #sys.exit(1)
            return 0
    return byteSize

def GenerateUpackString(SizeList):
    ret_string = "<"
    for itemSize in SizeList:
        if itemSize == 8:
            ret_string += 'B'
        elif itemSize == 16:
            ret_string += 'H'
        elif itemSize == 32:
            ret_string += 'I'
        elif itemSize == 64:
            ret_string += 'Q'
        else:
            print "GenerateUpackString: Unknown size mapping"
            #OutputLogFile.write("GenerateUpackString: Unknown size mapping (itemSize: %d)" % itemSize)
            #sys.exit(1)
            return 0
    return ret_string

class eventStructs(object):

    def __init__(self):
        self.Interface = 0

        self.FrameHeaderFields = ()
        self.FrameHeaderSizes = ()
        self.FrameHeaderString = ''

        self.FrameFooterFields = ()
        self.FrameFooterSizes = ()
        self.FrameFooterString = ''

        self.EventHeaderNames = ()
        self.EventHeaderSizes = ()
        self.EventHeaderString = ''

        self.CmdEventNames = ()
        self.CmdEventSizes = ()
        self.CmdEventString = ''

        self.HostNodeEventNames = ()
        self.HostNodeEventSizes = ()
        self.HostNodeEventString = ''

        self.StreamEventNames = ()
        self.StreamEventSizes = ()
        self.StreamEventString = ''

        self.ResetEventNames = ()
        self.ResetEventSizes = ()
        self.ResetEventString = ''

        self.AllEventNames = ()

    def SetupEventStructs(self, Interface):
        self.Interface = Interface
        self.FrameHeaderFields = FRAME_HEADER_FIELDS
        self.FrameFooterFields = FRAME_FOOTER_FIELDS
        self.FrameHeaderSizes = FRAME_HEADER_SIZES
        self.FrameFooterSizes = FRAME_FOOTER_SIZES
        self.EventHeaderNames = EVENT_HEADER_NAMES
        self.EventHeaderSizes = EVENT_HEADER_SIZES
        self.StreamEventNames = STREAM_EVENT_NAMES
        self.StreamEventSizes = STREAM_EVENT_SIZES
        self.ResetEventNames = RESET_EVENT_NAMES
        self.ResetEventSizes = RESET_EVENT_SIZES
        if Interface == SATA:
            self.CmdEventNames = CMD_EVENT_NAMES
            self.CmdEventSizes = CMD_EVENT_SIZES
            self.HostNodeEventNames = HOST_NODE_EVENT_NAMES
            self.HostNodeEventSizes = HOST_NODE_EVENT_SIZES
            self.AllEventNames = EVENT_HEADER_NAMES + CMD_EVENT_NAMES + ADDITIONAL_EVENT_FIELDS
        if Interface == SAS:
            self.CmdEventNames = SAS_CMD_EVENT_NAMES
            self.CmdEventSizes = SAS_CMD_EVENT_SIZES
            self.HostNodeEventNames = SAS_HOST_NODE_EVENT_NAMES
            self.HostNodeEventSizes = SAS_HOST_NODE_EVENT_SIZES
            self.AllEventNames = EVENT_HEADER_NAMES + SAS_CMD_EVENT_NAMES + ADDITIONAL_EVENT_FIELDS

        self.FrameHeaderString   = GenerateUpackString(self.FrameHeaderSizes)
        self.FrameFooterString   = GenerateUpackString(self.FrameFooterSizes)
        self.EventHeaderString   = GenerateUpackString(self.EventHeaderSizes)
        self.CmdEventString      = GenerateUpackString(self.CmdEventSizes)
        self.HostNodeEventString = GenerateUpackString(self.HostNodeEventSizes)
        self.StreamEventString   = GenerateUpackString(self.StreamEventSizes)
        self.ResetEventString    = GenerateUpackString(self.ResetEventSizes)

    def SetupEventStructsSAS(self, Interface):
        self.Interface = Interface
        self.CmdEventNames = SAS_CMD_EVENT_NAMES
        self.CmdEventSizes = SAS_CMD_EVENT_SIZES
        self.HostNodeEventNames = SAS_HOST_NODE_EVENT_NAMES
        self.HostNodeEventSizes = SAS_HOST_NODE_EVENT_SIZES
        self.AllEventNames = EVENT_HEADER_NAMES + SAS_CMD_EVENT_NAMES + ADDITIONAL_EVENT_FIELDS



def GenerateNamedTupleList(StringList):
    ret_string = ""
    for item in StringList:
        ret_string = ret_string + item + ' '

    return ret_string[:-1]





def CheckSize( ActualSizeBytes, ListofBitSizes, EventDesc, ByteOffset, OutputLogFile, OutputFileOption):
    TotalBits = sum(ListofBitSizes)  
    TotalBytes = (TotalBits/8)   # +1       #4/4/18 added the "+1', was always off by one for some reason.
    if ActualSizeBytes != TotalBytes:
        print 'Total size is unexpected. Exp: {:<4} Actual: {:<4}   Bits  {:<4}'.format(TotalBytes, ActualSizeBytes, TotalBits)
        if (OutputFileOption & 2) == 0:     #4/6/18
            OutputLogFile.write('Something is not right... total size is unexpected. Expected: {:<4} Actual: {:<4}  Bits  {:<4}  '.format(TotalBytes, ActualSizeBytes, TotalBits))
            OutputLogFile.write('Event: %s, ByteOffset %s\n' % (EventDesc, ByteOffset))
            #OutputLogFile.write('Bits: %d, \n'%TotalBits + '  %d\n'%ListofBitSizes)
        # print ' total size is unexpected. {:<4}'.format(ListofBitSizes)
        return 0
    return 1


def PrintFrameHeaderIBT( WLTRHeader ):
    print 'Frame Header Info'
    print '{:<13} {:<8} {:<8} {:<14} {:<8} {:<8} {:<13}'.format('Signature', 'FrameNum', 'FrameSize', 'OneSecMarkers', 'Session', 'Mode', 'WrapLocation')
    print '{:<13X} {:<8X} {:<8}  {:<14} {:<8} {:<8} {:<13}'.format(WLTRHeader['Signature'], WLTRHeader['FrameNum'], WLTRHeader['FrameSizeInBytes'], WLTRHeader['OneSecMarkers'], WLTRHeader['Session'], WLTRHeader['Mode'],  WLTRHeader['WrapLocation'])


def PrintEventHistory( EventHistoryList, OutputLogFile, interface ):

    # print '\n\n========================================================================== EVENT HISTORY =========================================================================='
    OutputLogFile.write('\n\n========================================================================== EVENT HISTORY ==========================================================================\n')

    if interface == SATA:
        """
        print '{:<15}: {:<8} {:<8} {:<20} {:<8} {:<20} {:<8} {:<8} {:<8} {:<8} {:<8} {:<8} {:<8} {:<8} {:<12} '.format('Timestamp',
                                                                                                   'Header',
                                                                                                   'Event',
                                                                                                   'Delta',
                                                                                                   'OpCode',
                                                                                                   'LBA',
                                                                                                   'InfoBits',
                                                                                                   'QD',
                                                                                                   'Tag',
                                                                                                   'Feature',
                                                                                                   'Count',
                                                                                                   'DH',
                                                                                                   'CmdCplt',
                                                                                                   'Error',
                                                                                                   'CDBDesc')
        """
        OutputLogFile.write('{:<15}: {:<8} {:<8} {:<20} {:<8} {:<20} {:<8} {:<8} {:<8} {:<8} {:<8} {:<8} {:<8} {:<8} {:<12}\n'.format('Timestamp',
                                                                                                   'Header',
                                                                                                   'Event',
                                                                                                   'Delta',
                                                                                                   'OpCode',
                                                                                                   'LBA',
                                                                                                   'InfoBits',
                                                                                                   'QD',
                                                                                                   'Tag',
                                                                                                   'Feature',
                                                                                                   'Count',
                                                                                                   'DH',
                                                                                                   'CmdCplt',
                                                                                                   'Error',
                                                                                                   'CDBDesc'))

        for event in EventHistoryList:
            for key in EVENT_FIELDS_ALL:
                if key not in event:
                    event[key] = 0
            """
            print '{:<15}: {:<8X} {:<8X} {:<20} {:<8X} {:<20X} {:<8} {:<8} {:<8} {:<8X} {:<8} {:<8X} {:<8X}/{:<8X}'.format(event['Timestamp'],
                                                                                                                           event['Signature'],
                                                                                                                           event['EventType'],
                                                                                                                           event['Delta'],
                                                                                                                           event['OpCode'],
                                                                                                                           event['LBA'],
                                                                                                                           event['InfoBits'],
                                                                                                                           event['QDepth'],
                                                                                                                           event['Tag'],
                                                                                                                           event['Feature'],
                                                                                                                           event['Count'],
                                                                                                                           event['DH'],
                                                                                                                           event['Status'],
                                                                                                                           event['Error'],
                                                                                                                           event['EventDesc'])
            """
            OutputLogFile.write('{:<15}: {:<8X} {:<8X} {:<20} {:<8X} {:<20X} {:<8} {:<8} {:<8} {:<8X} {:<8} {:<8X} {:<8X}/{:<8X}\n'.format(event['Timestamp'],
                                                                                                                           event['Signature'],
                                                                                                                           event['EventType'],
                                                                                                                           event['Delta'],
                                                                                                                           event['OpCode'],
                                                                                                                           event['LBA'],
                                                                                                                           event['InfoBits'],
                                                                                                                           event['QDepth'],
                                                                                                                           event['Tag'],
                                                                                                                           event['Feature'],
                                                                                                                           event['Count'],
                                                                                                                           event['DH'],
                                                                                                                           event['Status'],
                                                                                                                           event['Error'],
                                                                                                                           event['EventDesc']))

    elif interface == SAS:
        # print '{:<15}: {:<8} {:<8} {:<15} {:<100} {:<12}'.format('Timestamp', 'Header', 'Event', 'Delta', 'CDB', 'S\\C\\Q\\F')
        OutputLogFile.write( '{:<15}: {:<8} {:<8} {:<15} {:<100} {:<12}\n'.format('Timestamp', 'Header', 'Event', 'Delta', 'CDB', 'S\\C\\Q\\F'))

        for event in EventHistoryList:
            for key in EVENT_FIELDS_ALL:
                if key not in event:
                    event[key] = 0

            # Generate CDB list to print out
            str_cdb = ''
            if event['EventDesc'] == 'Cmd':
                for loop_i in range(0,32):
                    cdb_key = 'CDB'+str(loop_i)
                    str_cdb = str_cdb + '{:02X}'.format(event[cdb_key]) + ' '

            # Generate sense code to print out
            str_sense = ''
            if event['EventDesc'] == 'HostNode':
                str_sense = '{:02X}'.format(event['Key']) + '\\' + \
                            '{:02X}'.format(event['Code']) + '\\' + \
                            '{:02X}'.format(event['Qual']) + '\\' + \
                            '{:02X}'.format(event['FRU'])

            # print '{:<15}: {:<8X} {:<8} {:<15} {:<100} {:<12}'.format(event['Timestamp'], event['Signature'], event['EventDesc'], event['Delta'], str_cdb, str_sense)

            OutputLogFile.write( '{:<15}: {:<8X} {:<8} {:<15} {:<100} {:<12}\n'.format(event['Timestamp'], event['Signature'], event['EventDesc'], event['Delta'], str_cdb, str_sense))

def ParseEvent( Event, previousTimestamp, ByteOffset, traceData, eventStructs, OutputLogFile, OutputFileOption, Verbose):
    # Okay, we think we got a valid header, and we know the correct offset, lets find the size and event type
    try:
        EventDataSize = int(Event['Size'])
    except TypeError:
        print "Failed to find valid size: ", Event['Size']
        return ""
        #sys.exit(1)

    try:
        EventType = int(Event['EventType'])
    except TypeError:
        print "Failed to find event type: ", Event['EventType']
        return ""
        # sys.exit(1)

    Event['EventType'] = EventType
    Event['Size'] = EventDataSize

    if EventType == WLTR_HOST_NODE_FREED:
        EVENT_SIZES = eventStructs.EventHeaderSizes + eventStructs.HostNodeEventSizes
        EVENT_NAMES = eventStructs.EventHeaderNames + eventStructs.HostNodeEventNames
        EventDesc = 'HostNode'
    elif EventType == WLTR_RESET_EVENT:
        EVENT_SIZES = eventStructs.EventHeaderSizes + eventStructs.ResetEventSizes
        EVENT_NAMES = eventStructs.EventHeaderNames + eventStructs.ResetEventNames
        EventDesc = 'Reset'
    elif ( EventType & WLTR_STREAM_TERMINATION ) or ( EventType & WLTR_STREAM_START ):
        EVENT_SIZES = eventStructs.EventHeaderSizes + eventStructs.StreamEventSizes
        EVENT_NAMES = eventStructs.EventHeaderNames + eventStructs.StreamEventNames
        EventDesc = 'Stream'
    elif ( EventType == WLTR_LPC_COMMAND ) or ( EventType & WLTR_READ_COMMAND ) or ( EventType & WLTR_WRITE_COMMAND ):
        EVENT_SIZES = eventStructs.EventHeaderSizes + eventStructs.CmdEventSizes
        EVENT_NAMES = eventStructs.EventHeaderNames + eventStructs.CmdEventNames
        EventDesc = 'Cmd'
    else:
        print "Unknown Event Type: {:<8X}".format(EventType)
        if (OutputFileOption & 2) == 0:     #4/6/18
            OutputLogFile.write('Unknown Event Type: {:<8X}, Offset {:<8}\n'.format(EventType, ByteOffset))
        #sys.exit(1)
        return ""

    if eventStructs.Interface == SAS and EventDesc == 'Cmd':
        CDBSize = EventDataSize-GetByteSizeofStruct(eventStructs.EventHeaderSizes, OutputLogFile)

        if CDBSize > 32: 
            print 'Error: SAS CDB size is larger than 32 (reported: %d)' % CDBSize
            if (OutputFileOption & 2) == 0:     #4/6/18
                OutputLogFile.write('SAS CDB size is larger than 32 (reported: %d)\n' % CDBSize)
            print 'EventDataSize: %d' % EventDataSize
            print 'GetByteSizeofStruct(EventHeaderSizes): %d' % GetByteSizeofStruct(eventStructs.EventHeaderSizes)
            print eventStructs.EventHeaderSizes
            #sys.exit(0)
            return ""
        elif CDBSize == 0 :      #4/5/18
            print 'Error: SAS CDB size is zero (reported: %d)' % CDBSize
            if (OutputFileOption & 2) == 0:     #4/6/18
                OutputLogFile.write('SAS CDB size is zero (reported: %d)\n' % CDBSize)
            print 'EventDataSize: %d' % EventDataSize
            print 'GetByteSizeofStruct(EventHeaderSizes): %d' % GetByteSizeofStruct(eventStructs.EventHeaderSizes)
            print eventStructs.EventHeaderSizes
            #sys.exit(0)
            return ""

        eventStructs.CmdEventNames = ()
        eventStructs.CmdEventString = ()
        eventStructs.CmdEventSizes = ()

        for loop_i in range(0, CDBSize):
            cmd_str = 'CDB' + str(loop_i)
            eventStructs.CmdEventNames = eventStructs.CmdEventNames + (cmd_str, )
            eventStructs.CmdEventSizes = eventStructs.CmdEventSizes + (8, )

        EVENT_SIZES = eventStructs.EventHeaderSizes + eventStructs.CmdEventSizes
        EVENT_NAMES = eventStructs.EventHeaderNames + eventStructs.CmdEventNames

    UnpackString = GenerateUpackString( EVENT_SIZES )
    EventTuple = namedtuple('Event', GenerateNamedTupleList( EVENT_NAMES ))
    
    #4/9/18 seeing odd-ball value for the sizes from the array   (could do an '0 and ')
    if not CheckSize(EventDataSize, EVENT_SIZES, EventDesc, ByteOffset, OutputLogFile, OutputFileOption ):
        #if DEBUG_PRINTS:
        if Verbose:
            #print 'DEBUG INFORMATION'
            print 'EventType: %s' % EventDesc
            print 'Size from binary data: 0x%x' % EventDataSize
            print "Raw data starting at byte offset: %d "%ByteOffset + " at length %d"%EventDataSize
            s = traceData[ByteOffset:(ByteOffset+EventDataSize)]
            print "\t".join("{:02x}".format(ord(c)) for c in s)
            print '=========================================================================='
        #sys.exit(0)
        return ""

    #Now that we know the event type, we can correctly parse for all of the other data
    Event = EventTuple._asdict(EventTuple._make(struct.unpack_from(UnpackString, traceData, ByteOffset)))

    Event['Delta'] = Event['Timestamp'] - previousTimestamp

    Event['Offset'] = ByteOffset

    Event['EventDesc'] = EventDesc

    return Event


def ParseRawData( ldata, OutputLogFile, OutputFileOption, Verbose):

    global EVENT_FIELDS_ALL

    frame_header_size = 60
    frame_footer_size = 8
    second_marker_offset = 0

    max_data_size = 28

    size = ldata.__len__()

    EventStructs = eventStructs()
    EventStructs.SetupEventStructs(SATA)        #4/2/18 has to initialize this before if SAS or SATA is known...

    EVENT_FIELDS_ALL = EventStructs.AllEventNames

    for loop_i in range(0, 32):
        cdb_str = 'CDB' + str(loop_i)
        EVENT_FIELDS_ALL = EVENT_FIELDS_ALL + (cdb_str, )

    # =========================================================================
    # This section is to parse the header and footer
    # =========================================================================
    FrameHeader = namedtuple('Header', GenerateNamedTupleList(EventStructs.FrameHeaderFields))

    Header = FrameHeader._asdict(FrameHeader._make(struct.unpack_from(EventStructs.FrameHeaderString, ldata, 0)))
    if (OutputFileOption & 2) == 0:     #4/6/18
        OutputLogFile.write("HEADER Information\n" )
        OutputLogFile.write("  Signature    : 0x%x" % Header['Signature'] )
    if Header['Signature'] == HEADER_SIGNATURE_SATA:
        interface = SATA
        if (OutputFileOption & 2) == 0:     #4/6/18
            OutputLogFile.write(" - SATA\n")
    elif Header['Signature'] == HEADER_SIGNATURE_SAS:
        interface = SAS
        if (OutputFileOption & 2) == 0:     #4/6/18
            OutputLogFile.write(" - SAS\n")
    else:
        interface = 50    # make invalid.
        if (OutputFileOption & 2) == 0:     #4/6/18
            OutputLogFile.write(" - Invalid\n")
    if (OutputFileOption & 2) == 0:     #4/6/18
        OutputLogFile.write("  Wrap Location: 0x%x (%x)\n" % ( int(Header['WrapLocation']) , int(Header['WrapLocation']) + frame_header_size ) )
        OutputLogFile.write("  Frame Size   : %d\n" % Header['FrameSizeInBytes'] )
        OutputLogFile.write("  Header Size  : %d\n" % frame_header_size )
        OutputLogFile.write("  Frame Number : %d\n" % Header['FrameNum'] )
        OutputLogFile.write("  Mode         : %d" % Header['Mode'] )
        if Header['Mode'] == 1:
            OutputLogFile.write(": In Bus Trace Mode\n")
        else:
            OutputLogFile.write(": Workload Trace Mode\n")

        # (' '', '', '', 'Count', 'Session', '', '', '', 'Reads', 'Writes', 'OneSecMarkers', '', '')
        OutputLogFile.write("  Revision     : %d\n" % Header['Rev'] )
        OutputLogFile.write("  StartTime    : %d" % Header['StartTime'] )
        OutputLogFile.write(" - %f\n" % (float(Header['StartTime'] & 0xffffffffffff)/3600000000.0))          
        OutputLogFile.write("  EndTime      : %d" % Header['EndTime'] )
        OutputLogFile.write(" - %f\n" % (float(Header['EndTime'] & 0xffffffffffff)/3600000000.0))
        OutputLogFile.write("  Duration     : %d\n" % Header['Duration'] )
        OutputLogFile.write("  WrapLocation : %d\n" % Header['WrapLocation'] )
        OutputLogFile.write("  PrevOffset:    %d\n" % Header['PrevFrameOffsetBytes'] )

    FrameFooter = namedtuple('Footer', GenerateNamedTupleList(EventStructs.FrameFooterFields))
    Footer = FrameFooter._asdict(FrameFooter._make(struct.unpack_from(EventStructs.FrameFooterString, ldata, Header['FrameSizeInBytes'])))
    if (OutputFileOption & 2) == 0:     #4/6/18
        OutputLogFile.write("FOOTER Information\n" )
        OutputLogFile.write("  Signature    : 0x%x\n" % Footer['Signature'] )
        OutputLogFile.write("  Frame Num    : %d\n" % Footer['FrameNum'] )

    if Header['Mode'] != 1:
        if (OutputFileOption & 2) == 0:     #4/6/18
            OutputLogFile.write('Header Mode byte is not correct to parse this file.\n')
        print 'Error: Header Mode byte is not correct to parse this file.'
        # sys.exit(10)
        return "", "", "", SATA, 10
    # 4/2/18 added SAS signature, segregated SATA signatures
    if Header['Signature'] != HEADER_SIGNATURE_SATA and Footer['Signature'] != FOOTER_SIGNATURE_SATA and Header['Signature'] != HEADER_SIGNATURE_SAS and Footer['Signature'] != FOOTER_SIGNATURE_SAS:
        if (OutputFileOption & 2) == 0:     #4/6/18
            OutputLogFile.write('Header or Footer signatures could not be found. Expected:\n')
            OutputLogFile.write('  HEADER_SIGNATURE 0x%x\n' % HEADER_SIGNATURE_SATA)
            OutputLogFile.write('  HEADER_SIGNATURE 0x%x\n' % HEADER_SIGNATURE_SAS)
            OutputLogFile.write('  FOOTER_SIGNATURE 0x%x\n' % FOOTER_SIGNATURE_SATA)
            OutputLogFile.write('  FOOTER_SIGNATURE 0x%x\n' % FOOTER_SIGNATURE_SAS)
        print 'Error: could not find valid footer or header signatures'
        # sys.exit(11)
        return "", "", "", SATA, 11
    # 4/2/18 now determine the interface type.
    if interface == SAS:
        # 4/2/18 has to re-init this selected part for SAS (don't know if this really works....)
        # EventStructs.SetupEventStructsSAS(self, interface)
        #EventStructs.SetupEventStructs(SAS)        #4/2/18 has to re-initialize this since it was defaulted to SATA
        print "SAS, exiting"
        return "", "", "", SAS, 20
    elif interface == 50:       #4/2/18 can't determine, return.
        # print "Interface mode not defined"
        if (OutputFileOption & 2) == 0:     #4/6/18
            OutputLogFile.write('Interface mode is not defined, but will use SATA for now.\n')
        # will default to SATA for now
        interface = SATA
        
    # =========================================================================
    # I want to move all trace data to a simplified local 'array' for two
    # reasons:
    # 1. Easier indexing
    # 2. If there is a wrap condition, make that case easier as well
    # =========================================================================
    WrapLocation = Header['WrapLocation']

    TraceDataStartOffset = WrapLocation + frame_header_size
    TraceDataEndOffset = Header['FrameSizeInBytes']

    if WrapLocation:
        TraceDataNewestData = WrapLocation-5
        TraceDataOldestData = WrapLocation

        while struct.unpack_from('B', ldata, TraceDataOldestData)[0] != EVENT_TYPE_HEADER_VALUE:
            TraceDataOldestData += 1
            if TraceDataOldestData >= size:
                if (OutputFileOption & 2) == 0:     #4/6/18
                    OutputLogFile.write("Failed to find a valid event start header after the wrap location\n")
                print 'ERROR: Failed to find a valid event start header after the wrap location'
                #sys.exit(0)
                # will exit the loop, the following section will decode available data.
                break       #4/5/18 would prefer to parse the remaining available data, a break will do a return will abort existing data.
                #return
        if (OutputFileOption & 2) == 0:     #4/6/18
            OutputLogFile.write("First Event Start after wrap is at location 0x%x\n" % TraceDataOldestData )

        traceData = ldata[TraceDataStartOffset:TraceDataNewestData]
        traceData += ldata[TraceDataOldestData:TraceDataEndOffset]
    else:
        traceData = ldata[TraceDataStartOffset:TraceDataEndOffset]


    # =========================================================================
    # Now parse through each of these events
    # =========================================================================
    EventHist = []
    previousTimestamp = 0

    TraceDataEndOffset = traceData.__len__()
    offset_in_bytes = 0
    total_bytes_parsed = 0

    while offset_in_bytes < TraceDataEndOffset:
        # start at the wrap location if there is one
        # increment through the first bytes after the wrap signature to find a event signature
        EventTuple = namedtuple('Event', GenerateNamedTupleList(EventStructs.EventHeaderNames))

        Event = EventTuple._asdict(EventTuple._make(struct.unpack_from(EventStructs.EventHeaderString, traceData, offset_in_bytes)))

        while Event['Signature'] != EVENT_TYPE_HEADER_VALUE:
            offset_in_bytes += 1
            EventTuple = namedtuple('Event', GenerateNamedTupleList(EventStructs.EventHeaderNames))
            try:
                Event = EventTuple._asdict(EventTuple._make(struct.unpack_from(EventStructs.EventHeaderString, traceData, offset_in_bytes)))
            except struct.error:
                print 'Attempt to get event data failed'
                print GenerateUpackString(EventStructs.EventHeaderSizes)
                print offset_in_bytes
                #sys.exit(0)
                return Header, EventHist, Footer, interface, 1
            if total_bytes_parsed >= TraceDataEndOffset:
               print "Valid signature (0xED) not found in event header, found: ", Event['Signature']
               if (OutputFileOption & 2) == 0:     #4/6/18
                   OutputLogFile.write("Valid signature (0xED) not found in event header, found: %x. \nEnable DEBUG_PRINTS to see more information" % Event['Signature'])
               #if DEBUG_PRINTS:
               if Verbose:                
                   print 'DEBUG INFORMATION'
                   print '================='
                   PrintFrameHeaderIBT(Header)
                   print "30 bytes of raw data starting at byte offset: ", offset_in_bytes
                   s = traceData[offset_in_bytes:(offset_in_bytes+30)]
                   print "\t".join("{:02x}".format(ord(c)) for c in s)
                   #sys.exit(0)
               return Header, EventHist, Footer, interface, 2


        Event = ParseEvent(Event, previousTimestamp, offset_in_bytes, traceData, EventStructs, OutputLogFile, OutputFileOption, Verbose)
        offset_in_bytes += Event['Size']
        previousTimestamp = Event['Timestamp']
        total_bytes_parsed += Event['Size']

        EventHist.append(dict(Event))

        if 0:
            # print offset_in_bytes, UnpackString
            s = data[offset_in_bytes:(offset_in_bytes+28)]
            print "\t".join("{:02x}".format(ord(c)) for c in s)


    return Header, EventHist, Footer, interface, 0


def Pretty(d, indent=0):
    """
    A nicer way to print out dictionaries when needed
    """
    for key, value in d.iteritems():
        print '\t' * indent + str(key)
        if isinstance(value, dict):
            Pretty(value, indent+1)
        else:
            print '\t' * (indent+1) + str(value)


def IBTraceCommandLineHandler( ):
    if len( sys.argv ) < 2:
        IBTUsage()
        return 1
    # Extract the command line parameters
    InputFilename   = sys.argv[1]
    OutputFilename  = 'output.txt'
    #OutputFile      = None
    OutputFileNameComma = None
    #InputFilename   = None
    STXScript = 0
    Verbose = 0
    DefineCSVFile = 0
    OutputFileOption = 1
    
    # parse options
    ArgSkip = 0
    # print len(sys.argv)
    for i in range(2,len(sys.argv)):
        if ArgSkip:
            ArgSkip -= 1
            continue
        # print sys.argv[i]
        if sys.argv[i] == "-i":
            if len(sys.argv) >= i+2:
                InputFilename = sys.argv[i+1]
                ArgSkip += 1
                #print "...Input file base name = '{0}'".format(InputFilename)        
        elif sys.argv[i] == "-o":
            if len(sys.argv) >= i+2:
                OutputFilename = sys.argv[i+1]
                ArgSkip += 1
                #print "...Output file base name = '{0}'".format(OutputFilename)
        elif sys.argv[i] == "-v":
            Verbose = 1
            #print "...Verbose enabled"
        elif sys.argv[i] == "-notext":
            OutputFileOption |= 2
            #print "...No Text Output enabled"
        elif sys.argv[i] == "-csv":
            DefineCSVFile = 1
            OutputFileOption |= 1
            #print "...CSV file enabled"
        elif sys.argv[i] == "-s":
            STXScript = 1
            #print "...STX Script enabled"
    if DefineCSVFile == 1:
        OutputFileNameComma = OutputFilename + ".csv"
        print "...CSV Output file base name = '{0}'".format(OutputFileNameComma)
        
    
    return InputFilename, OutputFilename, OutputFileNameComma, STXScript, Verbose, OutputFileOption




def IBTUsage():
    print ("IBTParser usage\n")
    print ("Usage: %s [options]")
    print ("  -i       infile     - Specify input file")
    print ("  -o       outfile    - default=output.txt - Specify output file")
    print ("  -csv     Output CSV file")
    print ("  -notext  Do not Output CSV file")
    print ("  -s       store_true - Generate STX script")
    sys.exit()


def main():
    OutputFilename  = None
    # OutputFile      = None
    OutputFileNameComma = None
    InputFilename, OutputFilename, OutputFileNameComma, STXScript, Verbose, OutputFileOption = IBTraceCommandLineHandler( )
    ReturnStatus = IBTParseUpperLevel(InputFilename, OutputFilename, OutputFileNameComma, STXScript, Verbose, OutputFileOption)
    sys.exit()

def IBTParseUpperLevel(InputFilename, OutputFilename, OutputFilenameCSV, STXScript, Verbose, OutputFileOption):

    #if __name__ == "__main__":
    
    starttime = time.time()

    DEBUG_PRINTS = 0

    #outfile='output.csv'
    #OutputFilename = None
    #logging.basicConfig(format='%(asctime)s %(levelname)s:%(message)s',
    #                    filename='IDBTParser.log',
    #                    filemode='w',
    #                    level=logging.WARNING)
    #    return 1
    if OutputFilename == None:
        IBTUsage()
        # sys.exit(1)
        return 1
    else:
        if DEBUG_PRINTS:
            print ("Input  Filename: " + InputFilename)
            print ("Output Filename: " + OutputFilename)
            print ("Output Options:  " + str(OutputFileOption))
            print ("STX Script:      " + str(STXScript))
            if not OutputFilenameCSV == None:
                print ("Output CSV FN:   " + OutputFilenameCSV)

    print ('IBTParser.py Start\n')

    #outfile='output.csv'
    #OutputFilename = None
    #logging.basicConfig(format='%(asctime)s %(levelname)s:%(message)s',
    #                    filename='IDBTParser.log',
    #                    filemode='w',
    #                    level=logging.WARNING)
    #OutputLogFile = file("IDBTParser.log".format(
    #    OutputFilename, 0) ,"w")
    # open the output file to get text output
    if (OutputFileOption & 2) == 0:     #4/6/18
        OutputLogFile = file(OutputFilename ,"w")
    else:
        OutputLogFile = None
    try:
        with open(InputFilename, "rb") as binary_file:
            data = binary_file.read()
            #if DEBUG_PRINTS:
            #    print "Input file:           ", infile
            #    print "Number of bytes read: ", data.__len__()
            if (OutputFileOption & 2) == 0:     #4/6/18
                OutputLogFile.write("Input file: %s\n" % InputFilename)
                OutputLogFile.write("Number of bytes read: %s\n" % data.__len__())
    except IOError:
        print 'Failed to open file: ', InputFilename
        print 'Exiting'
        if (OutputFileOption & 2) == 0:     #4/6/18
            OutputLogFile.write("Failed to open file: %s\n" % InputFilename)
        # sys.exit(0)
        return 5
    Status = 0
    Header, CommandHist, Footer, interface_mode, Status = ParseRawData(data, OutputLogFile, OutputFileOption, Verbose)
    #if Status == 0 and DEBUG_PRINTS:
    if Status == 0 and Verbose:
        PrintFrameHeaderIBT(Header)

    if 0:
        for event in CommandHist:
            Pretty(event)
    if (OutputFileOption & 1) == 1:
        if not OutputFilenameCSV == None:    #4/5/18
            with open(OutputFilenameCSV, 'wb') as f:  # Just use 'w' mode in 3.x
                w = csv.DictWriter(f, EVENT_FIELDS_ALL)
                w.writeheader()
                w.writerows(CommandHist)
    if (OutputFileOption & 2) == 0:
        PrintEventHistory(CommandHist, OutputLogFile, interface_mode)

    print 'Total Number of Events:', len(CommandHist)

    print ""
    print "Script Runtime: %.2f (sec)" % (time.time() - starttime)



def IBTParseUpperLevelPointers(data, OutputLogFile, OutputFilename, OutputFileComma, STXScript, Verbose, OutputFileOption):

    #if __name__ == "__main__":
    
    starttime = time.time()


    #OutputLogFile = file("IDBTParser.log".format(
    #    OutputFilename, 0) ,"w")

    print ('IBTParser.py Start\n')
    Status = 0
    Header, CommandHist, Footer, interface_mode, Status = ParseRawData(data, OutputLogFile, OutputFileOption, Verbose)
    if Status == 0:
        PrintFrameHeaderIBT(Header)

    if 0:
        for event in CommandHist:
            Pretty(event)
    if (OutputFileOption & 2) == 0:
        with open(OutputFileComma, 'wb') as f:  # Just use 'w' mode in 3.x
            w = csv.DictWriter(f, EVENT_FIELDS_ALL)
            w.writeheader()
            w.writerows(CommandHist)
    if (OutputFileOption & 2) == 0:
        PrintEventHistory(CommandHist, OutputLogFile, interface_mode)

    print 'Total Number of Events:', len(CommandHist)

    print ""
    print "Script Runtime: %.2f (sec)" % (time.time() - starttime)



main()
