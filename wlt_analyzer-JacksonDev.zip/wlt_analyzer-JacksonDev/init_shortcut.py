#-------------------------------------------------------------------------------
# Name:        InitShortcut
# Purpose:     Creates a windows shortcut for the Population Analysis python script.
#
# Author:      230732
#
# Created:     18/02/202
# Copyright:   (c) 230732 2020
# Licence:     SEAGATE CONFIDENTIAL < Seagate Internal Use Only >
#-------------------------------------------------------------------------------

import win32com.client
import pythoncom
import os
from os.path import join
import sys

def create_shortcut(create_in, python_loc, script_loc, icon=None):
    """
    Creates a shortcut for python scripts
    """
    script_dir = os.getcwd()
    shell = win32com.client.Dispatch("WScript.Shell")
    shortcut = shell.CreateShortCut(create_in)
    shortcut.Targetpath = python_loc
    shortcut.Arguments = f'"{script_loc}"'
    shortcut.WorkingDirectory = script_dir
    shortcut.WindowStyle = 1  # 7 - Minimized, 3 - Maximized, 1 - Normal
    if not (icon is None):
        shortcut.IconLocation = icon
    shortcut.save()


def main():
    """
    Parses arguments from command line and runs main app with parsed arguments.
    """

    import argparse

    parser = argparse.ArgumentParser(description='Adds a windows shortcut file into the current working directory that points to the python script.')
    parser.add_argument('app_name',
                    help = 'The name of your application. This will also be the name of the windows shortcut.')
    parser.add_argument('python_script',
                    help = 'The filename of the python script. It should be located in the current directory.')
    parser.add_argument('python_path',
                    help = 'The path to pythonw.exe')
    parser.add_argument('--icon',
                    help = 'Relative path to the icon file (e.g "icon\\AppIcon.ico").' )

    args = parser.parse_args()

    app_name = args.app_name
    py_script = args.python_script
    python_path = args.python_path
    icon = args.icon

    if (app_name is None)  or  (py_script is None):
        parser.print_help()
        sys.exit(0)

    # app_name = 'PopulationAnalysis'       # Replace the string with the name of your application.
    # icon =     r'icons\cdf_C39_icon.ico'  # Comment out this line if no icon

    script_dir = os.getcwd()
    python_loc = join(python_path, "python.exe")
    icon_path =  None if icon is None else join(script_dir, icon)

    create_shortcut(os.path.join(script_dir, f'{app_name}.lnk'),
                    python_loc,
                    os.path.join(script_dir, py_script),
                    icon_path,
    )




if __name__ == '__main__':
    main()
