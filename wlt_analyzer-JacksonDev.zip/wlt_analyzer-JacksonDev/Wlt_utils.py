import os
import traceback, sys
import dask.dataframe as dd
import matplotlib
matplotlib.use('Qt5Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure

import numpy as np
import pandas as pd

from PyQt5 import uic, QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMdiSubWindow
from PyQt5.QtCore import QAbstractTableModel, Qt, QProcess, QThread, pyqtSignal, QRunnable

from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *

import pyarrow as pa
import pyarrow.dataset as ds
import pyarrow.compute as pc
import pyarrow.parquet as pq

PLOT_TYPE = ["scatter", "density", "hexbin"] 


def plot_mdiarea(mdiArea, figure, ax=None, title=None, process_bar=None, status_label=None):
    """
    Plot figure in mdiArea
    """
    plot = PlotSubWindow(fig=figure, ax=ax, title=title)

    # Create a new sub-window and add the plot widget to it
    sub = QMdiSubWindow()
    sub.setWidget(plot)
    # Add the sub-window to the MDI area
    mdiArea.addSubWindow(sub)
    mdiArea.tileSubWindows()
    process_bar.setValue(100)
    status_label.setText("Processing Status: Loading completed")
    sub.show()


def plot_canvas_mdiarea(mdiArea, canvas, title=None, process_bar=None, status_label=None):
    """
    Plot figure in mdiArea
    """
    plot = SubWindow_Canvas(canvas=canvas, title=title)

    # Create a new sub-window and add the plot widget to it
    sub = QMdiSubWindow()
    sub.setWidget(plot)
    # Add the sub-window to the MDI area
    mdiArea.addSubWindow(sub)
    mdiArea.tileSubWindows()
    process_bar.setValue(100)
    status_label.setText("Processing Status: Loading completed")
    
    sub.show()


def show_df_mdiarea(mdiArea, data, title):
    df = ShowPandas(data, title)
    sub = QMdiSubWindow()
    sub.setWidget(df)
    mdiArea.addSubWindow(sub)
    sub.show()
    mdiArea.tileSubWindows()

def str2num(lineEdit):
    if lineEdit.text().strip() == 'Max':
        return np.Inf
    elif lineEdit.text().strip() == 'Min':
        return np.NINF
    elif lineEdit.text().strip() == 'N.A':
        return -2
    else:
        return float(lineEdit.text().strip())

def transfer_feature(dataset, filter, feature):
    ms_tran = 60 * 60 * 1000
    if feature == 'poh':
        return dataset.to_table(columns=['time(ms)'], filter=filter).column('time(ms)').to_numpy() / ms_tran
    # if feature == 'delta_time(s)':
    #     return dataset.to_table(columns=['time(ms)'], filter=filter)

def ddf_compute(queue, **kwargs):
    '''Filter data with multiprocessing'''
    ms_tran = 60*60*1000
    count_limit = 100
    dataset = kwargs['dataset']
    # ddf = kwargs['ddf']
    if kwargs['type'] == 1: 
        # Only one lba
        tmp = ddf.loc[(ddf['start_lba'] == kwargs['lba']) & (ddf['time(ms)'] >= kwargs['start_poh'] * ms_tran)]
        if kwargs['end_poh'] > 0 :
            tmp = tmp.loc[tmp['time(ms)'] <= kwargs['end_poh'] * ms_tran]
    else:
        # specify start and end lba
        # tmp = ddf.loc[(ddf['start_lba'] >= kwargs['start_lba']) & (ddf['time(ms)'] >= kwargs['start_poh'] * ms_tran)]
        # if kwargs['end_lba'] > 0:
        #     tmp = tmp.loc[tmp['start_lba'] <= kwargs['end_lba']]
        # if kwargs['end_poh'] > 0:
        #     tmp = tmp.loc[tmp['time(ms)'] <= kwargs['end_poh'] * ms_tran]

        # for accessed data:
        if kwargs['type'] == 3:
            expr = pa.compute.field("start_lba_count") >= count_limit
            filter1 = (pc.field("start_lba") >= kwargs['start_lba']) & (pc.field("start_lba") <= kwargs['end_lba']) & (pc.field("time(ms)") >= kwargs['start_poh'] * ms_tran) \
                & (pc.field("start_lba") <= kwargs['end_poh'] * ms_tran)

            ans = dataset.to_table(columns=['start_lba'], filter=filter1).group_by("start_lba").aggregate([("start_lba", "count")]).filter(expr).sort_by([('start_lba_count', "descending")])
            # tmp = tmp['start_lba'].value_counts().compute().to_frame().reset_index()
            # tmp.loc[tmp['start_lba'] >= count_limit, :].rename(columns={"index": "start_lba", "start_lba": "count"}).to_parquet("buffer.parquet", index=False)
            pa.parquet.write_table(ans, "buffer.parquet")
            queue.put("buffer.parquet")
            return

    subdata = tmp.compute()
    if len(subdata) == 0:
        queue.put("None data found")
        return 
    
    subdata = subdata.reset_index(drop=True)

    if kwargs['type'] == 1:
        subdata = subdata.sort_values(by=['time(ms)'])

    if len(kwargs['aug']) != 0:
        for column in kwargs['aug']:
            if column == 'POH':
                subdata['POH'] = subdata['time(ms)'] / (ms_tran)
            # elif column == ''
            if column == 'delta_time':
                subdata['delta_time_hr'] = subdata['time(ms)'].diff() / ms_tran
                subdata['delta_time_sec'] = subdata['time(ms)'].diff() / 1000
                subdata['log_time(delta)'] = np.log10(subdata['delta_time_hr'])
                subdata = subdata.fillna(0)

    subdata.to_parquet("buffer.parquet")
    queue.put("buffer.parquet")

def stack_data(queue, **kwargs):
    ddf_compute(queue, **kwargs)
    buffer_file = queue.get()
    subdata = pd.read_parquet(buffer_file)
    subdata['end_lba'] = subdata['start_lba'] + subdata['xfer_length']
    stacked = subdata.melt(id_vars=['op', 'time(ms)', 'xfer_length'], var_name='label', value_name='lba').sort_values(by=['time(ms)', 'label'], ascending= [True, False]).reset_index(drop=True)
    stacked.to_parquet(buffer_file)
    queue.put(buffer_file)
    
class TableModel(QtCore.QAbstractTableModel):
    """create table model for pandas dataframe"""
    def __init__(self, data):
        super(TableModel, self).__init__()
        self._data = data

    def data(self, index, role):
        if role == Qt.DisplayRole:
            value = self._data.iloc[index.row(), index.column()]
            return str(value)

    def rowCount(self, index):
        return self._data.shape[0]

    def columnCount(self, index):
        return self._data.shape[1]

    def headerData(self, section, orientation, role):
        # section is the index of the column/row.
        if role == Qt.DisplayRole:
            if orientation == Qt.Horizontal:
                return str(self._data.columns[section])

            if orientation == Qt.Vertical:
                return str(self._data.index[section])


class ShowPandas(QtWidgets.QWidget):
    """
    create a new table to use the table model class to visualize pandas dataframe
    """
    def __init__(self, data, title):
        super().__init__()
        self.setWindowTitle(f"{title}")

        self.table = QtWidgets.QTableView()

        self.model = TableModel(data)
        self.table.setModel(self.model)

        layout = QtWidgets.QVBoxLayout()
        layout.addWidget(self.table)
        self.setLayout(layout)
        # self.setCentralWidget(self.table)

        # self.show()


class MplCanvas(FigureCanvasQTAgg):
    """
    Canvas class for PyQt5
    """
    def __init__(self, parent=None, nrows=1, ncols=1, width=5, height=4, dpi=100):
        fig, self.axes = plt.subplots(nrows=nrows, ncols=ncols, figsize=(width, height), dpi=dpi)
        super(MplCanvas, self).__init__(fig)


class PlotThread(QThread):
    """
    A threading to handle plot function
    """
    finished = pyqtSignal()

    def __init__(self, canvas, x_data, y_data):
        super().__init__()
        self.ax = canvas.axes
        self.x_data = x_data
        self.y_data = y_data

    def run(self):
        # Generate the plot in a separate thread
        self.ax.plot(self.x_data, self.y_data)
        self.ax.set_xlabel('X label')
        self.ax.set_ylabel('Y label')
        self.ax.figure.canvas.draw()

        # Emit the finished signal
        self.finished.emit()


class PlotSubWindow(QtWidgets.QWidget):
    """
    plot figure in Sub Window
    """
    def __init__(self, parent=None, fig=None, ax=None, title=None):
        super(PlotSubWindow, self).__init__(parent)
        if title is None:
            self.setWindowTitle("Plot Window")
        else:
            self.setWindowTitle(title)
        self.canvas = FigureCanvasQTAgg(fig)
        # Create a navigation toolbar and add it to the window
        self.toolbar = NavigationToolbar(self.canvas, self)

        layout = QtWidgets.QVBoxLayout()
        layout.addWidget(self.toolbar)
        layout.addWidget(self.canvas)
        self.setLayout(layout)


class SubWindow_Canvas(QtWidgets.QWidget):
    """
    plot figure in Sub Window
    """
    def __init__(self, parent=None, canvas=None, title=None):
        super(SubWindow_Canvas, self).__init__(parent)
        if title is None:
            self.setWindowTitle("Plot Window")
        else:
            self.setWindowTitle(title)
        # Create a navigation toolbar and add it to the window
        self.canvas = canvas
        self.toolbar = NavigationToolbar(canvas, self)
        
        layout = QtWidgets.QVBoxLayout()
        layout.addWidget(self.toolbar)
        layout.addWidget(canvas)
        self.setLayout(layout)


class WorkerSignals(QtCore.QObject):
    '''
    Defines the signals available from a running worker thread.
    Supported signals are:

    finished
        No data

    error
        tuple (exctype, value, traceback.format_exc() )

    result
        object data returned from processing, anything

    progress
        int indicating % progress

    '''
    finished = pyqtSignal()
    error = pyqtSignal(tuple)
    result = pyqtSignal(object)
    progress = pyqtSignal(int)


class Worker(QRunnable):
    '''
    Worker thread

    Inherits from QRunnable to handler worker thread setup, signals and wrap-up.

    :param callback: The function callback to run on this worker thread. Supplied args and
                     kwargs will be passed through to the runner.
    :type callback: function
    :param args: Arguments to pass to the callback function
    :param kwargs: Keywords to pass to the callback function

    '''

    def __init__(self, fn, *args, **kwargs):
        super(Worker, self).__init__()

        # Store constructor arguments (re-used for processing)
        self.fn = fn
        self.args = args
        self.kwargs = kwargs
        self.signals = WorkerSignals()

        # # Add the callback to our kwargs
        # self.kwargs['progress_callback'] = self.signals.progress

    @pyqtSlot()
    def run(self):
        '''
        Initialise the runner function with passed args, kwargs.
        '''
        # Retrieve args/kwargs here; and fire processing using them
        try:
            self.result = self.fn(*self.args, **self.kwargs)
            if len(self.result) > 0:
                pa.parquet.write_table(self.result, "buffer.parquet")
        except:
            traceback.print_exc()
            exctype, value = sys.exc_info()[:2]
            self.signals.error.emit((exctype, value, traceback.format_exc()))
        # else:
        #     self.signals.result.emit(result)  # Return the result of the processing
        finally:
            self.signals.finished.emit()  # Done
